@echo off
setlocal
title MrChat Server Manager

set "MRCHAT_ROOT=%LOCALAPPDATA%\MrApps\MrChat"
set "MRCHAT_PYTHON=%MRCHAT_ROOT%\.venv\Scripts\python.exe"
set "MRCHAT_CONTROL=%MRCHAT_ROOT%\server_control.py"

if not exist "%MRCHAT_PYTHON%" goto not_installed
if not exist "%MRCHAT_CONTROL%" goto update_required

:menu
cls
echo ========================================
echo          MrChat Server Manager
echo ========================================
echo.
echo   1. Enable MrChat Server
echo   2. Disable MrChat Server
echo.
choice /c 12 /n /m "Choose 1 or 2: "
if errorlevel 2 goto disable
if errorlevel 1 goto enable

:enable
echo.
echo Enabling the Windows Firewall rule...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$p=Start-Process -FilePath '%MRCHAT_PYTHON%' -ArgumentList '""%MRCHAT_CONTROL%"" --firewall-enable' -Verb RunAs -Wait -PassThru; exit $p.ExitCode"
if errorlevel 1 (
  echo.
  echo The firewall rule was not enabled. Please approve the Windows prompt.
  pause
  exit /b 1
)
echo Starting MrChat Server in the background...
"%MRCHAT_PYTHON%" "%MRCHAT_CONTROL%" --enable
echo.
echo Router requirement for friends outside your Wi-Fi:
echo   Network Setting ^> NAT ^> Port Forwarding
echo   TCP 8765 -^> 192.168.1.117 port 8765
echo.
pause
exit /b %errorlevel%

:disable
echo.
echo Stopping MrChat Server...
"%MRCHAT_PYTHON%" "%MRCHAT_CONTROL%" --disable
echo Removing the Windows Firewall rule...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$p=Start-Process -FilePath '%MRCHAT_PYTHON%' -ArgumentList '""%MRCHAT_CONTROL%"" --firewall-disable' -Verb RunAs -Wait -PassThru; exit $p.ExitCode"
echo.
pause
exit /b 0

:not_installed
echo MrChat is not installed in the default MrInstaller location.
echo Install or update MrChat first, then run this file again.
echo.
pause
exit /b 1

:update_required
echo The installed MrChat version does not include the home-server controller.
echo Update MrChat from MrInstaller first, then run this file again.
echo.
pause
exit /b 1
