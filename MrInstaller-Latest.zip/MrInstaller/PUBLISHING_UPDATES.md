# Publishing MrInstaller updates

MrInstaller is configured to watch one fixed ZIP file:

- Repository: `https://github.com/MrKayra/MrInstaller-Updates`
- Branch: `main`
- File: `MrInstaller-Latest.zip`

The hub asks GitHub for that file's metadata when it starts. If GitHub's file SHA changes, users receive an update popup. No separate online JSON manifest is required.

## First upload

1. Upload `MrInstaller-Latest.zip` to the root of the repository.
2. Keep the repository public.
3. Keep the file on the `main` branch.
4. Give friends the exact same ZIP after it has been uploaded.
5. Their first successful check records the current GitHub file SHA as the baseline.

## Every later update

1. Replace any changed app package or MrInstaller source files locally.
2. Optionally increase visible app versions and edit `UPDATE_NOTES.txt`.
3. Run `make_update_zip.bat`.
4. Upload the newly generated `MrInstaller-Latest.zip` over the existing GitHub file.
5. Commit the replacement to `main`.

The build script gives every bundle a unique `hub_build_id`. This prevents a newly installed bundle from repeatedly reporting itself as an available update.

## App update detection

Installed apps store the SHA-256 of the package used to install them. New bundles hash their included app packages. If a package changed, the app receives an **Update** button even when its visible version number was not changed.

Changing visible versions is still recommended because it makes the update easier to understand.

## Safety behavior

- GitHub checks use HTTPS.
- The ZIP is never downloaded or run without user approval.
- Update-check failures do not stop MrInstaller from opening.
- Replacing the online ZIP does not silently uninstall removed apps.
- The user downloads the new bundle, extracts it, and starts its MrInstaller.
