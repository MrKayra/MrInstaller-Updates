def build_stylesheet(accent: str) -> str:
    return f"""
    * {{
        font-family: "Segoe UI";
        font-size: 10.5pt;
        color: #E9ECF4;
    }}

    QMainWindow, QDialog {{
        background: #0B0E14;
    }}

    QWidget#Sidebar {{
        background: #10141D;
        border-right: 1px solid #232938;
    }}

    QLabel#Brand {{
        font-size: 19pt;
        font-weight: 800;
        color: #FFFFFF;
    }}

    QLabel#Subtle {{
        color: #8992A6;
    }}

    QLabel#PageTitle {{
        font-size: 22pt;
        font-weight: 800;
        color: #FFFFFF;
    }}

    QLabel#CardTitle {{
        font-size: 14pt;
        font-weight: 700;
        color: #FFFFFF;
    }}

    QLabel#SectionTitle {{
        font-size: 12pt;
        font-weight: 700;
        color: #FFFFFF;
    }}

    QFrame#Card, QFrame#Panel {{
        background: #121722;
        border: 1px solid #252C3B;
        border-radius: 14px;
    }}

    QFrame#Card:hover {{
        border: 1px solid {accent};
        background: #151B27;
    }}

    QPushButton {{
        min-height: 34px;
        padding: 0 15px;
        border-radius: 9px;
        border: 1px solid #30384A;
        background: #1B2230;
        color: #F4F6FB;
        font-weight: 600;
    }}

    QPushButton:hover {{
        background: #242D3D;
        border-color: #46516A;
    }}

    QPushButton:pressed {{
        background: #171D28;
    }}

    QPushButton:disabled {{
        color: #667085;
        background: #151923;
        border-color: #242A37;
    }}

    QPushButton#Primary {{
        background: {accent};
        border-color: {accent};
        color: white;
    }}

    QPushButton#Primary:hover {{
        background: #7A73FF;
    }}

    QPushButton#Danger {{
        background: #321A22;
        border-color: #7C3048;
        color: #FF9AB4;
    }}

    QPushButton#Nav {{
        text-align: left;
        padding-left: 14px;
        background: transparent;
        border: 1px solid transparent;
        color: #AEB6C8;
    }}

    QPushButton#Nav:hover {{
        background: #171D29;
        color: #FFFFFF;
    }}

    QPushButton#Nav:checked {{
        background: #1B2038;
        border-color: #393C79;
        color: #FFFFFF;
    }}

    QLineEdit {{
        min-height: 38px;
        padding: 0 13px;
        border-radius: 10px;
        background: #131824;
        border: 1px solid #2A3242;
        selection-background-color: {accent};
    }}

    QLineEdit:focus {{
        border-color: {accent};
    }}

    QScrollArea {{
        border: none;
        background: transparent;
    }}

    QScrollArea > QWidget > QWidget, QWidget#ListHost {{
        background: transparent;
    }}

    QScrollBar:vertical {{
        background: transparent;
        width: 10px;
        margin: 2px;
    }}

    QScrollBar::handle:vertical {{
        background: #30384A;
        border-radius: 5px;
        min-height: 25px;
    }}

    QProgressBar {{
        min-height: 12px;
        max-height: 12px;
        border-radius: 6px;
        background: #232938;
        text-align: center;
        color: transparent;
    }}

    QProgressBar::chunk {{
        border-radius: 6px;
        background: {accent};
    }}

    QCheckBox {{
        spacing: 8px;
    }}

    QCheckBox::indicator {{
        width: 18px;
        height: 18px;
        border-radius: 5px;
        border: 1px solid #3A4458;
        background: #121722;
    }}

    QCheckBox::indicator:checked {{
        background: {accent};
        border-color: {accent};
    }}

    QComboBox {{
        min-height: 36px;
        padding: 0 10px;
        border-radius: 9px;
        background: #131824;
        border: 1px solid #2A3242;
    }}

    QToolTip {{
        background: #161C27;
        border: 1px solid #3A4355;
        color: #FFFFFF;
        padding: 6px;
    }}
    """
