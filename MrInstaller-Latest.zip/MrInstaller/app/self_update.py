from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile
from pathlib import Path
from threading import Event
from typing import Callable

from .utils import format_bytes


ProgressCallback = Callable[[int, str], None]


def _git_blob_sha1(path: Path) -> str:
    size = path.stat().st_size
    digest = hashlib.sha1()
    digest.update(f"blob {size}\0".encode("ascii"))
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest().lower()


def _validate_update_zip(path: Path) -> None:
    with zipfile.ZipFile(path, "r") as archive:
        bad = archive.testzip()
        if bad:
            raise ValueError(f"The update ZIP is corrupted near: {bad}")
        names = [name.replace("\\", "/") for name in archive.namelist()]
        required = {
            "MrInstaller/main.py",
            "MrInstaller/run.bat",
            "MrInstaller/installer_manifest.json",
            "MrInstaller/app/ui.py",
        }
        missing = sorted(required.difference(names))
        if missing:
            raise ValueError(
                "The downloaded ZIP is not a complete MrInstaller update. Missing: "
                + ", ".join(missing)
            )
        for name in names:
            parts = Path(name).parts
            if name.startswith("/") or ".." in parts:
                raise ValueError(f"Unsafe path found inside update ZIP: {name}")


def download_github_update_bundle(
    download_url: str,
    expected_git_sha: str,
    progress: ProgressCallback,
    cancel_event: Event,
) -> Path:
    clean_url = str(download_url).strip()
    expected = str(expected_git_sha).strip().lower()
    if not clean_url.lower().startswith("https://"):
        raise ValueError("The GitHub update download must use HTTPS.")
    if len(expected) != 40 or any(ch not in "0123456789abcdef" for ch in expected):
        raise ValueError("GitHub returned an invalid update SHA.")

    update_dir = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "MrInstaller" / "updates"
    update_dir.mkdir(parents=True, exist_ok=True)
    destination = update_dir / f"MrInstaller-Latest-{expected[:12]}.zip"
    partial = destination.with_suffix(".zip.part")
    partial.unlink(missing_ok=True)

    request = urllib.request.Request(
        clean_url,
        headers={
            "User-Agent": "MrInstaller-SelfUpdater/1.4",
            "Accept": "application/octet-stream",
            "Cache-Control": "no-cache",
        },
    )
    progress(1, "Connecting to GitHub")
    try:
        with urllib.request.urlopen(request, timeout=30) as response, partial.open("wb") as output:
            total = int(response.headers.get("Content-Length", "0") or 0)
            if total > 2_000_000_000:
                raise ValueError("The update ZIP is unexpectedly large.")
            downloaded = 0
            while chunk := response.read(1024 * 512):
                if cancel_event.is_set():
                    raise RuntimeError("Update download cancelled")
                output.write(chunk)
                downloaded += len(chunk)
                if total > 0:
                    percent = min(88, int(downloaded * 88 / total))
                    progress(
                        percent,
                        f"Downloading the MrInstaller update ({format_bytes(downloaded)} / {format_bytes(total)})",
                    )
                else:
                    percent = min(88, 5 + downloaded // (1024 * 512))
                    progress(
                        percent,
                        f"Downloading the MrInstaller update ({format_bytes(downloaded)})",
                    )
    except Exception:
        partial.unlink(missing_ok=True)
        raise

    partial.replace(destination)
    progress(90, "Verifying the GitHub file")
    actual_git_sha = _git_blob_sha1(destination)
    if actual_git_sha != expected:
        destination.unlink(missing_ok=True)
        raise ValueError(
            "The downloaded ZIP does not match GitHub's file SHA. It was deleted for safety."
        )

    progress(95, "Checking update contents")
    try:
        _validate_update_zip(destination)
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    progress(100, "Update ready")
    return destination


def launch_in_place_updater(
    project_root: Path,
    bundle_path: Path,
    remote_sha: str,
) -> None:
    helper_source = project_root / "app" / "update_helper.py"
    if not helper_source.exists():
        raise FileNotFoundError(f"Update helper not found: {helper_source}")
    if not bundle_path.exists():
        raise FileNotFoundError(f"Downloaded update not found: {bundle_path}")

    helper_dir = Path(tempfile.mkdtemp(prefix="MrInstallerUpdater_"))
    helper_copy = helper_dir / "update_helper.py"
    shutil.copy2(helper_source, helper_copy)

    creationflags = 0
    if os.name == "nt":
        creationflags = (
            getattr(subprocess, "DETACHED_PROCESS", 0x00000008)
            | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200)
            | getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
        )
    subprocess.Popen(
        [
            sys.executable,
            str(helper_copy),
            "--project-root",
            str(project_root.resolve()),
            "--bundle",
            str(bundle_path.resolve()),
            "--wait-pid",
            str(os.getpid()),
            "--remote-sha",
            str(remote_sha).strip().lower(),
        ],
        cwd=str(helper_dir),
        close_fds=True,
        creationflags=creationflags,
    )
