from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .models import AppEntry, HubSettings


@dataclass(slots=True)
class AppConfig:
    settings: HubSettings
    apps: list[AppEntry]
    manifest_path: Path

    @classmethod
    def load(cls, manifest_path: Path) -> "AppConfig":
        if not manifest_path.exists():
            raise FileNotFoundError(f"Manifest not found: {manifest_path}")

        raw: dict[str, Any] = json.loads(manifest_path.read_text(encoding="utf-8"))
        settings = HubSettings.from_dict(raw.get("settings", {}))
        apps = [AppEntry.from_dict(item) for item in raw.get("apps", [])]

        app_ids = [app.app_id for app in apps]
        duplicates = sorted({x for x in app_ids if app_ids.count(x) > 1})
        if duplicates:
            raise ValueError(f"Duplicate app IDs in manifest: {', '.join(duplicates)}")

        return cls(settings=settings, apps=apps, manifest_path=manifest_path)

    @property
    def expanded_install_root(self) -> Path:
        expanded = os.path.expandvars(os.path.expanduser(self.settings.install_root))
        return Path(expanded)
