from __future__ import annotations

import ctypes
import hashlib
import os
import shutil
import subprocess
import zipfile
from pathlib import Path
from typing import Callable


def sha256_file(path: Path, progress: Callable[[int], None] | None = None) -> str:
    digest = hashlib.sha256()
    total = max(path.stat().st_size, 1)
    read = 0
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
            read += len(chunk)
            if progress:
                progress(int((read / total) * 100))
    return digest.hexdigest().lower()


def safe_extract_zip(
    archive: Path,
    destination: Path,
    progress: Callable[[int, str], None] | None = None,
) -> None:
    destination = destination.resolve()
    with zipfile.ZipFile(archive, "r") as zf:
        members = zf.infolist()
        total = max(sum(m.file_size for m in members), 1)
        extracted = 0
        for member in members:
            target = (destination / member.filename).resolve()
            if destination != target and destination not in target.parents:
                raise ValueError(f"Unsafe path inside ZIP archive: {member.filename}")
            if member.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(member, "r") as source, target.open("wb") as output:
                while chunk := source.read(1024 * 1024):
                    output.write(chunk)
                    extracted += len(chunk)
                    if progress:
                        progress(min(int((extracted / total) * 100), 100), member.filename)


def detect_payload_root(extracted_dir: Path) -> Path:
    children = [p for p in extracted_dir.iterdir() if p.name != "__MACOSX"]
    if len(children) == 1 and children[0].is_dir():
        return children[0]
    return extracted_dir


def create_windows_shortcut(
    shortcut_path: Path,
    target_path: Path,
    working_directory: Path,
    icon_path: Path | None = None,
    arguments: list[str] | None = None,
) -> None:
    shortcut_path.parent.mkdir(parents=True, exist_ok=True)

    def ps_escape(value: str) -> str:
        return value.replace("'", "''")

    icon_line = ""
    if icon_path and icon_path.exists():
        icon_line = f"$s.IconLocation = '{ps_escape(str(icon_path))}';"
    args_line = ""
    if arguments:
        rendered = subprocess.list2cmdline(arguments)
        args_line = f"$s.Arguments = '{ps_escape(rendered)}';"

    script = (
        "$ws = New-Object -ComObject WScript.Shell;"
        f"$s = $ws.CreateShortcut('{ps_escape(str(shortcut_path))}');"
        f"$s.TargetPath = '{ps_escape(str(target_path))}';"
        f"$s.WorkingDirectory = '{ps_escape(str(working_directory))}';"
        f"{args_line}{icon_line}$s.Save();"
    )
    result = subprocess.run(
        ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
        capture_output=True,
        text=True,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "Could not create shortcut")


def desktop_path() -> Path:
    return Path(os.environ.get("USERPROFILE", str(Path.home()))) / "Desktop"


def start_menu_programs_path() -> Path:
    appdata = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    return appdata / "Microsoft" / "Windows" / "Start Menu" / "Programs"
