from __future__ import annotations

import datetime as dt
import fnmatch
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path
from threading import Event
from typing import Callable
from urllib.parse import urlparse

from .models import AppEntry, ExternalDependency
from .state import StateStore
from .utils import (
    create_windows_shortcut,
    desktop_path,
    detect_payload_root,
    format_bytes,
    safe_extract_zip,
    sha256_file,
    start_menu_programs_path,
)


ProgressCallback = Callable[[int, str], None]


class InstallCancelled(RuntimeError):
    pass


class InstallerService:
    def __init__(self, project_root: Path, state: StateStore) -> None:
        self.project_root = project_root
        self.state = state

    @staticmethod
    def _python_command() -> list[str]:
        current = Path(sys.executable)
        if not getattr(sys, "frozen", False) and current.name.lower() in {"python.exe", "pythonw.exe", "python", "python3"}:
            if current.name.lower() == "pythonw.exe" and current.with_name("python.exe").exists():
                current = current.with_name("python.exe")
            return [str(current)]
        py = shutil.which("py")
        if py:
            return [py, "-3"]
        python = shutil.which("python") or shutil.which("python3")
        if python:
            return [python]
        raise RuntimeError(
            "Python 3.11 or newer was not found. Install Python, enable Add Python to PATH, "
            "then restart MrInstaller."
        )

    @staticmethod
    def _run_logged(
        command: list[str],
        cwd: Path,
        log_path: Path,
        cancel_event: Event,
        timeout_seconds: int = 1800,
    ) -> None:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
        started = time.monotonic()
        with log_path.open("w", encoding="utf-8", errors="replace") as log:
            process = subprocess.Popen(
                command,
                cwd=str(cwd),
                stdout=log,
                stderr=subprocess.STDOUT,
                text=True,
                creationflags=flags,
            )
            while process.poll() is None:
                if cancel_event.is_set():
                    process.terminate()
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                    raise InstallCancelled("Installation cancelled")
                if time.monotonic() - started > timeout_seconds:
                    process.kill()
                    raise TimeoutError("The setup process timed out.")
                time.sleep(0.2)
        if process.returncode != 0:
            details = log_path.read_text(encoding="utf-8", errors="replace")[-7000:]
            raise RuntimeError(
                f"Setup failed with exit code {process.returncode}.\n\n"
                f"Recent setup output:\n{details}\n\nFull log:\n{log_path}"
            )

    def _provision_python_app(
        self,
        app: AppEntry,
        target: Path,
        progress: ProgressCallback,
        cancel_event: Event,
    ) -> tuple[Path, list[str]]:
        entry = target / app.python_entry
        requirements = target / app.requirements_file
        if not entry.exists():
            raise FileNotFoundError(f"Python entry file not found:\n{entry}")
        if not requirements.exists():
            raise FileNotFoundError(f"Requirements file not found:\n{requirements}")

        venv = target / ".venv"
        python = venv / "Scripts" / "python.exe"
        pythonw = venv / "Scripts" / "pythonw.exe"
        log = target / "mrinstaller_setup.log"

        progress(76, "Creating a private app environment")
        if not python.exists():
            self._run_logged(
                [*self._python_command(), "-m", "venv", str(venv)],
                target,
                log,
                cancel_event,
            )

        progress(81, "Installing required app components")
        self._run_logged(
            [str(python), "-m", "pip", "install", "--disable-pip-version-check", "--upgrade", "pip"],
            target,
            log,
            cancel_event,
        )
        self._run_logged(
            [str(python), "-m", "pip", "install", "--disable-pip-version-check", "-r", str(requirements)],
            target,
            log,
            cancel_event,
        )
        if not pythonw.exists():
            raise FileNotFoundError(f"The private Python launcher was not created:\n{pythonw}")
        return pythonw, [str(entry), *app.launch_args]

    def install_app(
        self,
        app: AppEntry,
        install_root: Path,
        desktop_shortcut: bool,
        start_menu_shortcut: bool,
        progress: ProgressCallback,
        cancel_event: Event,
    ) -> dict:
        archive = (self.project_root / app.archive).resolve()
        if not archive.exists():
            raise FileNotFoundError(f"Package ZIP is missing:\n{archive}")

        install_root.mkdir(parents=True, exist_ok=True)
        target = (install_root / app.install_subdir).resolve()
        staging_parent = install_root / ".staging"
        staging_parent.mkdir(parents=True, exist_ok=True)
        backup = install_root / f".backup_{app.app_id}"

        archive_size = max(archive.stat().st_size, 1)
        progress(1, f"Checking package (0 / {format_bytes(archive_size)})")
        package_sha256 = sha256_file(
            archive,
            lambda percent: progress(
                min(4, max(1, int(percent * 0.04))),
                f"Checking package ({format_bytes(int(archive_size * percent / 100))} / {format_bytes(archive_size)})",
            ),
        )
        if cancel_event.is_set():
            raise InstallCancelled("Installation cancelled")

        with tempfile.TemporaryDirectory(prefix=f"{app.app_id}_", dir=staging_parent) as temp_name:
            extracted = Path(temp_name) / "payload"
            extracted.mkdir(parents=True, exist_ok=True)

            def extraction_progress(percent: int, filename: str) -> None:
                progress(5 + int(percent * 0.65), f"Extracting {filename}")
                if cancel_event.is_set():
                    raise InstallCancelled("Installation cancelled")

            safe_extract_zip(archive, extracted, extraction_progress)
            payload_root = detect_payload_root(extracted)
            progress(72, "Preparing installation")
            if backup.exists():
                shutil.rmtree(backup, ignore_errors=True)

            old_moved = False
            try:
                if target.exists():
                    target.replace(backup)
                    old_moved = True
                shutil.copytree(payload_root, target)

                if app.python_entry:
                    executable, launch_args = self._provision_python_app(app, target, progress, cancel_event)
                else:
                    executable = target / app.executable if app.executable else None
                    launch_args = list(app.launch_args)
                    if executable and not executable.exists():
                        raise FileNotFoundError(f"Configured executable not found:\n{executable}")

                progress(91, "Creating shortcuts")
                icon_path = target / app.icon if app.icon else None
                if icon_path and not icon_path.exists():
                    fallback = self.project_root / app.icon
                    icon_path = fallback if fallback.exists() else None

                if executable and desktop_shortcut:
                    create_windows_shortcut(
                        desktop_path() / f"{app.name}.lnk",
                        executable,
                        target,
                        icon_path,
                        launch_args,
                    )
                if executable and start_menu_shortcut:
                    create_windows_shortcut(
                        start_menu_programs_path() / "Mr Apps" / f"{app.name}.lnk",
                        executable,
                        target,
                        icon_path,
                        launch_args,
                    )

                installed_at = dt.datetime.now().isoformat(timespec="seconds")
                info = {
                    "name": app.name,
                    "version": app.version,
                    "path": str(target),
                    "executable": str(executable) if executable else "",
                    "launch_args": launch_args,
                    "working_directory": str(target),
                    "installed_at": installed_at,
                    "package_sha256": package_sha256,
                }
                (target / ".mrinstaller_install.json").write_text(
                    json.dumps(info, indent=2, ensure_ascii=False), encoding="utf-8"
                )
                self.state.mark_installed(app.app_id, info)
                if old_moved and backup.exists():
                    shutil.rmtree(backup, ignore_errors=True)
                progress(100, "Installed")
                return info
            except Exception:
                if target.exists():
                    shutil.rmtree(target, ignore_errors=True)
                if old_moved and backup.exists():
                    backup.replace(target)
                raise

    def uninstall_app(self, app: AppEntry, progress: ProgressCallback) -> None:
        info = self.state.installed_info(app.app_id)
        if not info:
            return
        target = Path(str(info.get("path", "")))
        progress(25, "Removing files")
        if target.exists():
            shutil.rmtree(target)
        for shortcut in (
            desktop_path() / f"{app.name}.lnk",
            start_menu_programs_path() / "Mr Apps" / f"{app.name}.lnk",
        ):
            try:
                shortcut.unlink(missing_ok=True)
            except OSError:
                pass
        progress(90, "Updating installer state")
        self.state.mark_uninstalled(app.app_id)
        progress(100, "Uninstalled")

    def launch_app(self, app: AppEntry) -> None:
        info = self.state.installed_info(app.app_id)
        if not info:
            raise RuntimeError(f"{app.name} is not installed.")
        executable = Path(str(info.get("executable", "")))
        args = [str(x) for x in info.get("launch_args", [])]
        cwd = Path(str(info.get("working_directory", executable.parent)))
        if not executable.exists():
            raise FileNotFoundError(f"Executable not found:\n{executable}")

        flags = 0
        if os.name == "nt":
            flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        subprocess.Popen(
            [str(executable), *args],
            cwd=str(cwd),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
            creationflags=flags,
        )

    def is_app_running(self, app: AppEntry) -> bool:
        """Return whether the installed app executable is currently running."""
        if os.name != "nt":
            return False
        info = self.state.installed_info(app.app_id)
        if not info:
            return False
        executable = Path(str(info.get("executable", "")))
        if not executable:
            return False
        target = os.path.normcase(os.path.abspath(str(executable)))
        try:
            import ctypes
            from ctypes import wintypes

            TH32CS_SNAPPROCESS = 0x00000002
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value

            class PROCESSENTRY32W(ctypes.Structure):
                _fields_ = [
                    ("dwSize", wintypes.DWORD),
                    ("cntUsage", wintypes.DWORD),
                    ("th32ProcessID", wintypes.DWORD),
                    ("th32DefaultHeapID", ctypes.c_size_t),
                    ("th32ModuleID", wintypes.DWORD),
                    ("cntThreads", wintypes.DWORD),
                    ("th32ParentProcessID", wintypes.DWORD),
                    ("pcPriClassBase", wintypes.LONG),
                    ("dwFlags", wintypes.DWORD),
                    ("szExeFile", wintypes.WCHAR * 260),
                ]

            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel32.CreateToolhelp32Snapshot.argtypes = (wintypes.DWORD, wintypes.DWORD)
            kernel32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
            kernel32.Process32FirstW.argtypes = (wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W))
            kernel32.Process32FirstW.restype = wintypes.BOOL
            kernel32.Process32NextW.argtypes = (wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W))
            kernel32.Process32NextW.restype = wintypes.BOOL
            kernel32.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
            kernel32.OpenProcess.restype = wintypes.HANDLE
            kernel32.QueryFullProcessImageNameW.argtypes = (
                wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)
            )
            kernel32.QueryFullProcessImageNameW.restype = wintypes.BOOL
            kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
            kernel32.CloseHandle.restype = wintypes.BOOL

            snapshot = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
            if snapshot in (None, 0, INVALID_HANDLE_VALUE):
                return False
            try:
                entry = PROCESSENTRY32W()
                entry.dwSize = ctypes.sizeof(PROCESSENTRY32W)
                has_entry = bool(kernel32.Process32FirstW(snapshot, ctypes.byref(entry)))
                while has_entry:
                    process = kernel32.OpenProcess(
                        PROCESS_QUERY_LIMITED_INFORMATION, False, entry.th32ProcessID
                    )
                    if process:
                        try:
                            buffer = ctypes.create_unicode_buffer(32768)
                            length = wintypes.DWORD(len(buffer))
                            if kernel32.QueryFullProcessImageNameW(
                                process, 0, buffer, ctypes.byref(length)
                            ):
                                running = os.path.normcase(
                                    os.path.abspath(buffer.value[: length.value])
                                )
                                if running == target:
                                    return True
                        finally:
                            kernel32.CloseHandle(process)
                    has_entry = bool(kernel32.Process32NextW(snapshot, ctypes.byref(entry)))
            finally:
                kernel32.CloseHandle(snapshot)
        except Exception:
            return False
        return False

    def download_dependency(
        self,
        dependency: ExternalDependency,
        progress: ProgressCallback,
        cancel_event: Event,
    ) -> Path:
        if not dependency.download_url.lower().startswith("https://"):
            raise ValueError("External downloads must use HTTPS.")
        download_dir = Path.home() / "Downloads" / "MrInstaller" / "ExternalInstallers"
        download_dir.mkdir(parents=True, exist_ok=True)
        file_name = dependency.file_name or Path(urlparse(dependency.download_url).path).name
        if not file_name:
            file_name = f"{dependency.name}.exe"
        destination = download_dir / file_name
        partial = destination.with_suffix(destination.suffix + ".part")

        request = urllib.request.Request(dependency.download_url, headers={"User-Agent": "MrInstaller/1.0"})
        progress(1, f"Connecting to download {dependency.name}")
        with urllib.request.urlopen(request, timeout=30) as response, partial.open("wb") as output:
            total = int(response.headers.get("Content-Length", "0") or 0)
            downloaded = 0
            while chunk := response.read(1024 * 256):
                if cancel_event.is_set():
                    partial.unlink(missing_ok=True)
                    raise InstallCancelled("Download cancelled")
                output.write(chunk)
                downloaded += len(chunk)
                if total > 0:
                    percent = min(90, int(downloaded * 90 / total))
                    progress(
                        percent,
                        f"Downloading {dependency.name} ({format_bytes(downloaded)} / {format_bytes(total)})",
                    )
                else:
                    percent = min(90, 5 + downloaded // (1024 * 512))
                    progress(
                        percent,
                        f"Downloading {dependency.name} ({format_bytes(downloaded)})",
                    )
        partial.replace(destination)
        if dependency.sha256:
            progress(91, f"Verifying {dependency.name} download")
            digest = sha256_file(
                destination,
                lambda percent: progress(
                    91 + min(8, int(percent * 0.08)),
                    f"Verifying {dependency.name} ({percent}%)",
                ),
            )
            if digest != dependency.sha256:
                destination.unlink(missing_ok=True)
                raise ValueError("The downloaded file failed SHA-256 verification and was deleted.")
        progress(100, f"{dependency.name} download ready")
        return destination

    @staticmethod
    def _select_archive_installer(folder: Path, dependency: ExternalDependency) -> Path:
        executables = [p for p in folder.rglob("*.exe") if "uninstall" not in p.name.lower()]
        if not executables:
            raise FileNotFoundError("No installer executable was found inside the downloaded ZIP.")
        machine = platform.machine().lower()
        preferred_arch = "arm64" if "arm" in machine else "x64"
        patterns = dependency.installer_patterns or [f"*{preferred_arch}*.exe", "*setup*.exe", "*.exe"]
        patterns = sorted(
            patterns,
            key=lambda pattern: (
                0 if preferred_arch in pattern.lower() else 1,
                1 if (preferred_arch == "arm64" and "x64" in pattern.lower()) else 0,
            ),
        )
        for pattern in patterns:
            matches = [p for p in executables if fnmatch.fnmatch(p.name.lower(), pattern.lower())]
            if matches:
                arch_matches = [p for p in matches if preferred_arch in p.name.lower()]
                return sorted(arch_matches or matches, key=lambda p: len(str(p)))[0]
        return sorted(executables, key=lambda p: len(str(p)))[0]

    def run_external_installer(
        self,
        installer_path: Path,
        dependency: ExternalDependency,
        progress: ProgressCallback,
        cancel_event: Event,
    ) -> None:
        actual = installer_path
        if installer_path.suffix.lower() == ".zip":
            progress(15, "Extracting external installer")
            folder = installer_path.with_suffix("")
            if folder.exists():
                shutil.rmtree(folder)
            folder.mkdir(parents=True)
            safe_extract_zip(installer_path, folder)
            actual = self._select_archive_installer(folder, dependency)

        progress(45, f"Starting {dependency.name} setup")
        args = [str(actual), *dependency.silent_args]
        if dependency.requires_admin:
            params = subprocess.list2cmdline(args[1:]).replace("'", "''")
            escaped = str(actual).replace("'", "''")
            command = [
                "powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command",
                f"$p = Start-Process -FilePath '{escaped}' -ArgumentList '{params}' -Verb RunAs -Wait -PassThru; exit $p.ExitCode",
            ]
        else:
            command = args
        log = Path.home() / "Downloads" / "MrInstaller" / "ExternalInstallers" / f"{dependency.name}_install.log"
        self._run_logged(command, actual.parent, log, cancel_event, timeout_seconds=3600)
        progress(100, "External installer finished")

    def install_winget_dependency(
        self,
        dependency: ExternalDependency,
        progress: ProgressCallback,
        cancel_event: Event,
    ) -> None:
        winget = shutil.which("winget")
        if not winget:
            raise RuntimeError(
                "Windows Package Manager (winget) was not found. Open the dependency's official website instead."
            )
        progress(10, f"Preparing {dependency.name}")
        command = [
            winget, "install", "--exact", "--id", dependency.winget_id,
            "--accept-package-agreements", "--accept-source-agreements", "--disable-interactivity",
        ]
        log = Path.home() / "Downloads" / "MrInstaller" / "ExternalInstallers" / f"{dependency.name}_winget.log"
        self._run_logged(command, Path.home(), log, cancel_event, timeout_seconds=3600)
        progress(100, f"{dependency.name} installed")
