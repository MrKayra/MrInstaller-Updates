from __future__ import annotations

import json
import re
import socket
import ssl
import urllib.error
import urllib.parse
import urllib.request
from typing import Any


_GITHUB_API_RESPONSE_LIMIT = 16 * 1024 * 1024


_GITHUB_REPOSITORY_RE = re.compile(
    r"^https://github\.com/(?P<owner>[A-Za-z0-9_.-]+)/(?P<repo>[A-Za-z0-9_.-]+?)(?:\.git)?/?$",
    re.IGNORECASE,
)


def parse_github_repository_url(url: str) -> tuple[str, str]:
    clean = str(url).strip()
    match = _GITHUB_REPOSITORY_RE.fullmatch(clean)
    if not match:
        raise ValueError(
            "The GitHub repository URL must look like "
            "https://github.com/OWNER/REPOSITORY"
        )
    return match.group("owner"), match.group("repo")


def _fetch_github_json(url: str, not_found_message: str) -> dict[str, Any]:
    """Read a bounded GitHub API JSON object without ever downloading file content."""
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": "MrInstaller-UpdateChecker/1.9.1",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "Cache-Control": "no-cache",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=12) as response:
            declared_length = int(response.headers.get("Content-Length", "0") or 0)
            if declared_length > _GITHUB_API_RESPONSE_LIMIT:
                raise ValueError("GitHub returned unexpectedly large metadata.")
            data = response.read(_GITHUB_API_RESPONSE_LIMIT + 1)
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            raise FileNotFoundError(not_found_message) from exc
        if exc.code == 403:
            raise RuntimeError(
                "GitHub refused the update check. Its temporary unauthenticated "
                "request limit may have been reached. Try again later."
            ) from exc
        raise RuntimeError(f"GitHub update check failed with HTTP {exc.code}.") from exc
    except urllib.error.URLError as exc:
        reason = exc.reason
        if isinstance(reason, (TimeoutError, socket.timeout)):
            raise TimeoutError("The GitHub update check timed out. Try again.") from exc
        if isinstance(reason, ssl.SSLError):
            raise RuntimeError(
                "A secure connection to GitHub could not be established. Check your "
                "PC date/time, antivirus HTTPS scanning, VPN, or proxy settings."
            ) from exc
        raise ConnectionError(
            "Could not reach GitHub. Check your internet connection, firewall, VPN, "
            "or DNS settings, then try again."
        ) from exc
    except (TimeoutError, socket.timeout) as exc:
        raise TimeoutError("The GitHub update check timed out. Try again.") from exc
    except OSError as exc:
        raise ConnectionError(
            "Could not reach GitHub. Check your internet connection, firewall, VPN, "
            "or DNS settings, then try again."
        ) from exc

    if len(data) > _GITHUB_API_RESPONSE_LIMIT:
        raise ValueError("GitHub returned unexpectedly large metadata.")
    try:
        payload = json.loads(data.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("GitHub returned unreadable update information.") from exc
    if not isinstance(payload, dict):
        raise ValueError("GitHub returned unreadable update information.")
    return payload


def _require_git_sha(value: object, message: str) -> str:
    sha = str(value or "").strip().lower()
    if not re.fullmatch(r"[0-9a-f]{40}", sha):
        raise ValueError(message)
    return sha


def fetch_github_bundle_metadata(
    repository_url: str,
    branch: str,
    file_path: str,
) -> dict[str, Any]:
    """Resolve one repository file through Git trees instead of the Contents API.

    The Contents endpoint may embed a small ZIP as Base64 inside JSON.  That made a
    harmless update file look like oversized metadata.  Walking the exact Git tree
    returns only branch, commit, directory, and blob metadata, never the ZIP bytes.
    """
    owner, repo = parse_github_repository_url(repository_url)
    clean_branch = str(branch).strip() or "main"
    clean_path = str(file_path).strip().replace("\\", "/").lstrip("/")
    if not clean_path or not clean_path.lower().endswith(".zip"):
        raise ValueError("The configured GitHub update file must be a ZIP file.")
    path_parts = [part for part in clean_path.split("/") if part]
    if not path_parts or any(part in {".", ".."} for part in path_parts):
        raise ValueError("The configured GitHub update file path is invalid.")

    api_owner = urllib.parse.quote(owner, safe="")
    api_repo = urllib.parse.quote(repo, safe="")
    api_root = f"https://api.github.com/repos/{api_owner}/{api_repo}"

    branch_url = f"{api_root}/branches/{urllib.parse.quote(clean_branch, safe='')}"
    branch_payload = _fetch_github_json(
        branch_url,
        f"Branch {clean_branch} was not found in {owner}/{repo}.",
    )
    commit_sha = _require_git_sha(
        (branch_payload.get("commit") or {}).get("sha")
        if isinstance(branch_payload.get("commit"), dict)
        else "",
        "GitHub returned an invalid branch commit SHA.",
    )

    # GitHub's branch response normally includes the head commit's tree SHA.
    # Read it directly to keep the common root-file lookup to only two small API calls.
    branch_commit = branch_payload.get("commit")
    branch_commit_details = (
        branch_commit.get("commit")
        if isinstance(branch_commit, dict)
        else None
    )
    tree_info = (
        branch_commit_details.get("tree")
        if isinstance(branch_commit_details, dict)
        else None
    )
    last_tree_url = branch_url
    if isinstance(tree_info, dict):
        tree_sha = _require_git_sha(
            tree_info.get("sha"),
            "GitHub returned an invalid repository tree SHA.",
        )
    else:
        # Compatibility fallback for GitHub-compatible API responses that omit
        # the nested tree object from the branch response.
        commit_url = f"{api_root}/git/commits/{commit_sha}"
        commit_payload = _fetch_github_json(
            commit_url,
            f"The latest commit for branch {clean_branch} could not be read.",
        )
        tree_info = commit_payload.get("tree")
        if not isinstance(tree_info, dict):
            raise ValueError("GitHub did not return the repository tree.")
        tree_sha = _require_git_sha(
            tree_info.get("sha"),
            "GitHub returned an invalid repository tree SHA.",
        )
        last_tree_url = commit_url

    file_entry: dict[str, Any] | None = None
    for index, part in enumerate(path_parts):
        tree_url = f"{api_root}/git/trees/{tree_sha}"
        last_tree_url = tree_url
        tree_payload = _fetch_github_json(
            tree_url,
            f"The repository tree for {clean_path} could not be read.",
        )
        entries = tree_payload.get("tree")
        if not isinstance(entries, list):
            raise ValueError("GitHub did not return the repository tree entries.")
        entry = next(
            (
                item
                for item in entries
                if isinstance(item, dict) and str(item.get("path", "")) == part
            ),
            None,
        )
        if entry is None:
            raise FileNotFoundError(
                f"{clean_path} was not found in {owner}/{repo} on branch {clean_branch}."
            )

        is_last = index == len(path_parts) - 1
        entry_type = str(entry.get("type", ""))
        if is_last:
            if entry_type != "blob":
                raise ValueError("The configured GitHub update path is not a file.")
            file_entry = entry
            break
        if entry_type != "tree":
            raise FileNotFoundError(
                f"{clean_path} was not found in {owner}/{repo} on branch {clean_branch}."
            )
        tree_sha = _require_git_sha(
            entry.get("sha"),
            "GitHub returned an invalid directory tree SHA.",
        )

    if file_entry is None:
        raise ValueError("GitHub did not return update-file metadata.")
    file_sha = _require_git_sha(
        file_entry.get("sha"),
        "GitHub returned an invalid file SHA.",
    )
    try:
        size = max(0, int(file_entry.get("size", 0) or 0))
    except (TypeError, ValueError):
        size = 0

    encoded_path = "/".join(urllib.parse.quote(part, safe="") for part in path_parts)
    download_url = (
        f"https://raw.githubusercontent.com/{api_owner}/{api_repo}/{commit_sha}/{encoded_path}"
    )
    html_url = f"https://github.com/{api_owner}/{api_repo}/blob/{commit_sha}/{encoded_path}"

    return {
        "source": "github_file",
        "repository_url": repository_url,
        "owner": owner,
        "repository": repo,
        "branch": clean_branch,
        "path": clean_path,
        "sha": file_sha,
        "size": size,
        "download_url": download_url,
        "html_url": html_url,
        "api_url": last_tree_url,
        "commit_sha": commit_sha,
        "metadata_method": "git_tree",
    }


def fetch_update_manifest(url: str) -> dict[str, Any]:
    clean = str(url).strip()
    if not clean:
        raise ValueError("No update-manifest URL is configured.")
    if not clean.lower().startswith("https://"):
        raise ValueError("The update-manifest URL must use HTTPS.")

    request = urllib.request.Request(
        clean,
        headers={
            "User-Agent": "MrInstaller-UpdateChecker/1.3",
            "Accept": "application/json",
            "Cache-Control": "no-cache",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            length = int(response.headers.get("Content-Length", "0") or 0)
            if length > 2_000_000:
                raise ValueError("The update manifest is unexpectedly large.")
            data = response.read(2_000_001)
            if len(data) > 2_000_000:
                raise ValueError("The update manifest is unexpectedly large.")
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"The update server returned HTTP {exc.code}.") from exc
    except urllib.error.URLError as exc:
        reason = exc.reason
        if isinstance(reason, (TimeoutError, socket.timeout)):
            raise TimeoutError("The update check timed out. Try again.") from exc
        raise ConnectionError(
            "Could not reach the update server. Check your internet connection, "
            "firewall, VPN, or DNS settings, then try again."
        ) from exc
    except (TimeoutError, socket.timeout) as exc:
        raise TimeoutError("The update check timed out. Try again.") from exc

    try:
        payload = json.loads(data.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("The update server returned unreadable JSON data.") from exc
    if not isinstance(payload, dict):
        raise ValueError("The update manifest must contain a JSON object.")
    if int(payload.get("schema_version", 1)) != 1:
        raise ValueError("This MrInstaller build does not support that update-manifest schema.")
    return payload
