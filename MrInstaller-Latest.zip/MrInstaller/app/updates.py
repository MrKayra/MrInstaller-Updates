from __future__ import annotations

import json
import re
import urllib.parse
import urllib.request
from typing import Any


_GITHUB_REPOSITORY_RE = re.compile(
    r"^https://github\.com/(?P<owner>[A-Za-z0-9_.-]+)/(?P<repo>[A-Za-z0-9_.-]+?)(?:\.git)?/?$",
    re.IGNORECASE,
)


def parse_github_repository_url(url: str) -> tuple[str, str]:
    clean = str(url).strip()
    match = _GITHUB_REPOSITORY_RE.fullmatch(clean)
    if not match:
        raise ValueError(
            "The GitHub repository URL must look like "
            "https://github.com/OWNER/REPOSITORY"
        )
    return match.group("owner"), match.group("repo")


def fetch_github_bundle_metadata(
    repository_url: str,
    branch: str,
    file_path: str,
) -> dict[str, Any]:
    owner, repo = parse_github_repository_url(repository_url)
    clean_branch = str(branch).strip() or "main"
    clean_path = str(file_path).strip().lstrip("/")
    if not clean_path or not clean_path.lower().endswith(".zip"):
        raise ValueError("The configured GitHub update file must be a ZIP file.")

    encoded_path = "/".join(urllib.parse.quote(part, safe="") for part in clean_path.split("/"))
    query = urllib.parse.urlencode({"ref": clean_branch})
    api_url = (
        f"https://api.github.com/repos/{urllib.parse.quote(owner, safe='')}/"
        f"{urllib.parse.quote(repo, safe='')}/contents/{encoded_path}?{query}"
    )
    request = urllib.request.Request(
        api_url,
        headers={
            "User-Agent": "MrInstaller-UpdateChecker/1.3",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "Cache-Control": "no-cache",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=12) as response:
            data = response.read(1_000_001)
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            raise FileNotFoundError(
                f"{clean_path} was not found in {owner}/{repo} on branch {clean_branch}."
            ) from exc
        if exc.code == 403:
            raise RuntimeError(
                "GitHub refused the update check. Its temporary unauthenticated "
                "request limit may have been reached. Try again later."
            ) from exc
        raise RuntimeError(f"GitHub update check failed with HTTP {exc.code}.") from exc
    except OSError as exc:
        raise RuntimeError(f"Could not connect to GitHub: {exc}") from exc

    if len(data) > 1_000_000:
        raise ValueError("GitHub returned unexpectedly large metadata.")
    payload = json.loads(data.decode("utf-8-sig"))
    if not isinstance(payload, dict) or payload.get("type") != "file":
        raise ValueError("GitHub did not return update-file metadata.")

    sha = str(payload.get("sha", "")).strip().lower()
    download_url = str(payload.get("download_url", "")).strip()
    html_url = str(payload.get("html_url", "")).strip()
    size = int(payload.get("size", 0) or 0)
    if not re.fullmatch(r"[0-9a-f]{40,64}", sha):
        raise ValueError("GitHub returned an invalid file SHA.")
    if not download_url.lower().startswith("https://"):
        raise ValueError("GitHub did not provide a secure ZIP download URL.")

    return {
        "source": "github_file",
        "repository_url": repository_url,
        "owner": owner,
        "repository": repo,
        "branch": clean_branch,
        "path": clean_path,
        "sha": sha,
        "size": size,
        "download_url": download_url,
        "html_url": html_url,
        "api_url": api_url,
    }


def fetch_update_manifest(url: str) -> dict[str, Any]:
    clean = str(url).strip()
    if not clean:
        raise ValueError("No update-manifest URL is configured.")
    if not clean.lower().startswith("https://"):
        raise ValueError("The update-manifest URL must use HTTPS.")

    request = urllib.request.Request(
        clean,
        headers={
            "User-Agent": "MrInstaller-UpdateChecker/1.3",
            "Accept": "application/json",
            "Cache-Control": "no-cache",
        },
    )
    with urllib.request.urlopen(request, timeout=10) as response:
        length = int(response.headers.get("Content-Length", "0") or 0)
        if length > 2_000_000:
            raise ValueError("The update manifest is unexpectedly large.")
        data = response.read(2_000_001)
        if len(data) > 2_000_000:
            raise ValueError("The update manifest is unexpectedly large.")

    payload = json.loads(data.decode("utf-8-sig"))
    if not isinstance(payload, dict):
        raise ValueError("The update manifest must contain a JSON object.")
    if int(payload.get("schema_version", 1)) != 1:
        raise ValueError("This MrInstaller build does not support that update-manifest schema.")
    return payload
