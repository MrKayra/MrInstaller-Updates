from __future__ import annotations

import re


def version_key(value: str) -> tuple[int, ...]:
    """Return a stable numeric key for versions such as 1.2.0 or v4.0.1."""
    numbers = [int(part) for part in re.findall(r"\d+", str(value))]
    return tuple((numbers + [0, 0, 0, 0])[:4])


def is_newer(candidate: str, current: str) -> bool:
    return version_key(candidate) > version_key(current)
