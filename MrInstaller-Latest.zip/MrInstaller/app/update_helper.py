from __future__ import annotations

import argparse
import ctypes
import datetime as dt
import json
import os
import shutil
import tempfile
import time
import traceback
import zipfile
from pathlib import Path


PRESERVE_TOP_LEVEL = {".venv", ".git"}
MANAGED_DIRECTORIES = {"app", "assets", "packages"}


def appdata_dir() -> Path:
    base = Path(os.environ.get("APPDATA", str(Path.home())))
    path = base / "MrInstaller"
    path.mkdir(parents=True, exist_ok=True)
    return path


def log(message: str) -> None:
    stamp = dt.datetime.now().isoformat(timespec="seconds")
    with (appdata_dir() / "update.log").open("a", encoding="utf-8") as handle:
        handle.write(f"{stamp} | {message}\n")


def show_error(message: str) -> None:
    log(message)
    if os.name == "nt":
        try:
            ctypes.windll.user32.MessageBoxW(
                None,
                message + "\n\nSee %APPDATA%\\MrInstaller\\update.log for details.",
                "MrInstaller update failed",
                0x10,
            )
        except Exception:
            pass


def wait_for_process(pid: int, timeout_seconds: int = 120) -> None:
    if pid <= 0:
        return
    if os.name == "nt":
        SYNCHRONIZE = 0x00100000
        handle = ctypes.windll.kernel32.OpenProcess(SYNCHRONIZE, False, pid)
        if handle:
            ctypes.windll.kernel32.WaitForSingleObject(handle, timeout_seconds * 1000)
            ctypes.windll.kernel32.CloseHandle(handle)
            return
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        try:
            os.kill(pid, 0)
        except OSError:
            return
        time.sleep(0.2)


def safe_extract(archive_path: Path, destination: Path) -> Path:
    destination = destination.resolve()
    with zipfile.ZipFile(archive_path, "r") as archive:
        bad = archive.testzip()
        if bad:
            raise ValueError(f"Corrupted update member: {bad}")
        for member in archive.infolist():
            target = (destination / member.filename).resolve()
            if target != destination and destination not in target.parents:
                raise ValueError(f"Unsafe update path: {member.filename}")
        archive.extractall(destination)
    payload = destination / "MrInstaller"
    if not payload.is_dir():
        children = [child for child in destination.iterdir() if child.name != "__MACOSX"]
        if len(children) == 1 and children[0].is_dir():
            payload = children[0]
    for required in ("main.py", "run.bat", "installer_manifest.json", "app"):
        if not (payload / required).exists():
            raise ValueError(f"Update payload is missing {required}")
    return payload


def copy_item(source: Path, destination: Path) -> None:
    if source.is_dir():
        shutil.copytree(source, destination)
    else:
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)


def remove_item(path: Path) -> None:
    if path.is_dir() and not path.is_symlink():
        shutil.rmtree(path)
    else:
        path.unlink(missing_ok=True)


def update_state(remote_sha: str, payload: Path) -> None:
    state_path = appdata_dir() / "state.json"
    try:
        state = json.loads(state_path.read_text(encoding="utf-8")) if state_path.exists() else {}
        if not isinstance(state, dict):
            state = {}
        settings = state.setdefault("settings", {})
        if not isinstance(settings, dict):
            settings = {}
            state["settings"] = settings
        settings["github_update_bundle_sha"] = remote_sha
        manifest = json.loads((payload / "installer_manifest.json").read_text(encoding="utf-8"))
        build_id = str((manifest.get("settings") or {}).get("hub_build_id", "")).strip()
        if build_id:
            settings["active_hub_build_id"] = build_id
        temp = state_path.with_suffix(".tmp")
        temp.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")
        temp.replace(state_path)
    except Exception as exc:
        log(f"Could not update state baseline: {exc}")


def apply_update(project_root: Path, payload: Path, remote_sha: str) -> None:
    backup_root = Path(tempfile.mkdtemp(prefix="MrInstallerBackup_"))
    replaced_names: list[str] = []
    try:
        payload_names = [child.name for child in payload.iterdir() if child.name not in PRESERVE_TOP_LEVEL]
        # Entire managed directories are replaced so deleted source/package files
        # do not survive an update. Root files are replaced only when the new
        # bundle contains a file with that name, preserving unrelated user files.
        targets = set(payload_names) | MANAGED_DIRECTORIES
        for name in sorted(targets):
            current = project_root / name
            if current.exists() and name not in PRESERVE_TOP_LEVEL:
                copy_item(current, backup_root / name)
                remove_item(current)
                replaced_names.append(name)

        for source in payload.iterdir():
            if source.name in PRESERVE_TOP_LEVEL:
                continue
            copy_item(source, project_root / source.name)

        # Force run.bat to refresh dependencies if requirements changed.
        venv = project_root / ".venv"
        if venv.exists():
            for marker in venv.glob(".mrinstaller_ready*"):
                marker.unlink(missing_ok=True)

        update_state(remote_sha, payload)
        log(f"In-place update completed successfully from SHA {remote_sha}.")
    except Exception:
        log("Update failed; restoring backup.\n" + traceback.format_exc())
        for name in set(replaced_names) | {child.name for child in payload.iterdir()}:
            target = project_root / name
            if target.exists() and name not in PRESERVE_TOP_LEVEL:
                remove_item(target)
        for source in backup_root.iterdir():
            copy_item(source, project_root / source.name)
        raise
    finally:
        shutil.rmtree(backup_root, ignore_errors=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", required=True)
    parser.add_argument("--bundle", required=True)
    parser.add_argument("--wait-pid", type=int, default=0)
    parser.add_argument("--remote-sha", required=True)
    args = parser.parse_args()

    project_root = Path(args.project_root).resolve()
    bundle = Path(args.bundle).resolve()
    log(f"Updater started for {project_root}; waiting for PID {args.wait_pid}.")
    wait_for_process(args.wait_pid)

    extract_root = Path(tempfile.mkdtemp(prefix="MrInstallerPayload_"))
    try:
        payload = safe_extract(bundle, extract_root)
        apply_update(project_root, payload, args.remote_sha)
        run_bat = project_root / "run.bat"
        if os.name == "nt":
            os.startfile(str(run_bat))  # type: ignore[attr-defined]
        else:
            log("Non-Windows test run: restart skipped.")
        bundle.unlink(missing_ok=True)
        return 0
    except Exception as exc:
        show_error(f"MrInstaller could not apply the update:\n{exc}")
        return 1
    finally:
        shutil.rmtree(extract_root, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
