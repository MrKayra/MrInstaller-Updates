from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class ExternalDependency:
    name: str
    description: str = ""
    download_url: str = ""
    website_url: str = ""
    winget_id: str = ""
    file_name: str = ""
    sha256: str = ""
    silent_args: list[str] = field(default_factory=list)
    installer_patterns: list[str] = field(default_factory=list)
    local_requirements_file: str = ""
    requires_admin: bool = False
    restart_required: bool = False
    required: bool = True
    instructions: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ExternalDependency":
        return cls(
            name=str(data["name"]),
            description=str(data.get("description", "")),
            download_url=str(data.get("download_url", "")),
            website_url=str(data.get("website_url", "")),
            winget_id=str(data.get("winget_id", "")),
            file_name=str(data.get("file_name", "")),
            sha256=str(data.get("sha256", "")).lower().strip(),
            silent_args=[str(x) for x in data.get("silent_args", [])],
            installer_patterns=[str(x) for x in data.get("installer_patterns", [])],
            local_requirements_file=str(data.get("local_requirements_file", "")).strip(),
            requires_admin=bool(data.get("requires_admin", False)),
            restart_required=bool(data.get("restart_required", False)),
            required=bool(data.get("required", True)),
            instructions=[str(x) for x in data.get("instructions", [])],
        )


@dataclass(slots=True)
class AppEntry:
    app_id: str
    name: str
    version: str
    description: str
    category: str
    archive: str
    install_subdir: str
    executable: str = ""
    python_entry: str = ""
    requirements_file: str = ""
    launch_args: list[str] = field(default_factory=list)
    icon: str = ""
    publisher: str = ""
    requires_admin: bool = False
    restart_required: bool = False
    instructions_before: list[str] = field(default_factory=list)
    instructions_after: list[str] = field(default_factory=list)
    tips: list[str] = field(default_factory=list)
    dependencies: list[ExternalDependency] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AppEntry":
        return cls(
            app_id=str(data["id"]),
            name=str(data["name"]),
            version=str(data.get("version", "1.0.0")),
            description=str(data.get("description", "")),
            category=str(data.get("category", "Other")),
            archive=str(data["archive"]),
            install_subdir=str(data.get("install_subdir", data["id"])),
            executable=str(data.get("executable", "")),
            python_entry=str(data.get("python_entry", "")),
            requirements_file=str(data.get("requirements_file", "")),
            launch_args=[str(x) for x in data.get("launch_args", [])],
            icon=str(data.get("icon", "")),
            publisher=str(data.get("publisher", "")),
            requires_admin=bool(data.get("requires_admin", False)),
            restart_required=bool(data.get("restart_required", False)),
            instructions_before=[str(x) for x in data.get("instructions_before", [])],
            instructions_after=[str(x) for x in data.get("instructions_after", [])],
            tips=[str(x) for x in data.get("tips", [])],
            dependencies=[ExternalDependency.from_dict(item) for item in data.get("dependencies", [])],
        )


@dataclass(slots=True)
class HubSettings:
    hub_name: str = "MrInstaller"
    publisher: str = "Kayra.exe Studios"
    install_root: str = r"%LOCALAPPDATA%\MrApps"
    accent: str = "#6C63FF"
    allow_external_downloads: bool = True
    desktop_shortcuts_default: bool = True
    start_menu_shortcuts_default: bool = True
    hub_version: str = "1.4.1"
    hub_build_id: str = ""
    github_repository_url: str = ""
    github_update_branch: str = "main"
    github_update_file: str = "MrInstaller-Latest.zip"
    update_manifest_url: str = ""
    check_updates_on_startup: bool = True

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "HubSettings":
        defaults = cls()
        return cls(
            hub_name=str(data.get("hub_name", defaults.hub_name)),
            publisher=str(data.get("publisher", defaults.publisher)),
            install_root=str(data.get("install_root", defaults.install_root)),
            accent=str(data.get("accent", defaults.accent)),
            allow_external_downloads=bool(data.get("allow_external_downloads", True)),
            desktop_shortcuts_default=bool(data.get("desktop_shortcuts_default", True)),
            start_menu_shortcuts_default=bool(data.get("start_menu_shortcuts_default", True)),
            hub_version=str(data.get("hub_version", defaults.hub_version)),
            hub_build_id=str(data.get("hub_build_id", "")).strip(),
            github_repository_url=str(data.get("github_repository_url", "")).strip(),
            github_update_branch=str(data.get("github_update_branch", "main")).strip() or "main",
            github_update_file=str(data.get("github_update_file", "MrInstaller-Latest.zip")).strip() or "MrInstaller-Latest.zip",
            update_manifest_url=str(data.get("update_manifest_url", "")).strip(),
            check_updates_on_startup=bool(data.get("check_updates_on_startup", True)),
        )
