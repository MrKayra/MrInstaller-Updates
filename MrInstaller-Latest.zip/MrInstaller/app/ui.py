from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Callable

from PySide6.QtCore import Qt, QThreadPool, Signal, QTimer, QUrl
from PySide6.QtGui import QCloseEvent, QDesktopServices, QPixmap
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSpacerItem,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
    QApplication,
)

from .config import AppConfig
from .installer import InstallerService
from .i18n import ENGLISH, TURKISH, set_app_language, tr
from .models import AppEntry, ExternalDependency
from .state import StateStore
from .styles import build_stylesheet
from .utils import format_bytes, sha256_file
from .self_update import launch_in_place_updater
from .versioning import is_newer
from .workers import (
    TaskWorker,
    make_dependency_worker,
    make_external_installer_worker,
    make_install_worker,
    make_local_component_worker,
    make_uninstall_worker,
    make_winget_worker,
    make_update_check_worker,
    make_github_update_check_worker,
    make_github_bundle_download_worker,
)


class SettingsDialog(QDialog):
    def __init__(self, config: AppConfig, state: StateStore, parent=None) -> None:
        super().__init__(parent)
        self.config = config
        self.state = state
        self.setWindowTitle("Installer Settings")
        self.setMinimumWidth(610)

        root = QVBoxLayout(self)
        root.setContentsMargins(24, 24, 24, 24)
        root.setSpacing(16)

        title = QLabel("Installer settings")
        title.setObjectName("PageTitle")
        root.addWidget(title)

        explanation = QLabel(
            "These settings control where apps are installed and which shortcuts "
            "are selected by default."
        )
        explanation.setObjectName("Subtle")
        explanation.setWordWrap(True)
        root.addWidget(explanation)

        language_label = QLabel("Interface language")
        language_label.setObjectName("SectionTitle")
        root.addWidget(language_label)

        self.language_combo = QComboBox()
        self.language_combo.addItem("English", ENGLISH)
        self.language_combo.addItem("Türkçe", TURKISH)
        current_language = str(state.get_setting("language", ENGLISH))
        language_index = self.language_combo.findData(current_language)
        self.language_combo.setCurrentIndex(max(0, language_index))
        root.addWidget(self.language_combo)

        language_note = QLabel(
            "English is used by default. This language is shared by MrInstaller and every Mr app."
        )
        language_note.setObjectName("Subtle")
        language_note.setWordWrap(True)
        root.addWidget(language_note)

        path_label = QLabel("Default installation folder")
        path_label.setObjectName("SectionTitle")
        root.addWidget(path_label)

        row = QHBoxLayout()
        self.path_edit = QLineEdit(
            str(
                state.get_setting(
                    "install_root",
                    str(config.expanded_install_root),
                )
            )
        )
        browse = QPushButton("Browse")
        browse.clicked.connect(self.browse)
        row.addWidget(self.path_edit, 1)
        row.addWidget(browse)
        root.addLayout(row)

        self.desktop = QCheckBox("Create desktop shortcuts by default")
        self.desktop.setChecked(
            bool(
                state.get_setting(
                    "desktop_shortcuts",
                    config.settings.desktop_shortcuts_default,
                )
            )
        )
        root.addWidget(self.desktop)

        self.start_menu = QCheckBox("Create Start Menu shortcuts by default")
        self.start_menu.setChecked(
            bool(
                state.get_setting(
                    "start_menu_shortcuts",
                    config.settings.start_menu_shortcuts_default,
                )
            )
        )
        root.addWidget(self.start_menu)

        self.check_updates = QCheckBox("Check online for updates when MrInstaller starts")
        self.check_updates.setChecked(
            bool(
                state.get_setting(
                    "check_updates_on_startup",
                    config.settings.check_updates_on_startup,
                )
            )
        )
        root.addWidget(self.check_updates)

        if config.settings.github_repository_url:
            channel_text = (
                "GitHub ZIP update channel configured:\n"
                f"{config.settings.github_repository_url}/blob/"
                f"{config.settings.github_update_branch}/{config.settings.github_update_file}"
            )
        elif config.settings.update_manifest_url:
            channel_text = "Online JSON update channel configured."
        else:
            channel_text = "Online update channel is not configured yet."
        channel = QLabel(channel_text)
        channel.setObjectName("Subtle")
        channel.setWordWrap(True)
        root.addWidget(channel)

        security = QLabel(
            "External apps are never downloaded or opened silently. The hub will "
            "show the source, instructions, restart notice, and ask for confirmation."
        )
        security.setObjectName("Subtle")
        security.setWordWrap(True)
        root.addWidget(security)

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        cancel = QPushButton("Cancel")
        save = QPushButton("Save")
        save.setObjectName("Primary")
        cancel.clicked.connect(self.reject)
        save.clicked.connect(self.save)
        buttons.addWidget(cancel)
        buttons.addWidget(save)
        root.addLayout(buttons)

    def browse(self) -> None:
        selected = QFileDialog.getExistingDirectory(
            self,
            "Choose installation folder",
            self.path_edit.text(),
        )
        if selected:
            self.path_edit.setText(selected)

    def save(self) -> None:
        path = self.path_edit.text().strip()
        if not path:
            QMessageBox.warning(self, "Invalid folder", "Choose an install folder.")
            return
        self.state.set_setting("install_root", path)
        self.state.set_setting("desktop_shortcuts", self.desktop.isChecked())
        self.state.set_setting("start_menu_shortcuts", self.start_menu.isChecked())
        self.state.set_setting("check_updates_on_startup", self.check_updates.isChecked())
        language = str(self.language_combo.currentData() or ENGLISH)
        self.state.set_setting("language", language)
        set_app_language(language)
        self.accept()


class InstructionDialog(QDialog):
    dependency_requested = Signal(object)

    def __init__(
        self,
        app: AppEntry,
        installed: bool,
        state: StateStore,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.app = app
        self.state = state
        self.setWindowTitle(app.name)
        self.setMinimumSize(680, 590)

        root = QVBoxLayout(self)
        root.setContentsMargins(26, 24, 26, 24)
        root.setSpacing(14)

        title = QLabel(app.name)
        title.setObjectName("PageTitle")
        root.addWidget(title)

        meta = QLabel(f"Version {app.version}  •  {app.category}")
        meta.setObjectName("Subtle")
        root.addWidget(meta)

        description = QLabel(app.description or "No description added yet.")
        description.setWordWrap(True)
        root.addWidget(description)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        body = QWidget()
        body_layout = QVBoxLayout(body)
        body_layout.setContentsMargins(0, 8, 8, 8)
        body_layout.setSpacing(14)

        if app.instructions_before:
            body_layout.addWidget(self.section("Before installing", app.instructions_before))
        if app.dependencies:
            body_layout.addWidget(self.dependencies_section(app.dependencies))
        if app.instructions_after:
            body_layout.addWidget(self.section("After installing", app.instructions_after))
        if app.tips:
            body_layout.addWidget(self.section("Tips and fixes", app.tips))

        if not (
            app.instructions_before
            or app.dependencies
            or app.instructions_after
            or app.tips
        ):
            empty = QLabel(
                "No special instructions have been added for this app yet."
            )
            empty.setObjectName("Subtle")
            body_layout.addWidget(empty)

        body_layout.addStretch(1)
        scroll.setWidget(body)
        root.addWidget(scroll, 1)

        close = QPushButton("Close")
        close.setObjectName("Primary")
        close.clicked.connect(self.accept)
        root.addWidget(close, alignment=Qt.AlignmentFlag.AlignRight)

    def section(self, title: str, items: list[str]) -> QFrame:
        frame = QFrame()
        frame.setObjectName("Panel")
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(18, 16, 18, 16)
        heading = QLabel(title)
        heading.setObjectName("SectionTitle")
        layout.addWidget(heading)
        for index, item in enumerate(items, start=1):
            label = QLabel(f"{index}. {item}")
            label.setWordWrap(True)
            layout.addWidget(label)
        return frame

    def dependencies_section(
        self,
        dependencies: list[ExternalDependency],
    ) -> QFrame:
        frame = QFrame()
        frame.setObjectName("Panel")
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(10)

        heading = QLabel("Required or recommended components")
        heading.setObjectName("SectionTitle")
        layout.addWidget(heading)

        for dep in dependencies:
            dep_frame = QFrame()
            dep_layout = QVBoxLayout(dep_frame)
            dep_layout.setContentsMargins(0, 8, 0, 8)

            top = QHBoxLayout()
            name = QLabel(dep.name + ("  • Required" if dep.required else "  • Optional"))
            name.setStyleSheet("font-weight: 700;")
            action = QPushButton(
                "Install component" if dep.local_requirements_file else "Review & install"
            )
            action.clicked.connect(
                lambda _=False, d=dep: self.dependency_requested.emit((self.app, d))
            )
            top.addWidget(name)
            top.addStretch(1)
            top.addWidget(action)
            dep_layout.addLayout(top)

            if dep.description:
                desc = QLabel(dep.description)
                desc.setObjectName("Subtle")
                desc.setWordWrap(True)
                dep_layout.addWidget(desc)

            if dep.restart_required:
                restart = QLabel("Restart required after installation")
                restart.setStyleSheet("color: #FFCC66; font-weight: 700;")
                dep_layout.addWidget(restart)

            layout.addWidget(dep_frame)
        return frame


class ProgressDialog(QDialog):
    cancelled = Signal()

    def __init__(self, title: str, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setModal(True)
        self.setMinimumWidth(520)
        self._allow_close = False

        root = QVBoxLayout(self)
        root.setContentsMargins(24, 24, 24, 24)
        root.setSpacing(14)

        self.title = QLabel(title)
        self.title.setObjectName("PageTitle")
        root.addWidget(self.title)

        self.message = QLabel("Preparing…")
        self.message.setObjectName("Subtle")
        self.message.setWordWrap(True)
        root.addWidget(self.message)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        root.addWidget(self.progress)

        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.clicked.connect(self.request_cancel)
        root.addWidget(self.cancel_button, alignment=Qt.AlignmentFlag.AlignRight)

    def update_progress(self, value: int, message: str) -> None:
        self.progress.setValue(value)
        self.message.setText(message)

    def request_cancel(self) -> None:
        self.cancel_button.setEnabled(False)
        self.message.setText("Cancelling safely…")
        self.cancelled.emit()

    def allow_close(self) -> None:
        self._allow_close = True
        self.close()

    def closeEvent(self, event: QCloseEvent) -> None:
        if self._allow_close:
            event.accept()
        else:
            event.ignore()


class AppCard(QFrame):
    install_clicked = Signal(object)
    launch_clicked = Signal(object)
    details_clicked = Signal(object)
    uninstall_clicked = Signal(object)

    def __init__(
        self,
        app: AppEntry,
        installed_info: dict | None,
        icon_path: Path | None = None,
        bundled_package_sha256: str = "",
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.app = app
        self.setObjectName("Card")
        self.setMinimumHeight(166)

        root = QHBoxLayout(self)
        root.setContentsMargins(20, 18, 18, 18)
        root.setSpacing(16)

        icon = QLabel()
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon.setFixedSize(62, 62)
        icon.setStyleSheet(
            "background:#222A3A; border:1px solid #343E53; border-radius:16px;"
            "font-size:22pt; font-weight:800;"
        )
        if icon_path and icon_path.exists():
            pixmap = QPixmap(str(icon_path))
            icon.setPixmap(pixmap.scaled(46, 46, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        else:
            icon.setText(app.name[:1].upper())
        root.addWidget(icon, alignment=Qt.AlignmentFlag.AlignTop)

        center = QVBoxLayout()
        center.setSpacing(5)
        name = QLabel(app.name)
        name.setObjectName("CardTitle")
        center.addWidget(name)

        installed_version = str(installed_info.get("version", "0")) if installed_info else ""
        installed_package_sha = str(installed_info.get("package_sha256", "")).lower() if installed_info else ""
        package_changed = bool(
            installed_info
            and bundled_package_sha256
            and installed_package_sha
            and bundled_package_sha256.lower() != installed_package_sha
        )
        version_changed = bool(installed_info and is_newer(app.version, installed_version))
        update_available = version_changed or package_changed
        if version_changed:
            status_text = f"Update available • v{installed_version} → v{app.version}"
        elif package_changed:
            status_text = f"Update available • package changed • v{app.version}"
        elif installed_info:
            status_text = f"Installed • v{installed_version or app.version}"
        else:
            status_text = f"Available • v{app.version}"
        status = QLabel(status_text)
        status.setObjectName("Subtle")
        if update_available:
            status.setStyleSheet("color:#9FE3B2; font-weight:700;")
        center.addWidget(status)

        description = QLabel(app.description or "No description added yet.")
        description.setWordWrap(True)
        description.setMaximumHeight(50)
        center.addWidget(description)
        center.addStretch(1)
        root.addLayout(center, 1)

        actions = QVBoxLayout()
        actions.setSpacing(7)

        if installed_info:
            if update_available:
                update = QPushButton("Update")
                update.setObjectName("Primary")
                update.clicked.connect(lambda: self.install_clicked.emit(app))
                actions.addWidget(update)

            launch = QPushButton("Launch")
            if not update_available:
                launch.setObjectName("Primary")
            launch.clicked.connect(lambda: self.launch_clicked.emit(app))
            actions.addWidget(launch)

            uninstall = QPushButton("Uninstall")
            uninstall.setObjectName("Danger")
            uninstall.clicked.connect(lambda: self.uninstall_clicked.emit(app))
            actions.addWidget(uninstall)
        else:
            install = QPushButton("Install")
            install.setObjectName("Primary")
            install.clicked.connect(lambda: self.install_clicked.emit(app))
            actions.addWidget(install)

        details = QPushButton("Instructions")
        details.clicked.connect(lambda: self.details_clicked.emit(app))
        actions.addWidget(details)
        actions.addStretch(1)
        root.addLayout(actions)


class MainWindow(QMainWindow):
    def __init__(self, config: AppConfig, project_root: Path) -> None:
        super().__init__()
        self.config = config
        self.project_root = project_root
        self.state = StateStore()
        self.service = InstallerService(project_root, self.state)
        self.thread_pool = QThreadPool.globalInstance()
        self.active_worker: TaskWorker | None = None
        self.update_check_worker: TaskWorker | None = None
        self.update_button: QPushButton | None = None
        self._update_check_token = 0
        self._stale_update_workers: dict[int, TaskWorker] = {}
        self.cards: list[AppCard] = []
        self.filter_mode = "all"
        self._package_hash_cache: dict[str, tuple[int, int, str]] = {}
        self._running_update_prompted: set[str] = set()
        previous_build_id = str(self.state.get_setting("active_hub_build_id", ""))
        self.local_hub_build_changed = bool(
            self.config.settings.hub_build_id
            and previous_build_id != self.config.settings.hub_build_id
        )
        self.setWindowTitle(config.settings.hub_name)
        self.resize(1180, 760)
        self.setMinimumSize(980, 650)
        self.setStyleSheet(build_stylesheet(config.settings.accent))

        shell = QWidget()
        self.setCentralWidget(shell)
        shell_layout = QHBoxLayout(shell)
        shell_layout.setContentsMargins(0, 0, 0, 0)
        shell_layout.setSpacing(0)

        shell_layout.addWidget(self.build_sidebar())
        shell_layout.addWidget(self.build_content(), 1)
        self.refresh_cards()
        QTimer.singleShot(650, self.show_bundled_update_popup)
        self.running_update_timer = QTimer(self)
        self.running_update_timer.setInterval(3000)
        self.running_update_timer.timeout.connect(self.check_running_apps_with_updates)
        self.running_update_timer.start()
        if bool(
            self.state.get_setting(
                "check_updates_on_startup",
                self.config.settings.check_updates_on_startup,
            )
        ):
            QTimer.singleShot(1300, lambda: self.check_for_updates(manual=False))

    def build_sidebar(self) -> QWidget:
        sidebar = QWidget()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(244)
        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(20, 24, 20, 20)
        layout.setSpacing(10)

        brand = QLabel(self.config.settings.hub_name)
        brand.setObjectName("Brand")
        brand.setWordWrap(True)
        layout.addWidget(brand)

        publisher = QLabel(f"{self.config.settings.publisher}  •  v{self.config.settings.hub_version}")
        publisher.setObjectName("Subtle")
        layout.addWidget(publisher)
        layout.addSpacing(24)

        self.nav_all = QPushButton("All apps")
        self.nav_all.setObjectName("Nav")
        self.nav_all.setCheckable(True)
        self.nav_all.setChecked(True)
        self.nav_all.clicked.connect(lambda: self.set_filter("all"))

        self.nav_installed = QPushButton("Installed")
        self.nav_installed.setObjectName("Nav")
        self.nav_installed.setCheckable(True)
        self.nav_installed.clicked.connect(lambda: self.set_filter("installed"))

        self.nav_available = QPushButton("Available")
        self.nav_available.setObjectName("Nav")
        self.nav_available.setCheckable(True)
        self.nav_available.clicked.connect(lambda: self.set_filter("available"))

        for button in (self.nav_all, self.nav_installed, self.nav_available):
            layout.addWidget(button)

        layout.addStretch(1)

        tip = QLabel(
            "Each app can include setup instructions, fixes, dependency installers, "
            "and restart warnings."
        )
        tip.setObjectName("Subtle")
        tip.setWordWrap(True)
        layout.addWidget(tip)

        self.update_button = QPushButton("Check for updates")
        self.update_button.clicked.connect(lambda: self.check_for_updates(manual=True))
        layout.addWidget(self.update_button)

        settings = QPushButton("Settings")
        settings.clicked.connect(self.open_settings)
        layout.addWidget(settings)
        return sidebar

    def build_content(self) -> QWidget:
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(30, 26, 30, 24)
        layout.setSpacing(18)

        header = QHBoxLayout()
        title_box = QVBoxLayout()
        title = QLabel("Mr Apps")
        title.setObjectName("PageTitle")
        subtitle = QLabel(
            "Install your personal tools, required components, setup instructions, and fixes in one place."
        )
        subtitle.setObjectName("Subtle")
        subtitle.setWordWrap(True)
        title_box.addWidget(title)
        title_box.addWidget(subtitle)
        header.addLayout(title_box, 1)

        self.search = QLineEdit()
        self.search.setPlaceholderText("Search apps…")
        self.search.setFixedWidth(310)
        self.search.textChanged.connect(self.refresh_cards)
        header.addWidget(self.search)
        layout.addLayout(header)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.list_host = QWidget()
        self.list_host.setObjectName("ListHost")
        self.list_host.setStyleSheet("background: transparent;")
        self.scroll.viewport().setStyleSheet("background: transparent;")
        self.list_layout = QVBoxLayout(self.list_host)
        self.list_layout.setContentsMargins(0, 0, 8, 0)
        self.list_layout.setSpacing(14)
        self.scroll.setWidget(self.list_host)
        layout.addWidget(self.scroll, 1)

        footer = QLabel(
            "External software is never installed silently. MrInstaller shows the source, warnings, and asks first."
        )
        footer.setObjectName("Subtle")
        footer.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(footer)
        return container

    def bundled_package_sha256(self, app: AppEntry) -> str:
        archive = (self.project_root / app.archive).resolve()
        if not archive.exists():
            return ""
        stat = archive.stat()
        cached = self._package_hash_cache.get(app.app_id)
        fingerprint = (stat.st_size, stat.st_mtime_ns)
        if cached and cached[:2] == fingerprint:
            return cached[2]
        digest = sha256_file(archive)
        self._package_hash_cache[app.app_id] = (fingerprint[0], fingerprint[1], digest)
        return digest

    def app_update_available(self, app: AppEntry) -> bool:
        installed = self.state.installed_info(app.app_id)
        if not installed:
            return False
        installed_version = str(installed.get("version", "0"))
        installed_sha = str(installed.get("package_sha256", "")).lower()
        bundled_sha = self.bundled_package_sha256(app).lower()
        package_changed = bool(installed_sha and bundled_sha and installed_sha != bundled_sha)
        return is_newer(app.version, installed_version) or package_changed

    def set_filter(self, mode: str) -> None:
        self.filter_mode = mode
        self.nav_all.setChecked(mode == "all")
        self.nav_installed.setChecked(mode == "installed")
        self.nav_available.setChecked(mode == "available")
        self.refresh_cards()

    def clear_layout(self) -> None:
        while self.list_layout.count():
            item = self.list_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()

    def refresh_cards(self) -> None:
        self.clear_layout()
        self.cards.clear()
        query = self.search.text().strip().lower() if hasattr(self, "search") else ""

        visible_apps: list[AppEntry] = []
        for app in self.config.apps:
            installed = self.state.installed_info(app.app_id)
            if self.filter_mode == "installed" and not installed:
                continue
            if self.filter_mode == "available" and installed:
                continue
            haystack = f"{app.name} {app.description} {app.category} {tr(app.description)} {tr(app.category)}".lower()
            if query and query not in haystack:
                continue
            visible_apps.append(app)

        if not visible_apps:
            empty = QFrame()
            empty.setObjectName("Panel")
            empty.setMinimumHeight(320)
            empty_layout = QVBoxLayout(empty)
            empty_layout.setContentsMargins(32, 32, 32, 32)
            empty_layout.addStretch(1)

            icon = QLabel("＋")
            icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
            icon.setStyleSheet("font-size:42pt; color:#69738A;")
            empty_layout.addWidget(icon)

            title = QLabel(
                "No apps added yet"
                if not self.config.apps
                else "No apps match this view"
            )
            title.setObjectName("CardTitle")
            title.setAlignment(Qt.AlignmentFlag.AlignCenter)
            empty_layout.addWidget(title)

            text = QLabel(
                "Place app ZIP files in the packages folder, then add their details "
                "to installer_manifest.json. The hub will generate install controls "
                "and instructions automatically."
                if not self.config.apps
                else "Try another search or category."
            )
            text.setObjectName("Subtle")
            text.setWordWrap(True)
            text.setAlignment(Qt.AlignmentFlag.AlignCenter)
            text.setMaximumWidth(570)
            empty_layout.addWidget(text, alignment=Qt.AlignmentFlag.AlignCenter)

            open_manifest = QPushButton("Open project folder")
            open_manifest.clicked.connect(lambda: os.startfile(self.project_root))
            empty_layout.addWidget(
                open_manifest,
                alignment=Qt.AlignmentFlag.AlignCenter,
            )
            empty_layout.addStretch(1)
            self.list_layout.addWidget(empty)
        else:
            for app in visible_apps:
                card = AppCard(
                    app,
                    self.state.installed_info(app.app_id),
                    (self.project_root / app.icon) if app.icon else None,
                    self.bundled_package_sha256(app),
                )
                card.install_clicked.connect(self.begin_install)
                card.launch_clicked.connect(self.launch_app)
                card.details_clicked.connect(self.show_details)
                card.uninstall_clicked.connect(self.begin_uninstall)
                self.cards.append(card)
                self.list_layout.addWidget(card)

        self.list_layout.addStretch(1)

    def open_settings(self) -> None:
        dialog = SettingsDialog(self.config, self.state, self)
        dialog.exec()

    def show_details(self, app: AppEntry) -> None:
        dialog = InstructionDialog(
            app,
            bool(self.state.installed_info(app.app_id)),
            self.state,
            self,
        )
        dialog.dependency_requested.connect(self.review_dependency)
        dialog.exec()

    def begin_install(self, app: AppEntry) -> None:
        install_root = Path(
            str(
                self.state.get_setting(
                    "install_root",
                    str(self.config.expanded_install_root),
                )
            )
        )
        desktop = bool(
            self.state.get_setting(
                "desktop_shortcuts",
                self.config.settings.desktop_shortcuts_default,
            )
        )
        start_menu = bool(
            self.state.get_setting(
                "start_menu_shortcuts",
                self.config.settings.start_menu_shortcuts_default,
            )
        )

        installed_info = self.state.installed_info(app.app_id)
        updating = self.app_update_available(app)
        action_word = "Update" if updating else "Install"

        if updating:
            while self.service.is_app_running(app):
                box = QMessageBox(self)
                box.setIcon(QMessageBox.Icon.Warning)
                box.setWindowTitle(f"Close {app.name} before updating")
                box.setText(
                    f"{app.name} is currently open and has an update available.\n\n"
                    "Close the app before MrInstaller replaces its files."
                )
                retry = box.addButton("I closed it — retry", QMessageBox.ButtonRole.AcceptRole)
                box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
                box.exec()
                if box.clickedButton() is not retry:
                    return

        warnings: list[str] = []
        if app.instructions_before:
            warnings.append("Before installing:\n• " + "\n• ".join(app.instructions_before))
        if app.requires_admin:
            warnings.append("This app may require administrator permission.")
        if app.restart_required:
            warnings.append("A PC restart is required after installation.")
        if app.dependencies:
            warnings.append(
                "This app lists external required or recommended software. "
                "You can review each dependency from the Instructions page."
            )

        if warnings:
            choice = QMessageBox.question(
                self,
                f"{action_word} {app.name}?",
                "\n\n".join(warnings) + f"\n\nContinue with the app {action_word.lower()}?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if choice != QMessageBox.StandardButton.Yes:
                return

        worker = make_install_worker(
            self.service,
            app,
            install_root,
            desktop,
            start_menu,
        )
        progress_title = f"Updating {app.name}" if updating else f"Installing {app.name}"
        self.run_worker(worker, progress_title, lambda _result: self.install_done(app, updating))

    def install_done(self, app: AppEntry, updated: bool = False) -> None:
        self.refresh_cards()
        message = f"{app.name} was {'updated' if updated else 'installed'} successfully."
        if app.instructions_after:
            message += "\n\nNext steps:\n• " + "\n• ".join(app.instructions_after)
        if app.restart_required:
            message += "\n\nRestart your PC before using this app."
        QMessageBox.information(self, "Update complete" if updated else "Installation complete", message)

    def begin_uninstall(self, app: AppEntry) -> None:
        choice = QMessageBox.warning(
            self,
            f"Uninstall {app.name}?",
            f"This removes the installed app files and shortcuts.\n\n"
            f"Uninstall {app.name}?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if choice != QMessageBox.StandardButton.Yes:
            return

        worker = make_uninstall_worker(self.service, app)
        self.run_worker(worker, f"Uninstalling {app.name}", lambda _result: self.uninstall_done(app))

    def uninstall_done(self, app: AppEntry) -> None:
        self.refresh_cards()
        QMessageBox.information(self, "Uninstalled", f"{app.name} was removed.")

    def launch_app(self, app: AppEntry) -> None:
        if self.app_update_available(app):
            box = QMessageBox(self)
            box.setIcon(QMessageBox.Icon.Information)
            box.setWindowTitle(f"{app.name} update available")
            box.setText(
                f"An update is ready for {app.name}.\n\n"
                "Update it before opening the older installed version?"
            )
            update_button = box.addButton("Update now", QMessageBox.ButtonRole.AcceptRole)
            launch_button = box.addButton("Launch old version", QMessageBox.ButtonRole.DestructiveRole)
            box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
            box.exec()
            if box.clickedButton() is update_button:
                self.begin_install(app)
                return
            if box.clickedButton() is not launch_button:
                return
        try:
            self.service.launch_app(app)
        except Exception as exc:
            QMessageBox.critical(self, "Could not launch app", str(exc))

    def review_dependency(self, request: object) -> None:
        app: AppEntry | None = None
        dependency: ExternalDependency
        if (
            isinstance(request, tuple)
            and len(request) == 2
            and isinstance(request[0], AppEntry)
            and isinstance(request[1], ExternalDependency)
        ):
            app, dependency = request
        elif isinstance(request, ExternalDependency):
            dependency = request
        else:
            QMessageBox.warning(self, "Invalid component", "The selected component could not be read.")
            return

        if dependency.local_requirements_file:
            if app is None:
                QMessageBox.warning(self, "Invalid component", "The selected component is missing its app information.")
                return
            if not self.state.installed_info(app.app_id):
                QMessageBox.information(
                    self,
                    f"Install {app.name} first",
                    f"Install {app.name} before adding {dependency.name}.",
                )
                return
            if self.service.is_app_running(app):
                QMessageBox.warning(
                    self,
                    f"Close {app.name}",
                    f"Close {app.name} before installing {dependency.name}, then try again.",
                )
                return

            details = [
                f"MrStudio component: {dependency.name}",
                dependency.description,
            ]
            if dependency.instructions:
                details.append("Instructions:\n• " + "\n• ".join(dependency.instructions))
            details.append(
                "MrInstaller will use MrStudio's private Python environment and install "
                f"the packages listed in {dependency.local_requirements_file}."
            )
            choice = QMessageBox.question(
                self,
                f"Install {dependency.name}?",
                "\n\n".join(item for item in details if item)
                + "\n\nContinue? This may download large AI runtime files and can take several minutes.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if choice != QMessageBox.StandardButton.Yes:
                return
            worker = make_local_component_worker(self.service, app, dependency)
            self.run_worker(
                worker,
                f"Installing {dependency.name}",
                lambda _result: self.local_component_install_done(app, dependency),
            )
            return

        source = dependency.download_url or dependency.website_url or "No source configured"
        details = [
            f"External app: {dependency.name}",
            f"Source: {source}",
        ]
        if dependency.description:
            details.append(dependency.description)
        if dependency.instructions:
            details.append("Instructions:\n• " + "\n• ".join(dependency.instructions))
        if dependency.requires_admin:
            details.append("Windows may show an administrator permission prompt.")
        if dependency.download_url and not dependency.sha256:
            details.append("No fixed checksum is configured, so verify that the shown download address is the official publisher domain before continuing.")
        if dependency.restart_required:
            details.append("You must restart the PC after installing it.")
        details.append(
            "This software is not built into the hub. Continue only if you trust "
            "the publisher and source."
        )

        if dependency.winget_id:
            choice = QMessageBox.question(
                self,
                f"Install {dependency.name}?",
                "\n\n".join(details)
                + f"\n\nMrInstaller will ask Windows Package Manager to install package:\n{dependency.winget_id}\n\nContinue?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if choice != QMessageBox.StandardButton.Yes:
                return
            worker = make_winget_worker(self.service, dependency)
            self.run_worker(
                worker,
                f"Installing {dependency.name}",
                lambda _result: self.external_install_done(dependency),
            )
        elif dependency.download_url:
            choice = QMessageBox.question(
                self,
                f"Download {dependency.name}?",
                "\n\n".join(details) + "\n\nDownload this external installer?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if choice != QMessageBox.StandardButton.Yes:
                return
            worker = make_dependency_worker(self.service, dependency)
            self.run_worker(
                worker,
                f"Downloading {dependency.name}",
                lambda path: self.external_download_done(dependency, Path(path)),
            )
        elif dependency.website_url:
            choice = QMessageBox.question(
                self,
                f"Open {dependency.name} website?",
                "\n\n".join(details) + "\n\nOpen the official website?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if choice == QMessageBox.StandardButton.Yes:
                os.startfile(dependency.website_url)  # type: ignore[attr-defined]
        else:
            QMessageBox.warning(
                self,
                "No source configured",
                "This dependency does not have a download or website URL yet.",
            )

    def local_component_install_done(
        self,
        app: AppEntry,
        dependency: ExternalDependency,
    ) -> None:
        message = (
            f"{dependency.name} was installed successfully.\n\n"
            f"Restart {app.name} before using the tool."
        )
        if "Vocal" in dependency.name:
            message += "\n\nThe selected Demucs model downloads automatically the first time it is used."
        elif "Background" in dependency.name:
            message += "\n\nThe selected background-removal model downloads automatically the first time it is used."
        QMessageBox.information(self, "Component installed", message)

    def external_download_done(
        self,
        dependency: ExternalDependency,
        path: Path,
    ) -> None:
        choice = QMessageBox.question(
            self,
            f"Run {dependency.name} installer?",
            f"The installer was downloaded to:\n{path}\n\n"
            "Run it now? Windows may ask for permission.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if choice != QMessageBox.StandardButton.Yes:
            return
        worker = make_external_installer_worker(self.service, path, dependency)
        self.run_worker(
            worker,
            f"Installing {dependency.name}",
            lambda _result: self.external_install_done(dependency),
        )

    def external_install_done(self, dependency: ExternalDependency) -> None:
        message = f"{dependency.name} installer finished."
        if dependency.restart_required:
            message += "\n\nRestart your PC before continuing."
        QMessageBox.information(self, "External installer finished", message)

    def bundled_updates(self) -> list[tuple[AppEntry, str]]:
        updates: list[tuple[AppEntry, str]] = []
        for app in self.config.apps:
            installed = self.state.installed_info(app.app_id)
            if not installed:
                continue
            current = str(installed.get("version", "0"))
            installed_sha = str(installed.get("package_sha256", "")).lower()
            bundled_sha = self.bundled_package_sha256(app).lower()
            package_changed = bool(installed_sha and bundled_sha and installed_sha != bundled_sha)
            if is_newer(app.version, current) or package_changed:
                updates.append((app, current))
        return updates

    def show_bundled_update_popup(self) -> None:
        updates = self.bundled_updates()
        if not updates:
            return
        lines: list[str] = []
        running_names: list[str] = []
        for app, current in updates:
            is_running = self.service.is_app_running(app)
            suffix = " — currently open" if is_running else ""
            lines.append(f"• {app.name}: v{current} → v{app.version}{suffix}")
            if is_running:
                running_names.append(app.name)
                self._running_update_prompted.add(app.app_id)
        extra = ""
        if running_names:
            extra = (
                "\n\nClose the open app"
                + ("s" if len(running_names) != 1 else "")
                + " before updating: "
                + ", ".join(running_names)
                + "."
            )
        QMessageBox.information(
            self,
            "App updates are ready",
            "This MrInstaller package contains updates for:\n\n"
            + "\n".join(lines)
            + extra
            + "\n\nUse each app's Update button. Existing settings and app data are kept.",
        )

    def check_running_apps_with_updates(self) -> None:
        """Show one app-specific notice when an outdated app becomes open."""
        active_ids: set[str] = set()
        for app, current in self.bundled_updates():
            if not self.service.is_app_running(app):
                continue
            active_ids.add(app.app_id)
            if app.app_id in self._running_update_prompted:
                continue
            self._running_update_prompted.add(app.app_id)
            QMessageBox.information(
                self,
                f"{app.name} update ready",
                f"{app.name} is currently open and an update is available "
                f"(installed v{current}, bundled v{app.version}).\n\n"
                f"Close {app.name}, then click its Update button in MrInstaller.",
            )
        # Re-arm the notice after the app closes, so a later reopening of the old
        # version can be reported again during the same MrInstaller session.
        self._running_update_prompted.intersection_update(active_ids)

    def _set_update_check_ui(self, checking: bool) -> None:
        if self.update_button is None:
            return
        self.update_button.setEnabled(not checking)
        self.update_button.setText("Checking for updates…" if checking else "Check for updates")

    def _release_update_check(self, worker: TaskWorker, token: int) -> bool:
        """Release only the currently active check and ignore late stale results."""
        self._stale_update_workers.pop(id(worker), None)
        if self.update_check_worker is not worker or token != self._update_check_token:
            return False
        self.update_check_worker = None
        self._set_update_check_ui(False)
        return True

    def _expire_update_check(self, worker: TaskWorker, token: int, manual: bool) -> None:
        """Recover from a network/DNS call that never reports back to Qt."""
        if self.update_check_worker is not worker or token != self._update_check_token:
            return
        worker.cancel()
        self._stale_update_workers[id(worker)] = worker
        self.update_check_worker = None
        self._set_update_check_ui(False)
        logging.warning("Online update check exceeded the 25-second UI timeout.")
        if manual:
            QMessageBox.warning(
                self,
                "Update check timed out",
                "GitHub did not answer in time. Check your internet connection, "
                "firewall, VPN, or GitHub availability, then try again.",
            )

    def check_for_updates(self, manual: bool = True) -> None:
        github_url = self.config.settings.github_repository_url.strip()
        legacy_url = self.config.settings.update_manifest_url.strip()
        if not github_url and not legacy_url:
            if manual:
                QMessageBox.information(
                    self,
                    "Online updates are not configured",
                    "No GitHub repository or HTTPS update manifest is configured.",
                )
            return
        if self.update_check_worker is not None:
            if manual:
                QMessageBox.information(
                    self,
                    "Update check running",
                    "MrInstaller is already checking for updates. The button will "
                    "become available again when the check finishes.",
                )
            return

        if github_url:
            worker = make_github_update_check_worker(
                github_url,
                self.config.settings.github_update_branch,
                self.config.settings.github_update_file,
            )
        else:
            worker = make_update_check_worker(legacy_url)

        self._update_check_token += 1
        token = self._update_check_token
        self.update_check_worker = worker
        self._set_update_check_ui(True)

        def finished(payload: object) -> None:
            if not self._release_update_check(worker, token):
                return
            try:
                if not isinstance(payload, dict):
                    raise ValueError("The server returned invalid update information.")
                if payload.get("source") == "github_file":
                    self.handle_github_bundle_metadata(payload, manual)
                else:
                    self.handle_remote_update_manifest(payload, manual)
            except Exception as exc:
                logging.exception("Could not process online update information")
                if manual:
                    QMessageBox.warning(
                        self,
                        "Update check failed",
                        "MrInstaller received the update information but could not "
                        f"process it.\n\n{type(exc).__name__}: {exc}",
                    )

        def failed(message: str) -> None:
            if not self._release_update_check(worker, token):
                return
            clean_message = str(message).strip() or "An unknown network error occurred."
            logging.warning("Online update check failed: %s", clean_message)
            if manual:
                QMessageBox.warning(self, "Update check failed", clean_message)

        def cancelled() -> None:
            self._release_update_check(worker, token)

        worker.signals.finished.connect(finished)
        worker.signals.failed.connect(failed)
        worker.signals.cancelled.connect(cancelled)
        QTimer.singleShot(25_000, lambda: self._expire_update_check(worker, token, manual))
        self.thread_pool.start(worker)

    def handle_github_bundle_metadata(self, payload: dict, manual: bool) -> None:
        remote_sha = str(payload.get("sha", "")).strip().lower()
        if not remote_sha:
            if manual:
                QMessageBox.warning(self, "Update check failed", "GitHub did not return a file SHA.")
            return

        state_key = "github_update_bundle_sha"
        known_sha = str(self.state.get_setting(state_key, "")).strip().lower()

        # A newly installed MrInstaller build establishes the currently uploaded
        # ZIP as its baseline. Future replacements of that fixed ZIP change the
        # GitHub blob SHA and trigger the popup.
        if not known_sha:
            self.state.set_setting(state_key, remote_sha)
            if self.config.settings.hub_build_id:
                self.state.set_setting("active_hub_build_id", self.config.settings.hub_build_id)
            self.local_hub_build_changed = False
            if manual:
                QMessageBox.information(
                    self,
                    "Update channel connected",
                    "MrInstaller is now tracking the current GitHub ZIP. Replace "
                    f"{payload.get('path', 'MrInstaller-Latest.zip')} in the repository "
                    "to publish the next update.",
                )
            return

        if self.local_hub_build_changed:
            if remote_sha == known_sha:
                # The newly created local build has not replaced the repository ZIP
                # yet. Keep the previous active build ID so another launch can
                # establish the new baseline after it is uploaded.
                if manual:
                    QMessageBox.information(
                        self,
                        "Upload this build first",
                        "This local MrInstaller build is newer, but GitHub still has "
                        "the previously tracked ZIP. Upload and replace "
                        f"{payload.get('path', 'MrInstaller-Latest.zip')}, then check again.",
                    )
                return
            self.state.set_setting(state_key, remote_sha)
            if self.config.settings.hub_build_id:
                self.state.set_setting("active_hub_build_id", self.config.settings.hub_build_id)
            self.local_hub_build_changed = False
            if manual:
                QMessageBox.information(
                    self,
                    "New build registered",
                    "This MrInstaller build now matches the newly uploaded GitHub ZIP. "
                    "Future ZIP replacements will show an update popup.",
                )
            return

        if remote_sha == known_sha:
            if manual:
                QMessageBox.information(
                    self,
                    "No updates",
                    "The GitHub MrInstaller ZIP has not changed since this build was installed.",
                )
            return

        size_text = format_bytes(int(payload.get("size", 0) or 0))
        download_url = str(payload.get("download_url", "")).strip()
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Icon.Information)
        box.setWindowTitle("MrInstaller update available")
        box.setText(
            "The MrInstaller ZIP in your GitHub update repository has changed.\n\n"
            f"File: {payload.get('path', 'MrInstaller-Latest.zip')}\n"
            f"Download size: {size_text}"
        )
        box.setInformativeText(
            "MrInstaller can download this ZIP, safely replace its current program files, "
            "keep the existing private Python environment and settings, then restart itself. "
            "Installed Mr Apps are not removed; changed bundled apps will show Update buttons."
        )
        install_button = box.addButton("Update now", QMessageBox.ButtonRole.AcceptRole)
        box.addButton("Later", QMessageBox.ButtonRole.RejectRole)
        box.exec()
        if box.clickedButton() is install_button and download_url.lower().startswith("https://"):
            self.download_and_apply_github_update(payload)


    def download_and_apply_github_update(self, payload: dict) -> None:
        download_url = str(payload.get("download_url", "")).strip()
        remote_sha = str(payload.get("sha", "")).strip().lower()
        if not download_url.lower().startswith("https://") or not remote_sha:
            QMessageBox.warning(self, "Update failed", "GitHub did not provide a valid update download.")
            return

        worker = make_github_bundle_download_worker(download_url, remote_sha)

        def ready(result: object) -> None:
            try:
                bundle_path = Path(str(result))
                launch_in_place_updater(self.project_root, bundle_path, remote_sha)
            except Exception as exc:
                QMessageBox.critical(self, "Could not start updater", str(exc))
                return
            QMessageBox.information(
                self,
                "Applying update",
                "MrInstaller will close, replace its current files, preserve your settings and private environment, then restart automatically.",
            )
            app = QApplication.instance()
            if app is not None:
                app.quit()

        self.run_worker(worker, "Downloading MrInstaller update", ready)

    def handle_remote_update_manifest(self, payload: dict, manual: bool) -> None:
        remote_hub = payload.get("hub", {}) if isinstance(payload.get("hub", {}), dict) else {}
        remote_apps_raw = payload.get("apps", [])
        remote_apps = {
            str(item.get("id", "")): item
            for item in remote_apps_raw
            if isinstance(item, dict) and item.get("id")
        } if isinstance(remote_apps_raw, list) else {}

        items: list[str] = []
        hub_version = str(remote_hub.get("version", "0"))
        if is_newer(hub_version, self.config.settings.hub_version):
            items.append(f"MrInstaller: v{self.config.settings.hub_version} → v{hub_version}")

        for app in self.config.apps:
            installed = self.state.installed_info(app.app_id)
            remote = remote_apps.get(app.app_id)
            if not installed or not isinstance(remote, dict):
                continue
            installed_version = str(installed.get("version", "0"))
            remote_version = str(remote.get("version", "0"))
            # Do not duplicate the bundled-update popup. Online notification is
            # only needed when the server advertises something newer than this
            # MrInstaller folder already contains.
            if is_newer(remote_version, app.version) and is_newer(remote_version, installed_version):
                items.append(f"{app.name}: v{installed_version} → v{remote_version}")

        if not items:
            if manual:
                QMessageBox.information(self, "No updates", "MrInstaller and your installed Mr Apps are up to date.")
            return

        notes = remote_hub.get("notes", [])
        notes_text = ""
        if isinstance(notes, list) and notes:
            notes_text = "\n\nRelease notes:\n• " + "\n• ".join(str(note) for note in notes[:8])

        download_url = str(remote_hub.get("download_url") or payload.get("bundle_url") or "").strip()
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Icon.Information)
        box.setWindowTitle("Updates available")
        box.setText("New updates are available:\n\n• " + "\n• ".join(items) + notes_text)
        box.setInformativeText(
            "This legacy update channel provides a download link. GitHub-file updates can be applied in place automatically. "
            "The new bundle will show Update buttons for installed apps."
        )
        download_button = None
        if download_url.lower().startswith("https://"):
            download_button = box.addButton("Download update", QMessageBox.ButtonRole.AcceptRole)
        box.addButton("Later", QMessageBox.ButtonRole.RejectRole)
        box.exec()
        if download_button is not None and box.clickedButton() is download_button:
            QDesktopServices.openUrl(QUrl(download_url))

    def run_worker(
        self,
        worker: TaskWorker,
        title: str,
        on_success: Callable[[object], None],
    ) -> None:
        if self.active_worker is not None:
            QMessageBox.information(
                self,
                "Another task is running",
                "Finish or cancel the current task first.",
            )
            return

        self.active_worker = worker
        dialog = ProgressDialog(title, self)
        dialog.cancelled.connect(worker.cancel)
        worker.signals.progress.connect(dialog.update_progress)

        def finished(result: object) -> None:
            dialog.allow_close()
            self.active_worker = None
            on_success(result)

        def failed(message: str) -> None:
            dialog.allow_close()
            self.active_worker = None
            QMessageBox.critical(self, "Task failed", message)

        def cancelled() -> None:
            dialog.allow_close()
            self.active_worker = None
            QMessageBox.information(self, "Cancelled", "The task was cancelled safely.")

        worker.signals.finished.connect(finished)
        worker.signals.failed.connect(failed)
        worker.signals.cancelled.connect(cancelled)
        dialog.show()
        self.thread_pool.start(worker)
