from __future__ import annotations

from pathlib import Path
from threading import Event
from typing import Callable

from PySide6.QtCore import QObject, QRunnable, Signal, Slot

from .installer import InstallerService
from .models import AppEntry, ExternalDependency
from .updates import fetch_github_bundle_metadata, fetch_update_manifest


class WorkerSignals(QObject):
    progress = Signal(int, str)
    finished = Signal(object)
    failed = Signal(str)
    cancelled = Signal()


class TaskWorker(QRunnable):
    def __init__(self, task: Callable[[WorkerSignals, Event], object]) -> None:
        super().__init__()
        self.signals = WorkerSignals()
        self.cancel_event = Event()
        self.task = task
        self.setAutoDelete(True)

    @Slot()
    def run(self) -> None:
        try:
            result = self.task(self.signals, self.cancel_event)
            if self.cancel_event.is_set():
                self.signals.cancelled.emit()
            else:
                self.signals.finished.emit(result)
        except Exception as exc:
            if self.cancel_event.is_set():
                self.signals.cancelled.emit()
            else:
                self.signals.failed.emit(str(exc))

    def cancel(self) -> None:
        self.cancel_event.set()


def make_install_worker(service: InstallerService, app: AppEntry, install_root: Path, desktop_shortcut: bool, start_menu_shortcut: bool) -> TaskWorker:
    return TaskWorker(lambda signals, cancel: service.install_app(
        app, install_root, desktop_shortcut, start_menu_shortcut,
        lambda p, m: signals.progress.emit(p, m), cancel
    ))


def make_uninstall_worker(service: InstallerService, app: AppEntry) -> TaskWorker:
    def task(signals: WorkerSignals, cancel: Event) -> object:
        del cancel
        service.uninstall_app(app, lambda p, m: signals.progress.emit(p, m))
        return None
    return TaskWorker(task)


def make_dependency_worker(service: InstallerService, dependency: ExternalDependency) -> TaskWorker:
    return TaskWorker(lambda signals, cancel: service.download_dependency(
        dependency, lambda p, m: signals.progress.emit(p, m), cancel
    ))


def make_external_installer_worker(service: InstallerService, path: Path, dependency: ExternalDependency) -> TaskWorker:
    def task(signals: WorkerSignals, cancel: Event) -> object:
        service.run_external_installer(path, dependency, lambda p, m: signals.progress.emit(p, m), cancel)
        return None
    return TaskWorker(task)


def make_winget_worker(service: InstallerService, dependency: ExternalDependency) -> TaskWorker:
    def task(signals: WorkerSignals, cancel: Event) -> object:
        service.install_winget_dependency(dependency, lambda p, m: signals.progress.emit(p, m), cancel)
        return None
    return TaskWorker(task)


def make_update_check_worker(url: str) -> TaskWorker:
    def task(signals: WorkerSignals, cancel: Event) -> object:
        del signals, cancel
        return fetch_update_manifest(url)
    return TaskWorker(task)



def make_github_update_check_worker(
    repository_url: str,
    branch: str,
    file_path: str,
) -> TaskWorker:
    def task(signals: WorkerSignals, cancel: Event) -> object:
        del signals, cancel
        return fetch_github_bundle_metadata(repository_url, branch, file_path)
    return TaskWorker(task)
