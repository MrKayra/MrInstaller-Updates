from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any

from PySide6.QtCore import QEvent, QObject, QTimer
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QAbstractButton,
    QApplication,
    QComboBox,
    QDockWidget,
    QGroupBox,
    QLabel,
    QLineEdit,
    QMenu,
    QPlainTextEdit,
    QSystemTrayIcon,
    QTabWidget,
    QTableWidget,
    QListWidget,
    QTreeWidget,
    QSpinBox,
    QDoubleSpinBox,
    QProgressBar,
    QToolBox,
    QTextEdit,
    QWidget,
)

ENGLISH = "en"
TURKISH = "tr"
SUPPORTED_LANGUAGES = (ENGLISH, TURKISH)


def _state_path() -> Path:
    if os.name == "nt":
        base = Path(os.getenv("APPDATA", Path.home() / "AppData" / "Roaming"))
    else:
        base = Path(os.getenv("XDG_CONFIG_HOME", Path.home() / ".config"))
    return base / "MrInstaller" / "state.json"


def normalize_language(value: Any) -> str:
    text = str(value or "").strip().lower().replace("_", "-")
    if text in {"tr", "tr-tr", "turkish", "türkçe", "turkce"}:
        return TURKISH
    return ENGLISH


def load_language() -> str:
    path = _state_path()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return normalize_language(data.get("settings", {}).get("language", ENGLISH))
    except Exception:
        return ENGLISH


def language_name(code: str) -> str:
    return "Türkçe" if normalize_language(code) == TURKISH else "English"


# Exact translations for common interface text and the most visible app-specific text.
_EXACT_TR: dict[str, str] = {
    # Shared
    "English": "İngilizce",
    "Turkish": "Türkçe",
    "Language": "Dil",
    "Settings": "Ayarlar",
    "Save": "Kaydet",
    "Cancel": "İptal",
    "Close": "Kapat",
    "Exit": "Çıkış",
    "Quit": "Çık",
    "Apply": "Uygula",
    "OK": "Tamam",
    "Yes": "Evet",
    "No": "Hayır",
    "Browse": "Gözat",
    "Open": "Aç",
    "Add": "Ekle",
    "Remove": "Kaldır",
    "Delete": "Sil",
    "Edit": "Düzenle",
    "Start": "Başlat",
    "Stop": "Durdur",
    "Pause": "Duraklat",
    "Resume": "Devam Et",
    "Refresh": "Yenile",
    "Retry": "Yeniden Dene",
    "Search": "Ara",
    "Name": "Ad",
    "Type": "Tür",
    "Status": "Durum",
    "Progress": "İlerleme",
    "Ready": "Hazır",
    "Running": "Çalışıyor",
    "Finished": "Tamamlandı",
    "Completed": "Tamamlandı",
    "Failed": "Başarısız",
    "Error": "Hata",
    "Warning": "Uyarı",
    "Information": "Bilgi",
    "None": "Yok",
    "Default": "Varsayılan",
    "Enabled": "Etkin",
    "Disabled": "Devre Dışı",
    "Required": "Gerekli",
    "Optional": "İsteğe Bağlı",
    "Installed": "Yüklü",
    "Available": "Mevcut",
    "Update": "Güncelle",
    "Install": "Yükle",
    "Uninstall": "Kaldır",
    "Launch": "Başlat",
    "Instructions": "Talimatlar",
    "Tips": "İpuçları",
    "Before installation": "Yüklemeden önce",
    "After installation": "Yüklemeden sonra",
    "Dependencies": "Gerekli bileşenler",
    "Description": "Açıklama",
    "Category": "Kategori",
    "Version": "Sürüm",
    "File": "Dosya",
    "View": "Görünüm",
    "Help": "Yardım",
    "About": "Hakkında",
    "Home": "Ana Sayfa",
    "Audio": "Ses",
    "Video": "Video",
    "Image": "Görsel",
    "Utilities": "Araçlar",
    "Converter": "Dönüştürücü",
    "Output": "Çıktı",
    "Input": "Girdi",
    "Quality": "Kalite",
    "Format": "Biçim",
    "Folder": "Klasör",
    "Select file": "Dosya seç",
    "Select files": "Dosyaları seç",
    "Choose folder": "Klasör seç",
    "Open output folder": "Çıktı klasörünü aç",
    "Open export folder": "Dışa aktarma klasörünü aç",
    "Open project folder": "Proje klasörünü aç",
    "Processing Log": "İşlem Günlüğü",
    "Export Queue": "Dışa Aktarma Kuyruğu",
    "AI Tools": "Yapay Zekâ Araçları",
    "Video Studio": "Video Stüdyosu",
    "Audio Studio": "Ses Stüdyosu",
    "Image Studio": "Görsel Stüdyosu",
    "Utility Lab": "Araç Laboratuvarı",
    "Change settings": "Ayarları değiştir",
    "No description added yet.": "Henüz açıklama eklenmedi.",
    "No files selected.": "Dosya seçilmedi.",
    "No file selected": "Dosya seçilmedi",
    "Select an item first.": "Önce bir öğe seçin.",
    "Are you sure?": "Emin misiniz?",
    # MrInstaller
    "Installer Settings": "Yükleyici Ayarları",
    "Installer settings": "Yükleyici ayarları",
    "Interface language": "Arayüz dili",
    "English is used by default. This language is shared by MrInstaller and every Mr app.": "Varsayılan dil İngilizcedir. Bu dil MrInstaller ve tüm Mr uygulamaları tarafından ortak kullanılır.",
    "These settings control where apps are installed and which shortcuts are selected by default.": "Bu ayarlar uygulamaların nereye yükleneceğini ve varsayılan olarak hangi kısayolların seçileceğini belirler.",
    "Default installation folder": "Varsayılan yükleme klasörü",
    "Create desktop shortcuts by default": "Varsayılan olarak masaüstü kısayolları oluştur",
    "Create Start Menu shortcuts by default": "Varsayılan olarak Başlat Menüsü kısayolları oluştur",
    "Check online for updates when MrInstaller starts": "MrInstaller açıldığında çevrimiçi güncellemeleri denetle",
    "Choose installation folder": "Yükleme klasörünü seç",
    "Invalid folder": "Geçersiz klasör",
    "Choose an install folder.": "Bir yükleme klasörü seçin.",
    "All apps": "Tüm uygulamalar",
    "Check for updates": "Güncellemeleri denetle",
    "Checking for updates…": "Güncellemeler denetleniyor…",
    "Mr Apps": "Mr Uygulamaları",
    "Install your personal tools, required components, setup instructions, and fixes in one place.": "Kişisel araçlarınızı, gerekli bileşenleri, kurulum talimatlarını ve düzeltmeleri tek yerden yükleyin.",
    "Search apps…": "Uygulamalarda ara…",
    "Each app can include setup instructions, fixes, dependency installers, and restart warnings.": "Her uygulama kurulum talimatları, düzeltmeler, bileşen yükleyicileri ve yeniden başlatma uyarıları içerebilir.",
    "External software is never installed silently. MrInstaller shows the source, warnings, and asks first.": "Harici yazılımlar asla sessizce yüklenmez. MrInstaller kaynağı ve uyarıları gösterir, ardından onay ister.",
    "No apps added yet": "Henüz uygulama eklenmedi",
    "No apps match this view": "Bu görünüme uyan uygulama yok",
    "Try another search or category.": "Başka bir arama veya kategori deneyin.",
    "Update available": "Güncelleme mevcut",
    "Package changed": "Paket değişti",
    "Restart required": "Yeniden başlatma gerekli",
    "Install component": "Bileşeni yükle",
    "Open official website": "Resmî web sitesini aç",
    "Download and install": "İndir ve yükle",
    "Installation cancelled": "Yükleme iptal edildi",
    "Preparing installation": "Yükleme hazırlanıyor",
    "Creating shortcuts": "Kısayollar oluşturuluyor",
    "Removing files": "Dosyalar kaldırılıyor",
    "Updating installer state": "Yükleyici durumu güncelleniyor",
    "Creating a private app environment": "Özel uygulama ortamı oluşturuluyor",
    "Installing required app components": "Gerekli uygulama bileşenleri yükleniyor",
    "Connecting to download": "İndirmeye bağlanılıyor",
    "Download ready": "İndirme hazır",
    "Cancelling safely…": "Güvenli şekilde iptal ediliyor…",
    # MrDownloader
    "Available formats": "Mevcut biçimler",
    "yt-dlp, without the command line": "Komut satırı olmadan yt-dlp",
    "Checking FFmpeg…": "FFmpeg denetleniyor…",
    "Checking Deno…": "Deno denetleniyor…",
    "Downloads stay on this PC\nNo account • No cloud queue": "İndirmeler bu bilgisayarda kalır\nHesap yok • Bulut kuyruğu yok",
    "Download queue": "İndirme kuyruğu",
    "Paste one link per line, or paste an entire block of text. MrDownloader extracts every supported URL and can process several links at once.": "Her satıra bir bağlantı yapıştırın veya tüm metin bloğunu ekleyin. MrDownloader desteklenen URL'leri çıkarır ve birden fazla bağlantıyı aynı anda işleyebilir.",
    "Add links": "Bağlantı ekle",
    "Paste YouTube video, playlist, Shorts, music, or other yt-dlp-supported links here…": "YouTube videosu, oynatma listesi, Shorts, müzik veya yt-dlp destekli diğer bağlantıları buraya yapıştırın…",
    "Paste clipboard": "Panodan yapıştır",
    "Import .txt": ".txt içe aktar",
    "Inspect first link": "İlk bağlantıyı incele",
    "Add to queue": "Kuyruğa ekle",
    "Start queue": "Kuyruğu başlat",
    "Cancel selected": "Seçileni iptal et",
    "Clear finished": "Tamamlananları temizle",
    "These settings are copied into each new queue item. Existing active downloads keep the settings they started with.": "Bu ayarlar her yeni kuyruk öğesine kopyalanır. Etkin indirmeler başladıkları ayarları kullanmaya devam eder.",
    "Video + audio": "Video + ses",
    "Audio only": "Yalnızca ses",
    "Video only": "Yalnızca video",
    "Best available": "Mevcut en iyi",
    "Only the linked video": "Yalnızca bağlantıdaki video",
    "Playlist range": "Oynatma listesi aralığı",
    "Playlist folders": "Oynatma listesi klasörleri",
    "Download failed": "İndirme başarısız",
    "Cancelled by user": "Kullanıcı tarafından iptal edildi",
    "MrDownloader currently supports Windows 10 and Windows 11.": "MrDownloader şu anda Windows 10 ve Windows 11'i destekler.",
    # MrMacro
    "MrMacro currently supports Windows 10/11 only.": "MrMacro şu anda yalnızca Windows 10/11'i destekler.",
    "New Macro": "Yeni Makro",
    "Record": "Kaydet",
    "Play": "Oynat",
    "Emergency Stop": "Acil Durdurma",
    "Keyboard: Press Key": "Klavye: Tuşa Bas",
    "Keyboard: Key Down": "Klavye: Tuşu Basılı Tut",
    "Keyboard: Key Up": "Klavye: Tuşu Bırak",
    "Keyboard: Type Text": "Klavye: Metin Yaz",
    "Mouse: Move Absolute": "Fare: Mutlak Konuma Taşı",
    "Mouse: Recorded Path": "Fare: Kaydedilmiş Yol",
    "Mouse: Move Relative": "Fare: Göreli Taşı",
    "Mouse: Click": "Fare: Tıkla",
    "Mouse: Button Down": "Fare: Düğmeyi Basılı Tut",
    "Mouse: Button Up": "Fare: Düğmeyi Bırak",
    "Mouse: Scroll": "Fare: Kaydır",
    "Timing: Delay": "Zamanlama: Gecikme",
    "Condition: Wait for Pixel": "Koşul: Pikseli Bekle",
    "Condition: Wait for Image": "Koşul: Görseli Bekle",
    "Control: Loop Start": "Denetim: Döngü Başlangıcı",
    "Control: Loop End": "Denetim: Döngü Sonu",
    "Control: Comment": "Denetim: Yorum",
    "No input is sent": "Girdi gönderilmez",
    "Repeat block": "Bloğu tekrarla",
    "Return to nearest Loop Start": "En yakın Döngü Başlangıcına dön",
    "MrMacro crashed": "MrMacro çöktü",
    "An unexpected error occurred.": "Beklenmeyen bir hata oluştu.",
    # MrSoundboard
    "Audio routing needs attention": "Ses yönlendirmesi kontrol edilmeli",
    "Primary output": "Birincil çıkış",
    "Monitor output": "Dinleme çıkışı",
    "Microphone input": "Mikrofon girişi",
    "Soundboard": "Ses Paneli",
    "Add sound": "Ses ekle",
    "Live microphone": "Canlı mikrofon",
    "Mix my microphone into Primary output": "Mikrofonumu Birincil çıkışa karıştır",
    "Keep running in the system tray": "Sistem tepsisinde çalışmaya devam et",
    "Test audio routing": "Ses yönlendirmesini test et",
    "MrSoundboard failed to start": "MrSoundboard başlatılamadı",
    "MrSoundboard could not start.": "MrSoundboard başlatılamadı.",
    "No microphone inputs were found.": "Mikrofon girişi bulunamadı.",
    "Diagnostic failed:": "Tanılama başarısız:",
    "Saved recording:": "Kayıt kaydedildi:",
    "Press Enter to close...": "Kapatmak için Enter'a basın...",
    # MrStudio
    "LOCAL CREATIVE SUITE": "YEREL YARATICI PAKET",
    "Account-free": "Hesapsız",
    "Local": "Yerel",
    "Ready — processing stays local on this computer": "Hazır — işlemler bu bilgisayarda yerel olarak kalır",
    "Settings updated": "Ayarlar güncellendi",
    "About MrStudio": "MrStudio Hakkında",
    "MrStudio failed to start": "MrStudio başlatılamadı",
    "Opening image": "Görsel açılıyor",
    "Loading segmentation model": "Bölütleme modeli yükleniyor",
    "Saving transparent PNG": "Şeffaf PNG kaydediliyor",
    "Background removed": "Arka plan kaldırıldı",
    "Preparing vocal separation": "Vokal ayırma hazırlanıyor",
    "Vocal separation complete": "Vokal ayırma tamamlandı",
    "Loading separation model": "Ayırma modeli yükleniyor",
    "Collecting separated tracks": "Ayrılmış parçalar toplanıyor",
    "Separating vocals and music": "Vokal ve müzik ayrılıyor",
    "Vocal Remover": "Vokal Ayırıcı",
    "Background Remover": "Arka Plan Kaldırıcı",
    "Transparent PNG": "Şeffaf PNG",
    "Auto contrast": "Otomatik kontrast",
    "Top left": "Sol üst",
    "Top right": "Sağ üst",
    "Bottom left": "Sol alt",
    "Bottom right": "Sağ alt",
    "Open an image first.": "Önce bir görsel açın.",
    "No source image is loaded.": "Kaynak görsel yüklenmedi.",
    "File size:": "Dosya boyutu:",
    "Image info:": "Görsel bilgisi:",
    "EXIF fields:": "EXIF alanları:",
    # Additional MrDownloader interface text
    "No link": "Bağlantı yok",
    "Save to": "Kaydetme yeri",
    "Copy all": "Tümünü kopyala",
    "End item": "Öğeyi bitir",
    "No limit": "Sınır yok",
    "Clear log": "Günlüğü temizle",
    "Deno ready": "Deno hazır",
    "Start item": "Öğeyi başlat",
    "Audio codec": "Ses kodeği",
    "Video codec": "Video kodeği",
    "Speed / ETA": "Hız / Tahmini süre",
    "Title / URL": "Başlık / URL",
    "Activity log": "Etkinlik günlüğü",
    "Audio format": "Ses biçimi",
    "FFmpeg ready": "FFmpeg hazır",
    "Output files": "Çıktı dosyaları",
    "Download type": "İndirme türü",
    "Naming layout": "Adlandırma düzeni",
    "Save settings": "Ayarları kaydet",
    "Bitrate / note": "Bit hızı / not",
    "Embed chapters": "Bölümleri göm",
    "FFmpeg missing": "FFmpeg eksik",
    "Invalid format": "Geçersiz biçim",
    "No links found": "Bağlantı bulunamadı",
    "Queue is empty": "Kuyruk boş",
    "Settings saved": "Ayarlar kaydedildi",
    "What it can do": "Neler yapabilir",
    "Import URL list": "URL listesini içe aktar",
    "Use responsibly": "Sorumlu kullanın",
    "Video container": "Video kapsayıcısı",
    "Deno recommended": "Deno önerilir",
    "Invalid template": "Geçersiz şablon",
    "Unknown uploader": "Bilinmeyen yükleyici",
    "About MrDownloader": "MrDownloader Hakkında",
    "Choose cookies.txt": "cookies.txt dosyasını seç",
    "Format and quality": "Biçim ve kalite",
    "Or use cookies.txt": "Veya cookies.txt kullan",
    "Simultaneous links": "Eşzamanlı bağlantılar",
    "Fragments per video": "Video başına parçalar",
    "Required components": "Gerekli bileşenler",
    "Maximum video quality": "Maksimum video kalitesi",
    "Custom output template": "Özel çıktı şablonu",
    "Download full playlist": "Tüm oynatma listesini indir",
    "Finished successfully.": "Başarıyla tamamlandı.",
    "Audio bitrate / quality": "Ses bit hızı / kalitesi",
    "SponsorBlock categories": "SponsorBlock kategorileri",
    "Overwrite existing files": "Mevcut dosyaların üzerine yaz",
    "Read cookies from browser": "Tarayıcı çerezlerini oku",
    "Authentication and network": "Kimlik doğrulama ve ağ",
    "Performance and reliability": "Performans ve güvenilirlik",
    "Queue activity will appear here…": "Kuyruk etkinliği burada görünecek…",
    "New queue items will use these settings.": "Yeni kuyruk öğeleri bu ayarları kullanacak.",
    "Resume partial downloads when possible": "Mümkün olduğunda yarım indirmelere devam et",
    "Skip items already downloaded by MrDownloader": "MrDownloader tarafından daha önce indirilen öğeleri atla",
    "Use restricted ASCII-only filenames": "Yalnızca sınırlı ASCII dosya adları kullan",
    # Additional MrMacro interface text
    "New Macro": "Yeni Makro",
    "No hotkey": "Kısayol yok",
    "Play once": "Bir kez oynat",
    "Add Action": "Eylem Ekle",
    "Macro name": "Makro adı",
    "On timeout": "Zaman aşımında",
    "Button hold": "Düğme basılı tutma",
    "Click count": "Tıklama sayısı",
    "Ease in/out": "Yumuşak giriş/çıkış",
    "Mouse wheel": "Fare tekerleği",
    "App Settings": "Uygulama Ayarları",
    "Delete macro": "Makroyu sil",
    "Export macro": "Makroyu dışa aktar",
    "Motion curve": "Hareket eğrisi",
    "Mouse button": "Fare düğmesi",
    "Playing loop": "Döngü oynatılıyor",
    "Repeat count": "Tekrar sayısı",
    "Save Project": "Projeyi Kaydet",
    "Target color": "Hedef renk",
    "About MrMacro": "MrMacro Hakkında",
    "Global hotkey": "Genel kısayol",
    "Hold duration": "Basılı tutma süresi",
    "Import Macro…": "Makro İçe Aktar…",
    "Macro Options": "Makro Seçenekleri",
    "Mouse buttons": "Fare düğmeleri",
    "Play Selected": "Seçileni Oynat",
    "Record Toggle": "Kayıt Aç/Kapat",
    "Search region": "Arama bölgesi",
    "Behavior notes": "Davranış notları",
    "Emergency Stop": "Acil Durdurma",
    "Global hotkeys": "Genel kısayollar",
    "Mouse movement": "Fare hareketi",
    "Playing macro…": "Makro oynatılıyor…",
    "Press one key…": "Bir tuşa basın…",
    "Search macros…": "Makrolarda ara…",
    "Untitled Macro": "Adsız Makro",
    "Playback timing": "Oynatma zamanlaması",
    "Reference image": "Referans görsel",
    "Timeline Editor": "Zaman Çizelgesi Düzenleyicisi",
    "Add Macro Action": "Makro Eylemi Ekle",
    "Autosave failed:": "Otomatik kaydetme başarısız:",
    "Coordinate space": "Koordinat alanı",
    "Execution chance": "Çalıştırma olasılığı",
    "Macro validation": "Makro doğrulaması",
    "Open Data Folder": "Veri Klasörünü Aç",
    "Polish Recording": "Kaydı İyileştir",
    "Recording input…": "Girdi kaydediliyor…",
    "Speed multiplier": "Hız çarpanı",
    "Action is enabled": "Eylem etkin",
    "Edit Macro Action": "Makro Eylemini Düzenle",
    "Movement duration": "Hareket süresi",
    "Recovered Project": "Kurtarılan Proje",
    "Start Recording": "Kaydı Başlat",
    "Character interval": "Karakter aralığı",
    "Minimum confidence": "Minimum güven",
    "Recording controls": "Kayıt denetimleri",
    "Delay before action": "Eylem öncesi gecikme",
    "Play Selected Macro": "Seçili Makroyu Oynat",
    "Edit Selected Action": "Seçili Eylemi Düzenle",
    "Image wait timed out": "Görsel bekleme zaman aşımına uğradı",
    "Pixel wait timed out": "Piksel bekleme zaman aşımına uğradı",
    "Playback and binding": "Oynatma ve atama",
    "Toggle infinite loop": "Sonsuz döngüyü aç/kapat",
    "Delay before playback": "Oynatma öncesi gecikme",
    "Choose reference image": "Referans görsel seç",
    "Entire virtual desktop": "Tüm sanal masaüstü",
    "Start / stop recording": "Kaydı başlat / durdur",
    "The timeline is empty.": "Zaman çizelgesi boş.",
    "Additional delay jitter": "Ek gecikme sapması",
    "Mouse movement filtering": "Fare hareketi filtreleme",
    "Noise filtering distance": "Gürültü filtreleme mesafesi",
    "Target window (optional)": "Hedef pencere (isteğe bağlı)",
    "Loop count (0 = infinite)": "Döngü sayısı (0 = sonsuz)",
    "This macro has no actions.": "Bu makroda eylem yok.",
    "Repeat while hotkey is held": "Kısayol basılıyken tekrarla",
    "Use current cursor position": "Geçerli imleç konumunu kullan",
    "Stop recording before playback.": "Oynatmadan önce kaydı durdurun.",
    "Global safety and control hotkeys": "Genel güvenlik ve denetim kısayolları",
    "No timeline problems were detected.": "Zaman çizelgesinde sorun bulunmadı.",
    # Additional MrSoundboard interface text
    "Fade in": "Yavaşça aç",
    "Fade out": "Yavaşça kapat",
    "No data": "Veri yok",
    "New Sound": "Yeni Ses",
    "Add Sounds": "Sesler Ekle",
    "All Sounds": "Tüm Sesler",
    "Audio file": "Ses dosyası",
    "New profile": "Yeni profil",
    "New Profile": "Yeni Profil",
    "Add sounds": "Sesler ekle",
    "Audio output": "Ses çıkışı",
    "Button color": "Düğme rengi",
    "Choose Audio": "Ses Seç",
    "Delete sound": "Sesi sil",
    "Grid columns": "Izgara sütunları",
    "Input device": "Giriş aygıtı",
    "Missing file": "Dosya eksik",
    "Missing name": "Ad eksik",
    "Audio devices": "Ses aygıtları",
    "Button height": "Düğme yüksekliği",
    "Global hotkey": "Genel kısayol",
    "Profile name:": "Profil adı:",
    "Speed / pitch": "Hız / perde",
    "Stop and save": "Durdur ve kaydet",
    "Trim from end": "Sondan kırp",
    "Capture Hotkey": "Kısayolu Yakala",
    "Delete current": "Geçerliyi sil",
    "Delete profile": "Profili sil",
    "Export Profile": "Profili Dışa Aktar",
    "Import profile": "Profili içe aktar",
    "Import Profile": "Profili İçe Aktar",
    "Profile exists": "Profil mevcut",
    "Record a Sound": "Bir Ses Kaydet",
    "Rename current": "Geçerliyi yeniden adlandır",
    "Rename Profile": "Profili Yeniden Adlandır",
    "Reorder Sounds": "Sesleri Yeniden Sırala",
    "Search sounds…": "Seslerde ara…",
    "Sound Settings": "Ses Ayarları",
    "System default": "Sistem varsayılanı",
    "Play in reverse": "Tersten oynat",
    "Show audio file": "Ses dosyasını göster",
    "Start minimized": "Küçültülmüş başlat",
    "Start recording": "Kaydı başlat",
    "Stop all sounds": "Tüm sesleri durdur",
    "Stop this sound": "Bu sesi durdur",
    "Stop-all hotkey": "Tümünü durdurma kısayolu",
    "Trim from start": "Baştan kırp",
    "Microphone volume": "Mikrofon ses düzeyi",
    "Show MrSoundboard": "MrSoundboard'u Göster",
    "Soundboard volume": "Ses paneli ses düzeyi",
    "Loop until stopped": "Durdurulana kadar döngü",
    "Normalize peak volume": "Tepe ses düzeyini normalleştir",
    "Export portable bundle": "Taşınabilir paketi dışa aktar",
    "Give the sound a name.": "Sese bir ad verin.",
    "No audio was captured.": "Ses kaydedilmedi.",
    "Live microphone level": "Canlı mikrofon düzeyi",
    "Could not apply settings": "Ayarlar uygulanamadı",
    "Apply and test audio routing": "Ses yönlendirmesini uygula ve test et",
    "Keep window always on top": "Pencereyi her zaman üstte tut",
    "Confirm before deleting sounds": "Sesleri silmeden önce onay iste",
    "Profile exported successfully.": "Profil başarıyla dışa aktarıldı.",
    "Stop every playing sound first": "Önce çalan tüm sesleri durdurun",
    "Allow repeated triggers to overlap": "Tekrarlanan tetiklemelerin çakışmasına izin ver",
    "Drag rows to change the pad order.": "Ped sırasını değiştirmek için satırları sürükleyin.",
    "Enable soft limiter to prevent clipping": "Bozulmayı önlemek için yumuşak sınırlayıcıyı etkinleştir",
    "Drop audio files here or click “Add sounds”.": "Ses dosyalarını buraya bırakın veya “Sesler ekle”ye tıklayın.",
    "Changes speed and pitch together. 1.0 is original.": "Hız ve perdeyi birlikte değiştirir. 1.0 özgün değerdir.",
    "Speak into your microphone and confirm that the live level meter moves.": "Mikrofona konuşun ve canlı düzey göstergesinin hareket ettiğini doğrulayın.",
    # Additional MrStudio interface text
    "Save as": "Farklı kaydet",
    "Add text": "Metin ekle",
    "No files": "Dosya yok",
    "No image": "Görsel yok",
    "Add clips": "Klip ekle",
    "Add files": "Dosya ekle",
    "Font size": "Yazı tipi boyutu",
    "Gain (dB)": "Kazanç (dB)",
    "Max width": "Maksimum genişlik",
    "Move down": "Aşağı taşı",
    "Move up": "Yukarı taşı",
    "Not found": "Bulunamadı",
    "Safe copy": "Güvenli kopya",
    "Track row": "Parça satırı",
    "Video CRF": "Video CRF",
    "Add images": "Görsel ekle",
    "Add tracks": "Parça ekle",
    "Create PDF": "PDF Oluştur",
    "Frame rate": "Kare hızı",
    "Open image": "Görsel aç",
    "MP3 bitrate": "MP3 bit hızı",
    "Noise floor": "Gürültü tabanı",
    "PDF created": "PDF oluşturuldu",
    "Room reverb": "Oda yankısı",
    "Rotate 180°": "180° döndür",
    "Rotate left": "Sola döndür",
    "Rotate right": "Sağa döndür",
    "Sample rate": "Örnekleme hızı",
    "Audio edit": "Ses düzenleme",
    "Audio edit —": "Ses düzenleme —",
    "Image editor": "Görsel düzenleyici",
    "Image format": "Görsel biçimi",
    "Inspect file": "Dosyayı incele",
    "Load project": "Projeyi yükle",
    "Music volume": "Müzik ses düzeyi",
    "Peak limiter": "Tepe sınırlayıcı",
    "Quick editor": "Hızlı düzenleyici",
    "Remove audio": "Sesi kaldır",
    "Resize image": "Görseli yeniden boyutlandır",
    "Save project": "Projeyi kaydet",
    "Stroke width": "Çizgi kalınlığı",
    "Timeline row": "Zaman çizelgesi satırı",
    "Video edit": "Video düzenleme",
    "Video edit —": "Video düzenleme —",
    "Audio bitrate": "Ses bit hızı",
    "Choose output": "Çıktı seç",
    "Edge softness": "Kenar yumuşaklığı",
    "Export folder": "Dışa aktarma klasörü",
    "Flip vertical": "Dikey çevir",
    "Flip horizontal": "Yatay çevir",
    "Image batch": "Toplu görsel işlemi",
    "Image batch —": "Toplu görsel işlemi —",
    "Image quality": "Görsel kalitesi",
    "Images to PDF": "Görsellerden PDF",
    "Invalid color": "Geçersiz renk",
    "Output format": "Çıktı biçimi",
    "Parallel jobs": "Eşzamanlı işler",
    "Quality / CRF": "Kalite / CRF",
    "Reverb amount": "Yankı miktarı",
    "Reverse audio": "Sesi ters çevir",
    "Text position": "Metin konumu",
    "Burn subtitles": "Altyazıları videoya göm",
    "Clear finished": "Tamamlananları temizle",
    "Encoder preset": "Kodlayıcı ön ayarı",
    "External tools": "Harici araçlar",
    "Extract frames": "Kareleri çıkar",
    "File inspector": "Dosya inceleyici",
    "Final export": "Son dışa aktarma",
    "Final export —": "Son dışa aktarma —",
    "Missing output": "Çıktı eksik",
    "Missing source": "Kaynak eksik",
    "Quality shifts": "Kalite değişimleri",
    "Rendering clip": "Klip işleniyor",
    "Reset controls": "Denetimleri sıfırla",
    "Strip metadata": "Meta veriyi kaldır",
    "Add video clips": "Video klipleri ekle",
    "Apply watermark": "Filigran uygula",
    "Batch processor": "Toplu işlemci",
    "Detected FFmpeg": "FFmpeg algılandı",
    "Drop files here": "Dosyaları buraya bırakın",
    "Export behavior": "Dışa aktarma davranışı",
    "Export settings": "Dışa aktarma ayarları",
    "Frame extractor": "Kare çıkarıcı",
    "Image converted": "Görsel dönüştürüldü",
    "Image watermark": "Görsel filigranı",
    "No image loaded": "Görsel yüklenmedi",
    "One frame every": "Her şu aralıkta bir kare",
    "Remove selected": "Seçileni kaldır",
    "Render timeline": "Zaman çizelgesini işle",
    "Trim and timing": "Kırpma ve zamanlama",
    "Add audio tracks": "Ses parçaları ekle",
    "Background music": "Arka plan müziği",
    "Export audio mix": "Ses miksini dışa aktar",
    "Interactive crop": "Etkileşimli kırpma",
    "Invalid timeline": "Geçersiz zaman çizelgesi",
    "Metadata cleaner": "Meta veri temizleyici",
    "Metadata removed": "Meta veri kaldırıldı",
    "Multi-track mixer": "Çok parçalı mikser",
    "Refresh detection": "Algılamayı yenile",
    "Save edited image": "Düzenlenen görseli kaydet",
    "Source and output": "Kaynak ve çıktı",
    "Timing and motion": "Zamanlama ve hareket",
    "Watermark opacity": "Filigran saydamlığı",
    "Windows installer": "Windows yükleyicisi",
    "Apply adjustments": "Ayarlamaları uygula",
    "Applying overlays": "Katmanlar uygulanıyor",
    "Dynamic compressor": "Dinamik kompresör",
    "No output selected": "Çıktı seçilmedi",
    "Source and preview": "Kaynak ve önizleme",
    "Subtitle converted": "Altyazı dönüştürüldü",
    "Watermark position": "Filigran konumu",
    "Apply selected crop": "Seçili kırpmayı uygula",
    "Effects & mastering": "Efektler ve mastering",
    "Export edited video": "Düzenlenen videoyu dışa aktar",
    "FFT noise reduction": "FFT gürültü azaltma",
    "Installer not found": "Yükleyici bulunamadı",
    "Normalize final mix": "Son miksi normalleştir",
}


# _FULL_TR_EXTRA: sentence-level Turkish coverage for every bundled app.
_EXACT_TR.update({'Online JSON update channel configured.': 'Çevrimiçi JSON güncelleme kanalı yapılandırıldı.', 'Online update channel is not configured yet.': 'Çevrimiçi güncelleme kanalı henüz yapılandırılmadı.', 'External apps are never downloaded or opened silently. The hub will show the source, instructions, restart notice, and ask for confirmation.': 'Harici uygulamalar asla sessizce indirilmez veya açılmaz. Merkez; kaynağı, talimatları ve yeniden başlatma uyarısını gösterir, ardından onay ister.', 'Version': 'Sürüm', 'Before installing': 'Yüklemeden önce', 'After installing': 'Yüklemeden sonra', 'Tips and fixes': 'İpuçları ve düzeltmeler', 'Required or recommended components': 'Gerekli veya önerilen bileşenler', 'Preparing…': 'Hazırlanıyor…', 'Uninstalled': 'Kaldırıldı', 'Component installed': 'Bileşen yüklendi', 'External installer finished': 'Harici yükleyici tamamlandı', 'App updates are ready': 'Uygulama güncellemeleri hazır', 'Online update check exceeded the 25-second UI timeout.': 'Çevrimiçi güncelleme denetimi 25 saniyelik arayüz zaman aşımını geçti.', 'Updates available': 'Güncellemeler mevcut', 'No special instructions have been added for this app yet.': 'Bu uygulama için henüz özel talimat eklenmedi.', 'Update check timed out': 'Güncelleme denetimi zaman aşımına uğradı', 'GitHub did not answer in time. Check your internet connection, firewall, VPN, or GitHub availability, then try again.': "GitHub zamanında yanıt vermedi. İnternet bağlantınızı, güvenlik duvarını, VPN'i veya GitHub erişilebilirliğini denetleyip yeniden deneyin.", 'Update failed': 'Güncelleme başarısız', 'GitHub did not provide a valid update download.': 'GitHub geçerli bir güncelleme indirmesi sağlamadı.', 'Applying update': 'Güncelleme uygulanıyor', 'MrInstaller will close, replace its current files, preserve your settings and private environment, then restart automatically.': 'MrInstaller kapanacak, mevcut dosyalarını değiştirecek, ayarlarınızı ve özel ortamınızı koruyacak, ardından otomatik olarak yeniden başlayacak.', 'Another task is running': 'Başka bir görev çalışıyor', 'Finish or cancel the current task first.': 'Önce geçerli görevi tamamlayın veya iptal edin.', 'Cancelled': 'İptal edildi', 'The task was cancelled safely.': 'Görev güvenli biçimde iptal edildi.', 'Restart required after installation': 'Yüklemeden sonra yeniden başlatma gerekli', 'Invalid component': 'Geçersiz bileşen', 'The selected component could not be read.': 'Seçilen bileşen okunamadı.', 'The selected component is missing its app information.': 'Seçilen bileşenin uygulama bilgileri eksik.', 'Online updates are not configured': 'Çevrimiçi güncellemeler yapılandırılmadı', 'No GitHub repository or HTTPS update manifest is configured.': 'GitHub deposu veya HTTPS güncelleme bildirimi yapılandırılmamış.', 'Update check running': 'Güncelleme denetimi çalışıyor', 'MrInstaller is already checking for updates. The button will become available again when the check finishes.': 'MrInstaller zaten güncellemeleri denetliyor. Denetim bitince düğme yeniden kullanılabilir olacak.', 'Update check failed': 'Güncelleme denetimi başarısız', 'GitHub did not return a file SHA.': 'GitHub dosya SHA değerini döndürmedi.', 'Update channel connected': 'Güncelleme kanalı bağlandı', 'New build registered': 'Yeni yapı kaydedildi', 'No updates': 'Güncelleme yok', 'MrInstaller and your installed Mr Apps are up to date.': 'MrInstaller ve yüklü Mr uygulamalarınız güncel.', 'No source configured': 'Kaynak yapılandırılmadı', 'This dependency does not have a download or website URL yet.': 'Bu bağımlılık için henüz indirme veya web sitesi adresi yok.', 'Upload this build first': 'Önce bu yapıyı yükleyin', 'This MrInstaller build now matches the newly uploaded GitHub ZIP. Future ZIP replacements will show an update popup.': "Bu MrInstaller yapısı artık GitHub'a yeni yüklenen ZIP ile eşleşiyor. Bundan sonraki ZIP değişiklikleri bir güncelleme penceresi gösterecek.", 'The GitHub MrInstaller ZIP has not changed since this build was installed.': "GitHub'daki MrInstaller ZIP'i bu yapı yüklendiğinden beri değişmedi.", 'MrInstaller received the update information but could not process it.': 'MrInstaller güncelleme bilgisini aldı ancak işleyemedi.', 'MrInstaller could not apply the update:': 'MrInstaller güncellemeyi uygulayamadı:', 'Download update': 'Güncellemeyi indir', 'Update now': 'Şimdi güncelle', 'Later': 'Daha sonra', 'Downloading MrInstaller update': 'MrInstaller güncellemesi indiriliyor', 'Could not start updater': 'Güncelleyici başlatılamadı', 'Task failed': 'Görev başarısız', 'Download size': 'İndirme boyutu', 'Release notes': 'Sürüm notları', 'Container': 'Kapsayıcı', 'Resolution': 'Çözünürlük', 'Bitrate / note': 'Bit hızı / not', 'Use an exact yt-dlp format selector': 'Tam bir yt-dlp biçim seçicisi kullan', 'Example: 137+140 or bv*[height<=1080]+ba/b': 'Örnek: 137+140 veya bv*[height<=1080]+ba/b', 'Playlist downloads are expanded by yt-dlp inside the same queue job. Large playlists may take a long time.': 'Oynatma listesi indirmeleri aynı kuyruk görevi içinde yt-dlp tarafından genişletilir. Büyük oynatma listeleri uzun sürebilir.', 'Download creator-provided subtitles': 'İçerik üreticisinin sağladığı altyazıları indir', 'Also download automatic subtitles': 'Otomatik altyazıları da indir', 'Embed subtitles into video when supported': 'Destekleniyorsa altyazıları videoya göm', 'Embed thumbnail / cover art': 'Küçük resmi / kapak görselini göm', 'Embed title, artist, uploader and other metadata': 'Başlık, sanatçı, yükleyen ve diğer meta verileri göm', 'Save description as a text file': 'Açıklamayı metin dosyası olarak kaydet', 'Save full metadata as .info.json': 'Tüm meta verileri .info.json olarak kaydet', 'Remove selected SponsorBlock segments (can require re-encoding)': 'Seçili SponsorBlock bölümlerini kaldır (yeniden kodlama gerekebilir)', 'More simultaneous links and fragments can be faster, but they also use more bandwidth, CPU, disk and memory.': 'Daha fazla eşzamanlı bağlantı ve parça daha hızlı olabilir; ancak daha fazla bant genişliği, işlemci, disk ve bellek kullanır.', 'Optional: http://127.0.0.1:8080 or socks5://127.0.0.1:1080': 'İsteğe bağlı: http://127.0.0.1:8080 veya socks5://127.0.0.1:1080', 'Browser cookies are only read locally by yt-dlp. Close the selected browser if Windows prevents access to its cookie database.': 'Tarayıcı çerezleri yalnızca yerel olarak yt-dlp tarafından okunur. Windows çerez veritabanına erişimi engelliyorsa seçili tarayıcıyı kapatın.', 'Download one or many links, choose video or audio quality, process playlists, inspect available formats, use browser cookies, fetch subtitles, embed metadata and thumbnails, and keep a duplicate-prevention archive. yt-dlp supports YouTube and many other sites, although individual sites can change or break without notice.': "Bir veya birden fazla bağlantı indirin; video ya da ses kalitesini seçin, oynatma listelerini işleyin, mevcut biçimleri inceleyin, tarayıcı çerezlerini kullanın, altyazıları alın, meta verileri ve küçük resimleri gömün, ayrıca yinelenen indirmeleri önleyen bir arşiv tutun. yt-dlp YouTube'u ve birçok başka siteyi destekler; ancak siteler haber vermeden değişebilir veya bozulabilir.", 'FFmpeg is required for merging separate video/audio streams and most post-processing. Deno is strongly recommended for full modern YouTube format support. MrInstaller can install both after asking for permission.': 'Ayrı video ve ses akışlarını birleştirmek ve çoğu son işlem için FFmpeg gereklidir. Güncel YouTube biçimlerini tam desteklemek için Deno önemle önerilir. MrInstaller izin isteyerek ikisini de yükleyebilir.', "Only download media you own, that is public-domain or openly licensed, or that you otherwise have permission to save. MrDownloader does not bypass DRM, paywalls, private access controls, or platform permissions. You remain responsible for following the source site's terms and local law.": "Yalnızca size ait, kamu malı, açık lisanslı veya kaydetme izniniz bulunan medyaları indirin. MrDownloader DRM'i, ödeme duvarlarını, özel erişim denetimlerini veya platform izinlerini aşmaz. Kaynak sitenin koşullarına ve yerel yasalara uymak sizin sorumluluğunuzdadır.", 'yt-dlp format selector': 'yt-dlp biçim seçicisi', 'Choose a download folder.': 'Bir indirme klasörü seçin.', 'Enter a custom yt-dlp format selector or turn the custom selector off.': 'Özel bir yt-dlp biçim seçicisi girin veya özel seçiciyi kapatın.', 'Enter a custom output template or choose a preset.': 'Özel bir çıktı şablonu girin veya bir ön ayar seçin.', 'Paste at least one http:// or https:// link.': 'En az bir http:// veya https:// bağlantısı yapıştırın.', 'Add one or more links first.': 'Önce bir veya daha fazla bağlantı ekleyin.', 'Paste a link first.': 'Önce bir bağlantı yapıştırın.', 'Download full playlist': 'Tüm oynatma listesini indir', 'When a link contains a playlist': 'Bir bağlantı oynatma listesi içerdiğinde', 'Maximum video quality': 'En yüksek video kalitesi', 'Download type': 'İndirme türü', 'Video container': 'Video kapsayıcısı', 'Audio format': 'Ses biçimi', 'Audio quality': 'Ses kalitesi', 'Naming layout': 'Adlandırma düzeni', 'Custom format selector': 'Özel biçim seçicisi', 'Custom output template': 'Özel çıktı şablonu', 'Read cookies from browser': 'Tarayıcıdan çerezleri oku', 'No browser cookies': 'Tarayıcı çerezi kullanma', 'Concurrent fragments per video': 'Video başına eşzamanlı parça', 'Simultaneous links': 'Eşzamanlı bağlantılar', 'Retry attempts': 'Yeniden deneme sayısı', 'Rate limit': 'Hız sınırı', 'Proxy': 'Vekil sunucu', 'Subtitles and metadata': 'Altyazılar ve meta veriler', 'Performance and network': 'Performans ve ağ', 'Output and filenames': 'Çıktı ve dosya adları', 'Playlist behavior': 'Oynatma listesi davranışı', 'Queue activity will appear here…': 'Kuyruk etkinliği burada görünecek…', 'No links found': 'Bağlantı bulunamadı', 'Queue is empty': 'Kuyruk boş', 'No link': 'Bağlantı yok', 'Queued': 'Kuyrukta', 'Inspecting': 'İnceleniyor', 'Downloading': 'İndiriliyor', 'Merging': 'Birleştiriliyor', 'Post-processing': 'Son işlem yapılıyor', 'Done': 'Tamamlandı', 'Press one key…': 'Bir tuşa basın…', 'Action is enabled': 'Eylem etkin', 'Optional label or explanation': 'İsteğe bağlı etiket veya açıklama', 'Entire virtual desktop': 'Tüm sanal masaüstü', 'Foreground window (relative)': 'Ön plandaki pencere (göreli)', 'Choose target pixel color': 'Hedef piksel rengini seç', 'Use current cursor position': 'Geçerli imleç konumunu kullan', 'Move cursor before sending this action': 'Bu eylemi göndermeden önce imleci taşı', 'Stop macro with an error when the timeout expires': 'Zaman aşımı dolduğunda makroyu hatayla durdur', 'Leave width or height at 0 to search the entire virtual desktop.': 'Tüm sanal masaüstünde aramak için genişliği veya yüksekliği 0 bırakın.', 'Playback jumps back to the nearest unmatched Loop Start.': 'Oynatma, eşleşmemiş en yakın Döngü Başlangıcına geri döner.', 'Comments do not send input. Put the comment in the Note field above.': 'Yorumlar girdi göndermez. Yorumu yukarıdaki Not alanına yazın.', 'Recorder · editor · hotkey engine': 'Kaydedici · düzenleyici · kısayol motoru', "Uses standard Windows input. It does not bypass anti-cheat, secure input, or a game's rules.": 'Standart Windows girdisini kullanır. Hile korumasını, güvenli girdiyi veya oyun kurallarını aşmaz.', 'Macro': 'Makro', '■ Emergency Stop': '■ Acil Durdurma', 'Project autosaves to your Windows AppData folder.': 'Proje Windows AppData klasörünüze otomatik kaydedilir.', 'Make Window-Relative': 'Pencereye Göreli Yap', 'Validate': 'Doğrula', 'Follow playback': 'Oynatmayı takip et', 'On': 'Açık', '± Jitter': '± Sapma', 'Chance': 'Olasılık', 'Details': 'Ayrıntılar', 'Note': 'Not', 'Delay is the wait before each action. Jitter randomizes that delay. Chance can probabilistically skip an action. Use Loop Start/End for repeatable sections.': 'Gecikme, her eylemden önceki bekleme süresidir. Sapma bu gecikmeyi rastgele değiştirir. Olasılık, bir eylemi belirli bir ihtimalle atlayabilir. Tekrarlanabilir bölümler için Döngü Başlangıcı/Bitişi kullanın.', 'Identity': 'Kimlik', 'Ignore unrelated keys while the hotkey is held': 'Kısayol basılıyken ilgisiz tuşları yoksay', 'When enabled, a while-held macro keeps running while you press other keyboard keys, as long as every key in the macro hotkey remains physically held.': 'Etkinleştirildiğinde, makro kısayolundaki tüm tuşlar fiziksel olarak basılı kaldığı sürece başka klavye tuşlarına bassanız da basılı tutma makrosu çalışmaya devam eder.', 'Window-title text, for example: Roblox': 'Pencere başlığı metni, örneğin: Roblox', 'Use current foreground window': 'Geçerli ön plan penceresini kullan', 'Focus this window before playback': 'Oynatmadan önce bu pencereye odaklan', "Foreground-window-relative mouse actions use the active window's top-left corner. Focusing a named target first makes those actions portable when the window moves.": 'Ön plan penceresine göreli fare eylemleri etkin pencerenin sol üst köşesini kullanır. Önce adlandırılmış hedefe odaklanmak, pencere taşındığında bu eylemleri taşınabilir hâle getirir.', 'Behavior notes': 'Davranış notları', 'Capture': 'Yakala', '● Start Recording': '● Kaydı Başlat', '■ Stop Recording': '■ Kaydı Durdur', 'Recording stores separate key-down/key-up and mouse-down/mouse-up events, preserving holds and chords. Use Polish Recording afterward to convert simple button pairs into editable click actions.': "Kayıt; tuşa basma/bırakma ve fare düğmesine basma/bırakma olaylarını ayrı saklayarak basılı tutmaları ve tuş birleşimlerini korur. Basit düğme çiftlerini düzenlenebilir tıklama eylemlerine dönüştürmek için daha sonra Kaydı İyileştir'i kullanın.", 'Sources': 'Kaynaklar', 'Keyboard presses and releases': 'Klavye basma ve bırakmaları', 'Append to the current timeline instead of replacing it': 'Geçerli zaman çizelgesini değiştirmek yerine sonuna ekle', 'Compatibility': 'Uyumluluk', 'Switch to the target window…': 'Hedef pencereye geçin…', 'Switch to the target window now. Its title will be captured in 2.5 seconds.': 'Şimdi hedef pencereye geçin. Başlığı 2,5 saniye içinde yakalanacak.', 'Exported': 'Dışa aktarıldı', 'No different foreground window was detected. Try again and switch windows during the countdown.': 'Farklı bir ön plan penceresi algılanmadı. Yeniden deneyin ve geri sayım sırasında pencere değiştirin.', 'Another macro is already playing. Use Emergency Stop first.': "Başka bir makro zaten oynatılıyor. Önce Acil Durdurma'yı kullanın.", 'Playback stopped. Any held keys and mouse buttons were released.': 'Oynatma durdu. Basılı kalan tüm tuşlar ve fare düğmeleri bırakıldı.', 'Global hotkeys': 'Genel kısayollar', 'Mouse movement filtering': 'Fare hareketi filtreleme', 'Macro validation': 'Makro doğrulaması', 'Polish Recording': 'Kaydı İyileştir', 'New Macro': 'Yeni Makro', 'Press a key combination…': 'Bir tuş birleşimine basın…', 'Example: <ctrl>+<alt>+1': 'Örnek: <ctrl>+<alt>+1', 'App Settings': 'Uygulama Ayarları', 'No signal': 'Sinyal yok', 'Press Apply and test, then speak into your microphone.': "Uygula ve test et'e basın, ardından mikrofonunuza konuşun.", 'Voice-chat setup: Primary = CABLE Input, Monitor = your headphones, and Microphone input = your real microphone. Enable microphone mixing below. In Discord or the game, select CABLE Output as the input device. Your voice and soundboard will then be sent together, while only the soundboard is monitored in your headphones. Virtual-cable Primary outputs now receive a voice-chat-safe mono copy of every sound, preventing silent right-only or phase-cancelled clips. The app also scans every channel on stereo and multi-input microphones instead of assuming channel 1. Low-latency mode automatically prefers matching Windows WASAPI endpoints over DirectSound and drops stale microphone backlog, preventing the roughly half-second voice delay common with legacy audio backends.': "Sesli sohbet kurulumu: Birincil = CABLE Input, Dinleme = kulaklığınız ve Mikrofon girişi = gerçek mikrofonunuz olmalıdır. Aşağıdan mikrofon karıştırmayı etkinleştirin. Discord'da veya oyunda giriş aygıtı olarak CABLE Output'u seçin. Böylece sesiniz ve ses paneli birlikte gönderilir; kulaklığınızda yalnızca ses paneli dinlenir. Sanal kablonun Birincil çıkışları artık her sesi sesli sohbete uygun mono kopya olarak alır; böylece yalnızca sağ kanalda olan veya faz iptalli kliplerin sessiz kalması önlenir. Uygulama ayrıca stereo ve çok girişli mikrofonlarda yalnızca 1. kanalı varsaymak yerine tüm kanalları tarar. Düşük gecikme modu, DirectSound yerine eşleşen Windows WASAPI uç noktalarını otomatik olarak tercih eder ve eski mikrofon birikimini atarak eski ses altyapılarında görülen yaklaşık yarım saniyelik ses gecikmesini önler.", 'local • unlimited • yours': 'yerel • sınırsız • sizin', 'Profiles ▾': 'Profiller ▾', '+ Add sounds': '+ Ses ekle', 'Reorder': 'Yeniden sırala', '■ Stop all': '■ Tümünü durdur', 'CATEGORIES': 'KATEGORİLER', 'Drop audio files anywhere on the pad area. Right-click a pad for edit, duplicate, stop, or delete.': 'Ses dosyalarını ped alanının herhangi bir yerine bırakın. Düzenlemek, çoğaltmak, durdurmak veya silmek için bir pede sağ tıklayın.', 'Choose an existing audio file.': 'Mevcut bir ses dosyası seçin.', 'Enable microphone mixing to send your voice into the cable.': 'Sesinizi kabloya göndermek için mikrofon karıştırmayı etkinleştirin.', 'No microphone samples are arriving. Press Apply and test, then verify Windows microphone privacy and the selected real microphone.': "Mikrofon örneği gelmiyor. Uygula ve test et'e basın, ardından Windows mikrofon gizlilik ayarlarını ve seçili gerçek mikrofonu doğrulayın.", 'Capture is running, but the selected input is silent or muted.': 'Yakalama çalışıyor ancak seçili giriş sessiz veya susturulmuş.', 'Microphone detected. Your voice is being mixed into Primary output.': 'Mikrofon algılandı. Sesiniz Birincil çıkışa karıştırılıyor.', 'Audio routing active': 'Ses yönlendirmesi etkin', 'Playing': 'Oynatılıyor', 'Profile exists': 'Profil mevcut', 'A profile with that name already exists.': 'Bu ada sahip bir profil zaten var.', 'Cannot delete': 'Silinemez', 'At least one profile must remain.': 'En az bir profil kalmalıdır.', 'Still running in the tray. Your global hotkeys remain active.': 'Sistem tepsisinde çalışmaya devam ediyor. Genel kısayollarınız etkin kalır.', 'Could not list audio devices:': 'Ses aygıtları listelenemedi:', 'Hotkey error': 'Kısayol hatası', 'Playback failed': 'Oynatma başarısız', 'The profile loaded, but its saved output device is unavailable:': 'Profil yüklendi ancak kayıtlı çıkış aygıtı kullanılamıyor:', 'Using the system default instead.': 'Bunun yerine sistem varsayılanı kullanılıyor.', 'New Sound': 'Yeni Ses', 'General': 'Genel', 'All': 'Tümü', 'No Category': 'Kategorisiz', 'Account-free': 'Hesap gerektirmez', 'workspace': 'çalışma alanı', 'Source and destination': 'Kaynak ve hedef', 'Separation settings': 'Ayırma ayarları', 'HTDemucs — balanced quality': 'HTDemucs — dengeli kalite', 'HTDemucs Fine-Tuned — slower, cleaner': 'HTDemucs Fine-Tuned — daha yavaş, daha temiz', 'MDX Extra — alternate music model': 'MDX Extra — alternatif müzik modeli', 'Higher values can improve quality but multiply processing time.': 'Daha yüksek değerler kaliteyi artırabilir ancak işlem süresini katlar.', 'Auto': 'Otomatik', 'Export isolated vocals': 'Ayrılmış vokalleri dışa aktar', 'Export instrumental / no vocals': 'Enstrümantal / vokalsiz parçayı dışa aktar', 'Remove vocals / separate stems': 'Vokalleri kaldır / kanalları ayır', 'Removal settings': 'Kaldırma ayarları', 'U²-Net — general purpose': 'U²-Net — genel amaçlı', 'IS-Net General — detailed objects': 'IS-Net General — ayrıntılı nesneler', 'Human Segmentation — portraits': 'İnsan Bölütleme — portreler', 'IS-Net Anime — art and characters': 'IS-Net Anime — çizimler ve karakterler', 'Refine hair and soft edges with alpha matting': 'Saç ve yumuşak kenarları alfa matlaştırma ile iyileştir', 'Remove image background': 'Görsel arka planını kaldır', 'Ready — Demucs is installed locally.': 'Hazır — Demucs yerel olarak yüklü.', 'Optional component missing — install Demucs to enable this tool.': "İsteğe bağlı bileşen eksik — bu aracı etkinleştirmek için Demucs'u yükleyin.", 'Ready — rembg is installed locally.': 'Hazır — rembg yerel olarak yüklü.', 'Optional component missing — install rembg to enable this tool.': "İsteğe bağlı bileşen eksik — bu aracı etkinleştirmek için rembg'yi yükleyin.", 'Choose an audio or video file first.': 'Önce bir ses veya video dosyası seçin.', 'Choose an output folder.': 'Bir çıktı klasörü seçin.', 'Select vocals, instrumental, or both.': 'Vokali, enstrümantali veya ikisini birden seçin.', 'Choose an image first.': 'Önce bir görsel seçin.', 'Choose an output PNG file.': 'Bir çıktı PNG dosyası seçin.', 'Windows installer': 'Windows yükleyicisi', 'Source and preview': 'Kaynak ve önizleme', 'Export processed audio': 'İşlenmiş sesi dışa aktar', ' semitones': ' yarım ses', 'Levels and mastering': 'Düzeyler ve mastering', 'Loudness normalize to streaming-friendly level': 'Ses yüksekliğini yayın dostu düzeye normalleştir', 'Tone, EQ, and cleanup': 'Ton, EQ ve temizleme', 'Space and output': 'Ortam ve çıktı', 'Keep': 'Koru', 'Mixer incomplete': 'Mikser tamamlanmadı', 'Add at least one track and choose an output file.': 'En az bir parça ekleyin ve bir çıktı dosyası seçin.', 'Invalid mixer value': 'Geçersiz mikser değeri', 'Drop any supported files here. Mixed batches are allowed; incompatible items fail individually without stopping the rest.': 'Desteklenen dosyaları buraya bırakın. Karma toplu işlemlere izin verilir; uyumsuz öğeler diğerlerini durdurmadan ayrı ayrı başarısız olur.', 'Lower is better for H.264. 18–23 is a strong general range.': 'H.264 için daha düşük değer daha iyidir. 18–23 güçlü bir genel aralıktır.', 'Strip metadata from outputs': 'Çıktılardan meta veriyi kaldır', 'Preserve subfolders when possible': 'Mümkün olduğunda alt klasörleri koru', 'Queue conversion': 'Dönüştürmeyi kuyruğa ekle', 'Add at least one file to convert.': 'Dönüştürmek için en az bir dosya ekleyin.', 'Start creating': 'Oluşturmaya başla', 'Open a focused workspace. Every export is processed locally on your computer.': 'Odaklanmış bir çalışma alanı açın. Tüm dışa aktarma işlemleri bilgisayarınızda yerel olarak yapılır.', 'Open or drop an image to begin': 'Başlamak için bir görsel açın veya bırakın', 'Fit': 'Sığdır', 'Start crop selection': 'Kırpma seçimini başlat', 'Drag over the image after enabling crop mode.': 'Kırpma modunu etkinleştirdikten sonra görselin üzerinde sürükleyin.', 'Resize': 'Yeniden boyutlandır', 'Keep aspect ratio': 'En-boy oranını koru', 'Rotate and flip': 'Döndür ve çevir', 'Filters are applied as undoable edits. Some are intentionally strong so they remain useful for stylized work.': 'Filtreler geri alınabilir düzenlemeler olarak uygulanır. Bazıları stilize çalışmalar için yararlı kalması amacıyla bilerek güçlüdür.', 'Text': 'Metin', 'Caption, title, credit, or label': 'Açıklama, başlık, kaynak veya etiket', 'Center': 'Orta', '% of image width': "görsel genişliğinin %'si", 'Chroma key / color removal': 'Renk anahtarı / renk kaldırma', 'Pick': 'Seç', 'Remove selected color': 'Seçili rengi kaldır', 'Optional AI background removal': 'İsteğe bağlı yapay zekâ arka plan kaldırma', 'Runs locally after setup_optional_ai.bat installs rembg and its model runtime. The first use may initialize a model cache.': "setup_optional_ai.bat rembg'yi ve model çalışma zamanını yükledikten sonra yerel olarak çalışır. İlk kullanım model önbelleğini hazırlayabilir.", 'Remove background with AI': 'Arka planı yapay zekâ ile kaldır', 'Queue batch processing': 'Toplu işlemi kuyruğa ekle', 'Zoom': 'Yakınlaştırma', 'Missing watermark': 'Filigran eksik', 'Choose a watermark image first.': 'Önce bir filigran görseli seçin.', 'Enter a hex color such as #00ff00.': '#00ff00 gibi bir onaltılık renk girin.', 'Batch incomplete': 'Toplu işlem tamamlanmadı', 'Add images and choose an output folder.': 'Görseller ekleyin ve bir çıktı klasörü seçin.', "Leave paths blank to auto-detect installed tools from PATH, the app's bin folder, or standard Windows locations.": "Yüklü araçları PATH'ten, uygulamanın bin klasöründen veya standart Windows konumlarından otomatik algılamak için yolları boş bırakın.", 'Ask before overwriting from interactive editors': 'Etkileşimli düzenleyicilerde üzerine yazmadan önce sor', 'Open output location after a completed export': 'Dışa aktarma tamamlanınca çıktı konumunu aç', 'MrStudio settings were saved.': 'MrStudio ayarları kaydedildi.', 'Detailed stream, codec, duration, dimensions, bitrate, channel, and metadata information appears here.': 'Ayrıntılı akış, kodek, süre, boyut, bit hızı, kanal ve meta veri bilgileri burada görünür.', 'For a 30 FPS video, choose 33 ms to export approximately every frame. Large exports can create thousands of files.': '30 FPS bir videoda yaklaşık her kareyi dışa aktarmak için 33 ms seçin. Büyük dışa aktarımlar binlerce dosya oluşturabilir.', 'Create metadata-free copy': 'Meta verisiz kopya oluştur', 'Media streams are copied without re-encoding when possible. Images are safely re-saved without EXIF and ancillary metadata.': 'Mümkün olduğunda medya akışları yeniden kodlanmadan kopyalanır. Görseller EXIF ve yardımcı meta veriler olmadan güvenli biçimde yeniden kaydedilir.', 'Choose a file to inspect.': 'İncelemek için bir dosya seçin.', 'Extractor incomplete': 'Kare çıkarıcı tamamlanmadı', 'Choose a video and output folder.': 'Bir video ve çıktı klasörü seçin.', 'Cleaner incomplete': 'Temizleyici tamamlanmadı', 'Choose a source and safe-copy output path.': 'Bir kaynak ve güvenli kopya çıktı yolu seçin.', 'PDF incomplete': 'PDF işlemi tamamlanmadı', 'Add images and choose a PDF output path.': 'Görseller ekleyin ve bir PDF çıktı yolu seçin.', 'Transform and framing': 'Dönüşüm ve kadraj', 'Original': 'Orijinal', 'Flip horizontally': 'Yatay çevir', 'Flip vertically': 'Dikey çevir', 'Text, watermark, and subtitles': 'Metin, filigran ve altyazılar', 'Optional title or caption': 'İsteğe bağlı başlık veya açıklama', 'Top center': 'Üst orta', 'Bottom center': 'Alt orta', 'Clip': 'Klip', 'In (s)': 'Giriş (sn)', 'Out (s)': 'Çıkış (sn)', 'Fade (s)': 'Geçiş (sn)', 'Optional opening title shown for four seconds': 'Dört saniye gösterilen isteğe bağlı açılış başlığı', 'Editor incomplete': 'Düzenleyici tamamlanmadı', 'Choose a source video and output path.': 'Bir kaynak video ve çıktı yolu seçin.', 'Timeline incomplete': 'Zaman çizelgesi tamamlanmadı', 'Add at least one clip and choose an output path.': 'En az bir klip ekleyin ve bir çıktı yolu seçin.', 'Ready — processing stays local on this computer': 'Hazır — işlemler bu bilgisayarda yerel kalır', 'v1.3.0 · Account-free · Local': 'v1.3.0 · Hesap gerektirmez · Yerel', 'MrStudio failed to start': 'MrStudio başlatılamadı', 'Editing': 'Düzenleme', 'Automation': 'Otomasyon', 'Downloads': 'İndirmeler', 'A local editing suite with video, audio, images, conversions, vocal separation, background removal, metadata, subtitles, and file utilities.': 'Video, ses, görsel, dönüştürme, vokal ayırma, arka plan kaldırma, meta veri, altyazı ve dosya araçları içeren yerel bir düzenleme paketi.', 'A configurable Windows macro recorder with high-fidelity mouse paths, global hotkeys, playback, and precision timeline editing.': 'Yüksek doğruluklu fare yolları, genel kısayollar, oynatma ve hassas zaman çizelgesi düzenleme sunan yapılandırılabilir bir Windows makro kaydedici.', 'A configurable low-latency soundboard with global hotkeys, live microphone mixing, monitoring, recording, and voice-chat audio routing.': 'Genel kısayollar, canlı mikrofon karıştırma, dinleme, kayıt ve sesli sohbet yönlendirmesi sunan yapılandırılabilir, düşük gecikmeli bir ses paneli.', 'A high-configuration local YouTube and media downloader powered by yt-dlp, with multi-link queues, quality presets, playlists, subtitles, metadata, cookies, and format inspection.': 'yt-dlp destekli; çoklu bağlantı kuyrukları, kalite ön ayarları, oynatma listeleri, altyazılar, meta veriler, çerezler ve biçim inceleme özellikleri sunan gelişmiş yerel YouTube ve medya indiricisi.', 'The first installation needs an internet connection because MrInstaller creates a private environment and downloads the required Python components.': 'İlk yüklemede internet bağlantısı gerekir; çünkü MrInstaller özel bir ortam oluşturur ve gerekli Python bileşenlerini indirir.', 'The first installation needs internet access while MrInstaller downloads the private runtime components.': 'MrInstaller özel çalışma zamanı bileşenlerini indirirken ilk yüklemede internet erişimi gerekir.', 'The first installation needs internet access while MrInstaller downloads the required private audio components.': 'MrInstaller gerekli özel ses bileşenlerini indirirken ilk yüklemede internet erişimi gerekir.', 'The first installation needs internet access while MrInstaller creates a private Python environment and installs yt-dlp with its recommended Python components.': "MrInstaller özel bir Python ortamı oluşturup yt-dlp'yi önerilen Python bileşenleriyle yüklerken ilk yüklemede internet erişimi gerekir.", 'FFmpeg is required for audio, video, GIF, subtitle-burning, and most media conversion tools. Image-only tools can still work without it.': 'Ses, video, GIF, altyazı gömme ve çoğu medya dönüştürme aracı için FFmpeg gereklidir. Yalnızca görsel araçları onsuz da çalışabilir.', 'LibreOffice is optional and is only needed for Word, spreadsheet, presentation, EPUB, ODT, and similar document conversions.': 'LibreOffice isteğe bağlıdır ve yalnızca Word, elektronik tablo, sunum, EPUB, ODT ve benzeri belge dönüştürmeleri için gereklidir.', 'Keep enough free disk space for both source files and exported files; large video jobs may temporarily need several gigabytes.': 'Hem kaynak hem dışa aktarılan dosyalar için yeterli boş disk alanı bırakın; büyük video işleri geçici olarak birkaç gigabayt gerektirebilir.', 'Vocal Remover and AI Background Remover are optional local tools with larger model/runtime downloads; the normal editor works without them.': 'Vokal Ayırıcı ve Yapay Zekâ Arka Plan Kaldırıcı, daha büyük model/çalışma zamanı indirmeleri olan isteğe bağlı yerel araçlardır; normal düzenleyici bunlar olmadan çalışır.', 'Open Instructions and install FFmpeg for the complete media toolset.': "Eksiksiz medya araçları için Talimatlar'ı açıp FFmpeg'i yükleyin.", 'Restart MrStudio after installing FFmpeg or LibreOffice. If FFmpeg is still not detected, restart Windows or select ffmpeg.exe and ffprobe.exe manually in Settings.': "FFmpeg veya LibreOffice yükledikten sonra MrStudio'yu yeniden başlatın. FFmpeg hâlâ algılanmıyorsa Windows'u yeniden başlatın ya da Ayarlar'dan ffmpeg.exe ve ffprobe.exe dosyalarını elle seçin.", 'Use the Install component buttons in Instructions for Vocal Remover Components and Background Remover Components, then restart MrStudio.': "Talimatlar'daki Vokal Ayırıcı Bileşenleri ve Arka Plan Kaldırıcı Bileşenleri için Bileşeni yükle düğmelerini kullanın, ardından MrStudio'yu yeniden başlatın.", 'Use the Processing Log when an export fails; unsupported codecs and filters depend on the installed FFmpeg build.': "Dışa aktarma başarısız olduğunda İşlem Günlüğü'nü kullanın; desteklenmeyen kodekler ve filtreler yüklü FFmpeg yapısına bağlıdır.", 'Closing the launcher command window will not close MrStudio. The installed shortcut starts it through pythonw without a console.': "Başlatıcı komut penceresini kapatmak MrStudio'yu kapatmaz. Yüklü kısayol, uygulamayı konsol olmadan pythonw ile başlatır.", 'All editing is processed locally, but source files can still be overwritten when overwrite is explicitly enabled—keep backups of important originals.': 'Tüm düzenlemeler yerel olarak işlenir; ancak üzerine yazma özellikle etkinleştirilirse kaynak dosyaların üzerine yazılabilir. Önemli asılların yedeğini tutun.', 'All visible product branding and source package names now use MrStudio.': 'Görünen tüm ürün markaları ve kaynak paket adları artık MrStudio kullanır.', 'The AI Tools page keeps files local. Each selected background or vocal model downloads its model data the first time it is used.': 'Yapay Zekâ Araçları sayfası dosyaları yerel tutar. Seçilen her arka plan veya vokal modeli, ilk kullanımda model verisini indirir.', 'MrMacro currently supports Windows 10 and Windows 11.': "MrMacro şu anda Windows 10 ve Windows 11'i destekler.", 'Macros may violate a game or service rule even when they use normal Windows input APIs. Use automation only where it is permitted.': "Makrolar normal Windows girdi API'lerini kullansa bile bir oyunun veya hizmetin kurallarını ihlal edebilir. Otomasyonu yalnızca izin verilen yerlerde kullanın.", 'MrMacro cannot guarantee compatibility with protected games, raw-input games, exclusive input modes, or anti-cheat systems.': 'MrMacro korumalı oyunlar, ham girdi kullanan oyunlar, özel girdi modları veya hile koruma sistemleriyle uyumluluğu garanti edemez.', 'Set and test an emergency-stop hotkey before creating long, repeating, or infinite macros.': 'Uzun, tekrarlayan veya sonsuz makrolar oluşturmadan önce acil durdurma kısayolunu ayarlayıp test edin.', 'Test new macros in a harmless window before using them in an important application or game.': 'Yeni makroları önemli bir uygulama veya oyunda kullanmadan önce zararsız bir pencerede test edin.', 'Closing the launcher command window will not close MrMacro; the installed shortcut starts it as a detached GUI process.': "Başlatıcı komut penceresini kapatmak MrMacro'yu kapatmaz; yüklü kısayol onu bağımsız bir arayüz işlemi olarak başlatır.", 'To send both your real microphone and soundboard into Discord, Roblox, or another voice-chat app, install VB-CABLE and restart the PC before configuring routing.': "Gerçek mikrofonunuzu ve ses panelini Discord, Roblox veya başka bir sesli sohbet uygulamasına birlikte göndermek için VB-CABLE'ı yükleyin ve yönlendirmeyi ayarlamadan önce bilgisayarı yeniden başlatın.", 'Allow desktop apps to access your microphone in Windows Privacy & security settings.': 'Windows Gizlilik ve güvenlik ayarlarında masaüstü uygulamalarının mikrofonunuza erişmesine izin verin.', 'Primary output: choose CABLE Input (VB-Audio Virtual Cable).': 'Birincil çıkış: CABLE Input (VB-Audio Virtual Cable) seçin.', 'Monitor output: choose your real headphones or speakers so you can hear soundboard clips.': 'Dinleme çıkışı: ses paneli kliplerini duyabilmek için gerçek kulaklığınızı veya hoparlörlerinizi seçin.', 'Microphone input: choose your real physical microphone—not CABLE Output.': 'Mikrofon girişi: CABLE Output yerine gerçek fiziksel mikrofonunuzu seçin.', 'In Discord, Roblox, or the voice-chat app, choose CABLE Output as the input/microphone and keep its output on your real headphones.': "Discord, Roblox veya sesli sohbet uygulamasında giriş/mikrofon olarak CABLE Output'u seçin ve çıkışı gerçek kulaklığınızda bırakın.", 'Never select CABLE Output as MrSoundboard microphone input; that creates a cable feedback loop instead of capturing your real voice.': "MrSoundboard mikrofon girişi olarak asla CABLE Output'u seçmeyin; bu, gerçek sesinizi yakalamak yerine kablo geri besleme döngüsü oluşturur.", 'You cannot hear clips: set Monitor output to your real headphones or speakers.': 'Klipleri duyamıyorsanız Dinleme çıkışını gerçek kulaklığınıza veya hoparlörlerinize ayarlayın.', 'Closing the launcher command window does not close MrSoundboard; it is launched through pythonw as a detached GUI process.': "Başlatıcı komut penceresini kapatmak MrSoundboard'u kapatmaz; uygulama pythonw üzerinden bağımsız bir arayüz işlemi olarak başlatılır.", 'MrDownloader currently supports Windows 10 and Windows 11.': "MrDownloader şu anda Windows 10 ve Windows 11'i destekler.", 'Install FFmpeg for merging separate video and audio streams, MP3/audio extraction, thumbnails, subtitles, metadata, chapters, and SponsorBlock processing.': "Ayrı video ve ses akışlarını birleştirme, MP3/ses çıkarma, küçük resimler, altyazılar, meta veriler, bölümler ve SponsorBlock işlemleri için FFmpeg'i yükleyin.", 'Install Deno for full modern YouTube support. YouTube now uses JavaScript challenges that can hide formats or break downloads when no supported runtime is available.': "Güncel YouTube desteğinin tamamı için Deno'yu yükleyin. YouTube artık desteklenen bir çalışma zamanı olmadığında biçimleri gizleyebilen veya indirmeleri bozabilen JavaScript sınamaları kullanıyor.", 'Open Settings and choose the output folder, download type, maximum quality, container, naming layout, and playlist behavior.': "Ayarlar'ı açıp çıktı klasörünü, indirme türünü, en yüksek kaliteyi, kapsayıcıyı, adlandırma düzenini ve oynatma listesi davranışını seçin.", 'For several videos, paste one link per line or paste a block of text; MrDownloader extracts the links and queues them together.': 'Birden fazla video için her satıra bir bağlantı yapıştırın veya bir metin bloğu yapıştırın; MrDownloader bağlantıları çıkarıp birlikte kuyruğa ekler.', 'Use Inspect first link to view exact format IDs, codecs, resolutions, bitrates, and approximate sizes before downloading.': "İndirmeden önce tam biçim kimliklerini, kodekleri, çözünürlükleri, bit hızlarını ve yaklaşık boyutları görmek için İlk bağlantıyı incele'yi kullanın.", 'If FFmpeg or Deno was installed while MrDownloader was already open, close and reopen MrDownloader so every dependency is detected cleanly.': "FFmpeg veya Deno, MrDownloader açıkken yüklendiyse tüm bağımlılıkların temiz biçimde algılanması için MrDownloader'ı kapatıp yeniden açın.", 'Some sites change frequently. Keep MrDownloader updated through MrInstaller when extraction errors appear.': "Bazı siteler sık değişir. Çıkarma hataları oluştuğunda MrDownloader'ı MrInstaller üzerinden güncel tutun.", 'MrDownloader does not bypass DRM, paywalls, private permissions, or platform access controls.': "MrDownloader DRM'i, ödeme duvarlarını, özel izinleri veya platform erişim denetimlerini aşmaz.", 'Required for combining high-quality video and audio streams and for most post-processing features.': 'Yüksek kaliteli video ve ses akışlarını birleştirmek ve çoğu son işlem özelliği için gereklidir.', 'Strongly recommended for full YouTube support because yt-dlp uses it to solve current YouTube JavaScript challenges.': 'yt-dlp güncel YouTube JavaScript sınamalarını çözmek için kullandığından eksiksiz YouTube desteği için önemle önerilir.', 'MrStudio 1.3.0\n\nA professional local editing and conversion suite built with Python, Qt, Pillow, and FFmpeg. It does not require an account or upload your files to a website.\n\nFFmpeg and LibreOffice remain separate third-party tools under their respective licenses.': 'MrStudio 1.3.0\n\nPython, Qt, Pillow ve FFmpeg ile geliştirilmiş profesyonel bir yerel düzenleme ve dönüştürme paketidir. Hesap gerektirmez ve dosyalarınızı bir web sitesine yüklemez.\n\nFFmpeg ve LibreOffice, kendi lisansları kapsamındaki ayrı üçüncü taraf araçlar olarak kalır.', 'MrMacro 1.3\n\nA Windows macro recorder and timeline editor using standard SendInput playback.\n\nNo driver, injection, memory editing, input hiding, or anti-cheat bypass is included.': 'MrMacro 1.3\n\nStandart SendInput oynatmasını kullanan bir Windows makro kaydedici ve zaman çizelgesi düzenleyicisidir.\n\nSürücü, enjeksiyon, bellek düzenleme, girdi gizleme veya hile korumasını aşma özelliği içermez.'})


_REGEX_TR: list[tuple[re.Pattern[str], Any]] = [
    (re.compile(r"^Version (.+?)  •  (.+)$"), lambda m: f"Sürüm {m.group(1)}  •  {translate_text(m.group(2), TURKISH)}"),
    (re.compile(r"^Uninstall (.+)\?$"), lambda m: f"{m.group(1)} kaldırılsın mı?"),
    (re.compile(r"^This removes the installed app files and shortcuts\.\n\nUninstall (.+)\?$"), lambda m: f"Bu işlem yüklü uygulama dosyalarını ve kısayolları kaldırır.\n\n{m.group(1)} kaldırılsın mı?"),
    (re.compile(r"^(.+) was removed\.$"), lambda m: f"{m.group(1)} kaldırıldı."),
    (re.compile(r"^(.+) update available$"), lambda m: f"{m.group(1)} güncellemesi mevcut"),
    (re.compile(r"^An update is ready for (.+)\.\n\nUpdate it before opening the older installed version\?$"), lambda m: f"{m.group(1)} için bir güncelleme hazır.\n\nEski yüklü sürümü açmadan önce güncellensin mi?"),
    (re.compile(r"^Close (.+) before updating$"), lambda m: f"Güncellemeden önce {m.group(1)} uygulamasını kapatın"),
    (re.compile(r"^(.+) is currently open and has an update available\.\n\nClose the app before MrInstaller replaces its files\.$"), lambda m: f"{m.group(1)} şu anda açık ve bir güncellemesi var.\n\nMrInstaller dosyalarını değiştirmeden önce uygulamayı kapatın."),
    (re.compile(r"^Install (.+) first$"), lambda m: f"Önce {m.group(1)} yükleyin"),
    (re.compile(r"^Install (.+) before adding (.+)\.$"), lambda m: f"{m.group(2)} eklemeden önce {m.group(1)} yükleyin."),
    (re.compile(r"^Close (.+) before installing (.+), then try again\.$"), lambda m: f"{m.group(2)} yüklemeden önce {m.group(1)} uygulamasını kapatın, ardından yeniden deneyin."),
    (re.compile(r"^Save to (.+?)  •  Up to (.+?) simultaneous link\(s\)$"), lambda m: f"{m.group(1)} konumuna kaydet  •  En fazla {m.group(2)} eşzamanlı bağlantı"),
    (re.compile(r"^(.+?)  •  (.+?)  •  Use a format ID in Settings → Custom format selector when you need an exact stream\.$"), lambda m: f"{m.group(1)}  •  {m.group(2)}  •  Tam bir akış gerektiğinde Ayarlar → Özel biçim seçicisi bölümünde bir biçim kimliği kullanın."),
    (re.compile(r"^Playing: (.+)$"), lambda m: f"Oynatılıyor: {m.group(1)}"),
    (re.compile(r"^Added (\d+) sound\(s\)\. Right-click one to configure it\.$"), lambda m: f"{m.group(1)} ses eklendi. Yapılandırmak için birine sağ tıklayın."),
    (re.compile(r"^(\d+) shown • (\d+) total$"), lambda m: f"{m.group(1)} gösteriliyor • toplam {m.group(2)}"),
    (re.compile(r"^Captured target window: (.+)$"), lambda m: f"Hedef pencere yakalandı: {m.group(1)}"),
    (re.compile(r"^Converted (\d+) action\(s\) to target-window client coordinates\.$"), lambda m: f"{m.group(1)} eylem hedef pencerenin istemci koordinatlarına dönüştürüldü."),
    (re.compile(r"^Polished recording: converted (\d+) button pair\(s\) into click actions\.$"), lambda m: f"Kayıt iyileştirildi: {m.group(1)} düğme çifti tıklama eylemine dönüştürüldü."),
    (re.compile(r"^(\d+) timeline action(s?) · Autosave enabled$"), lambda m: f"{m.group(1)} zaman çizelgesi eylemi · Otomatik kaydetme etkin"),
    (re.compile(r"^Playing loop (\d+), action (\d+)$"), lambda m: f"Döngü {m.group(1)}, eylem {m.group(2)} oynatılıyor"),
    (re.compile(r"^Selected: left (\d+), top (\d+), right (\d+), bottom (\d+)$"), lambda m: f"Seçim: sol {m.group(1)}, üst {m.group(2)}, sağ {m.group(3)}, alt {m.group(4)}"),
    (re.compile(r"^The installer was downloaded to:\n(.+)\n\nRun it now\? Windows may ask for permission\.$", re.S), lambda m: f"Yükleyici şu konuma indirildi:\n{m.group(1)}\n\nŞimdi çalıştırılsın mı? Windows izin isteyebilir."),
    (re.compile(r"^The MrInstaller ZIP in your GitHub update repository has changed\.\n\nFile: (.+)\nDownload size: (.+)$", re.S), lambda m: f"GitHub güncelleme deponuzdaki MrInstaller ZIP'i değişti.\n\nDosya: {m.group(1)}\nİndirme boyutu: {m.group(2)}"),
    (re.compile(r"^(.+) is currently open and an update is available \(installed v(.+), bundled v(.+)\)\.\n\nClose (.+), then click its Update button in MrInstaller\.$", re.S), lambda m: f"{m.group(1)} şu anda açık ve bir güncelleme mevcut (yüklü v{m.group(2)}, paketteki v{m.group(3)}).\n\n{m.group(4)} uygulamasını kapatın, ardından MrInstaller'daki Güncelle düğmesine tıklayın."),
    (re.compile(r"^MrInstaller is now tracking the current GitHub ZIP\. Replace (.+) in the repository to publish the next update\.$"), lambda m: f"MrInstaller artık geçerli GitHub ZIP'ini izliyor. Sonraki güncellemeyi yayımlamak için depodaki {m.group(1)} dosyasını değiştirin."),
    (re.compile(r"^This local MrInstaller build is newer, but GitHub still has the previously tracked ZIP\. Upload and replace (.+), then check again\.$"), lambda m: f"Bu yerel MrInstaller yapısı daha yeni; ancak GitHub'da hâlâ daha önce izlenen ZIP var. {m.group(1)} dosyasını yükleyip değiştirin, ardından yeniden denetleyin."),
    (re.compile(r"^MrInstaller received the update information but could not process it\.\n\n(.+): (.+)$", re.S), lambda m: f"MrInstaller güncelleme bilgisini aldı ancak işleyemedi.\n\n{m.group(1)}: {m.group(2)}"),
    (re.compile(r"^(\d+) job\(s\) are still active\. Cancel them and exit\?$"), lambda m: f"{m.group(1)} iş hâlâ etkin. İptal edilip çıkılsın mı?"),
    (re.compile(r"^Delete profile “(.+)”\?\nAudio files are not deleted\.$", re.S), lambda m: f"“{m.group(1)}” profili silinsin mi?\nSes dosyaları silinmeyecek."),
    (re.compile(r"^Delete “(.+)” from this profile\?\nThe audio file itself will not be deleted\.$", re.S), lambda m: f"“{m.group(1)}” bu profilden silinsin mi?\nSes dosyasının kendisi silinmeyecek."),
    (re.compile(r"^The profile loaded, but its saved output device is unavailable:\n(.+)\n\nUsing the system default instead\.$", re.S), lambda m: f"Profil yüklendi ancak kayıtlı çıkış aygıtı kullanılamıyor:\n{m.group(1)}\n\nBunun yerine sistem varsayılanı kullanılıyor."),
    (re.compile(r"^Track row (\d+) has an invalid gain or delay\.$"), lambda m: f"{m.group(1)}. parça satırında geçersiz kazanç veya gecikme var."),
    (re.compile(r"^Run (.+) from the original MrStudio folder\.$"), lambda m: f"{m.group(1)} dosyasını özgün MrStudio klasöründen çalıştırın."),
    (re.compile(r"^This helper is a Windows batch file: (.+)$"), lambda m: f"Bu yardımcı bir Windows toplu iş dosyasıdır: {m.group(1)}"),
]

# _FULL_TR_AUDIT_FIXES
_EXACT_TR.update({'Could not inspect link': 'Bağlantı incelenemedi', 'Downloads are still running': 'İndirmeler hâlâ çalışıyor', 'Recorded high-fidelity path: {count} stored points, {duration} ms.\nThe path geometry is kept as one compact action. Delay, chance, enabled state, and note remain editable.': 'Yüksek doğruluklu kayıt yolu: {count} nokta, {duration} ms.\nYol geometrisi tek bir kompakt eylem olarak korunur. Gecikme, olasılık, etkinlik durumu ve not düzenlenebilir.', 'Play once uses the repeat count above. Toggle mode runs until the same hotkey, Stop button, or emergency hotkey is used. While-held mode stops as soon as the binding is released. Enable Ignore unrelated keys to keep it running while using other controls. Repeat count 0 means infinite.': 'Bir kez oynat, yukarıdaki tekrar sayısını kullanır. Aç/kapat modu aynı kısayol, Durdur düğmesi veya acil durum kısayolu kullanılana kadar çalışır. Basılı tutma modu, tuş birleşimi bırakılır bırakılmaz durur. Başka kontrolleri kullanırken çalışmayı sürdürmesi için İlgisiz tuşları yoksay seçeneğini etkinleştirin. Tekrar sayısı 0 sonsuz anlamına gelir.', 'MrMacro records complete timed mouse paths rather than only the newest point in each interval. Use 2–4 ms and 0–1 px for drawing-level accuracy. Continuous movement is stored as one compact action, so there is no fixed macro-action count limit and accurate paths do not flood the timeline.': 'MrMacro, her aralıktaki yalnızca en yeni noktayı değil, zamanlaması tamamlanmış fare yollarını kaydeder. Çizim düzeyinde doğruluk için 2–4 ms ve 0–1 px kullanın. Sürekli hareket tek bir kompakt eylem olarak saklanır; bu nedenle sabit bir makro eylemi sınırı yoktur ve doğru yollar zaman çizelgesini doldurmaz.', 'MrMacro uses the documented Windows SendInput API. Many normal desktop apps and games accept it, but protected or competitive games may block it. The app intentionally contains no driver, DLL injection, anti-cheat bypass, memory editing, or input hiding.': "MrMacro belgelenmiş Windows SendInput API'sini kullanır. Birçok normal masaüstü uygulaması ve oyun bunu kabul eder; ancak korumalı veya rekabetçi oyunlar engelleyebilir. Uygulama bilerek sürücü, DLL enjeksiyonu, hile korumasını aşma, bellek düzenleme veya girdi gizleme içermez.", 'Audio routing test failed': 'Ses yönlendirme testi başarısız', 'Exports are running': 'Dışa aktarımlar çalışıyor', "The first run downloads the selected model. CUDA requires a compatible NVIDIA setup; Auto safely falls back to CPU. Output files are named _vocals and _instrumental without Demucs' nested folders.": "İlk çalıştırmada seçili model indirilir. CUDA uyumlu bir NVIDIA kurulumu gerektirir; Otomatik seçeneği güvenli biçimde CPU'ya geri döner. Çıktı dosyaları Demucs'un iç içe klasörleri olmadan _vocals ve _instrumental adlarıyla oluşturulur.", 'The first use of each model downloads its local model file. Alpha matting is slower but can improve hair, fur, glass, and soft edge transparency.': 'Her modelin ilk kullanımında yerel model dosyası indirilir. Alfa matlaştırma daha yavaştır; ancak saç, kürk, cam ve yumuşak kenar saydamlığını iyileştirebilir.'})

# _FULL_TR_MANIFEST
_EXACT_TR.update({'Transparent PNG Background Removal is in AI Tools → Background Remover. If it shows “Optional component missing — install rembg to enable this tool,” run setup_background_remover.bat from the installed MrStudio folder, then restart MrStudio.': 'Şeffaf '
                                                                                                                                                                                                                                                      'PNG '
                                                                                                                                                                                                                                                      'Arka '
                                                                                                                                                                                                                                                      'Plan '
                                                                                                                                                                                                                                                      'Kaldırma '
                                                                                                                                                                                                                                                      'aracı, '
                                                                                                                                                                                                                                                      'Yapay '
                                                                                                                                                                                                                                                      'Zekâ '
                                                                                                                                                                                                                                                      'Araçları '
                                                                                                                                                                                                                                                      '→ '
                                                                                                                                                                                                                                                      'Arka '
                                                                                                                                                                                                                                                      'Plan '
                                                                                                                                                                                                                                                      'Kaldırıcı '
                                                                                                                                                                                                                                                      'bölümündedir. '
                                                                                                                                                                                                                                                      '“İsteğe '
                                                                                                                                                                                                                                                      'bağlı '
                                                                                                                                                                                                                                                      'bileşen '
                                                                                                                                                                                                                                                      'eksik '
                                                                                                                                                                                                                                                      '— '
                                                                                                                                                                                                                                                      'bu '
                                                                                                                                                                                                                                                      'aracı '
                                                                                                                                                                                                                                                      'etkinleştirmek '
                                                                                                                                                                                                                                                      'için '
                                                                                                                                                                                                                                                      'rembg’yi '
                                                                                                                                                                                                                                                      'yükleyin” '
                                                                                                                                                                                                                                                      'iletisi '
                                                                                                                                                                                                                                                      'görünürse '
                                                                                                                                                                                                                                                      'yüklü '
                                                                                                                                                                                                                                                      'MrStudio '
                                                                                                                                                                                                                                                      'klasöründeki '
                                                                                                                                                                                                                                                      'setup_background_remover.bat '
                                                                                                                                                                                                                                                      'dosyasını '
                                                                                                                                                                                                                                                      'çalıştırın, '
                                                                                                                                                                                                                                                      'ardından '
                                                                                                                                                                                                                                                      'MrStudio’yu '
                                                                                                                                                                                                                                                      'yeniden '
                                                                                                                                                                                                                                                      'başlatın.',
 'Vocal Remover is in AI Tools → Vocal Remover. If it shows the optional component message, run setup_vocal_remover.bat or setup_optional_ai.bat, then restart MrStudio.': 'Vokal '
                                                                                                                                                                           'Ayırıcı, '
                                                                                                                                                                           'Yapay '
                                                                                                                                                                           'Zekâ '
                                                                                                                                                                           'Araçları '
                                                                                                                                                                           '→ '
                                                                                                                                                                           'Vokal '
                                                                                                                                                                           'Ayırıcı '
                                                                                                                                                                           'bölümündedir. '
                                                                                                                                                                           'İsteğe '
                                                                                                                                                                           'bağlı '
                                                                                                                                                                           'bileşen '
                                                                                                                                                                           'iletisi '
                                                                                                                                                                           'görünürse '
                                                                                                                                                                           'setup_vocal_remover.bat '
                                                                                                                                                                           'veya '
                                                                                                                                                                           'setup_optional_ai.bat '
                                                                                                                                                                           'dosyasını '
                                                                                                                                                                           'çalıştırın, '
                                                                                                                                                                           'ardından '
                                                                                                                                                                           'MrStudio’yu '
                                                                                                                                                                           'yeniden '
                                                                                                                                                                           'başlatın.',
 'MP4/H.264/AAC, MP3, WAV, FLAC, PNG, JPEG, and WebP are the safest compatibility choices.': 'MP4/H.264/AAC, MP3, WAV, FLAC, PNG, JPEG ve WebP en güvenli uyumluluk '
                                                                                             'seçenekleridir.',
 'The Instructions panel now explicitly lists the Transparent PNG Background Removal tool and its rembg setup step.': 'Talimatlar panelinde artık Şeffaf PNG Arka Plan Kaldırma '
                                                                                                                      'aracı ve rembg kurulum adımı açıkça listelenir.',
 'Installs Demucs, PyTorch, and the other local packages required by MrStudio’s Vocal Remover.': 'MrStudio’nun Vokal Ayırıcısı için gereken Demucs, PyTorch ve diğer yerel '
                                                                                                 'paketleri yükler.',
 'Install MrStudio first, then use this button from MrStudio’s Instructions panel.': 'Önce MrStudio’yu yükleyin, ardından bu düğmeyi MrStudio’nun Talimatlar panelinden kullanın.',
 'The download can be large and may take several minutes, especially while PyTorch is being installed.': 'İndirme büyük olabilir ve özellikle PyTorch yüklenirken birkaç dakika '
                                                                                                         'sürebilir.',
 'Restart MrStudio after installation. The selected Demucs model downloads automatically on first use.': 'Yüklemeden sonra MrStudio’yu yeniden başlatın. Seçilen Demucs modeli ilk '
                                                                                                         'kullanımda otomatik olarak indirilir.',
 'Installs rembg, ONNX Runtime, and the other local packages required for Transparent PNG background removal.': 'Şeffaf PNG arka plan kaldırma için gereken rembg, ONNX Runtime ve '
                                                                                                                'diğer yerel paketleri yükler.',
 'The selected removal model downloads locally the first time it is used.': 'Seçilen kaldırma modeli ilk kullanımda yerel olarak indirilir.',
 'MrInstaller can install the Gyan.FFmpeg package through Windows Package Manager after you approve it.': 'Onayınızdan sonra MrInstaller, Gyan.FFmpeg paketini Windows Paket '
                                                                                                          'Yöneticisi üzerinden yükleyebilir.',
 'If Windows has not refreshed PATH, restart Windows or select the FFmpeg executables manually in MrStudio Settings.': 'Windows PATH değişkenini yenilemediyse Windows’u yeniden '
                                                                                                                       'başlatın veya MrStudio Ayarları’ndan FFmpeg '
                                                                                                                       'çalıştırılabilir dosyalarını elle seçin.',
 'Install LibreOffice only when document conversion is needed.': 'LibreOffice’i yalnızca belge dönüştürme gerektiğinde yükleyin.',
 'If it is not detected automatically, select LibreOffice program\\soffice.exe in MrStudio Settings.': 'Otomatik algılanmazsa MrStudio Ayarları’ndan LibreOffice '
                                                                                                       'program\\soffice.exe dosyasını seçin.',
 'For drawing-level mouse recording, use 2–4 ms Maximum time between path points and 0–1 px Noise filtering distance.': 'Çizim düzeyinde fare kaydı için Yol noktaları arasındaki '
                                                                                                                        'en uzun süre ayarını 2–4 ms, Gürültü filtreleme uzaklığı '
                                                                                                                        'ayarını 0–1 px olarak kullanın.',
 'For hold-to-spam macros, open Macro Options and enable Ignore unrelated keys while the hotkey is held if you need to use other controls at the same time.': 'Basılı tutarak '
                                                                                                                                                              'tekrarlayan '
                                                                                                                                                              'makrolarda, aynı '
                                                                                                                                                              'anda başka '
                                                                                                                                                              'kontrolleri '
                                                                                                                                                              'kullanmanız '
                                                                                                                                                              'gerekiyorsa Makro '
                                                                                                                                                              'Seçenekleri’ni açın '
                                                                                                                                                              've kısayol '
                                                                                                                                                              'basılıyken İlgisiz '
                                                                                                                                                              'tuşları yoksay '
                                                                                                                                                              'seçeneğini '
                                                                                                                                                              'etkinleştirin.',
 'Run MrMacro at the same privilege level as the target. When a target is running as administrator, MrMacro may also need to be started as administrator.': 'MrMacro’yu hedefle '
                                                                                                                                                            'aynı yetki düzeyinde '
                                                                                                                                                            'çalıştırın. Hedef '
                                                                                                                                                            'yönetici olarak '
                                                                                                                                                            'çalışıyorsa '
                                                                                                                                                            'MrMacro’nun da '
                                                                                                                                                            'yönetici olarak '
                                                                                                                                                            'başlatılması '
                                                                                                                                                            'gerekebilir.',
 'The old latest-position sampler was removed because it discarded curves and sharp turns. Playback now follows one high-resolution schedule so timing errors do not accumulate.': 'Eski '
                                                                                                                                                                                   'son-konum '
                                                                                                                                                                                   'örnekleyicisi, '
                                                                                                                                                                                   'eğrileri '
                                                                                                                                                                                   've '
                                                                                                                                                                                   'keskin '
                                                                                                                                                                                   'dönüşleri '
                                                                                                                                                                                   'kaybettiği '
                                                                                                                                                                                   'için '
                                                                                                                                                                                   'kaldırıldı. '
                                                                                                                                                                                   'Oynatma '
                                                                                                                                                                                   'artık '
                                                                                                                                                                                   'tek '
                                                                                                                                                                                   'bir '
                                                                                                                                                                                   'yüksek '
                                                                                                                                                                                   'çözünürlüklü '
                                                                                                                                                                                   'zamanlamayı '
                                                                                                                                                                                   'izler; '
                                                                                                                                                                                   'böylece '
                                                                                                                                                                                   'zamanlama '
                                                                                                                                                                                   'hataları '
                                                                                                                                                                                   'birikmez.',
 'There is no fixed macro-action count limit. Recorded paths can contain thousands of internal points without creating thousands of timeline rows.': 'Sabit bir makro eylemi '
                                                                                                                                                     'sayısı sınırı yoktur. '
                                                                                                                                                     'Kaydedilen yollar, binlerce '
                                                                                                                                                     'zaman çizelgesi satırı '
                                                                                                                                                     'oluşturmadan binlerce iç '
                                                                                                                                                     'nokta içerebilir.',
 'Use 2–4 ms and 0–1 px for drawing-level accuracy. Higher values reduce stored points but can reduce fine-detail accuracy.': 'Çizim düzeyinde doğruluk için 2–4 ms ve 0–1 px '
                                                                                                                              'kullanın. Daha yüksek değerler saklanan nokta '
                                                                                                                              'sayısını azaltır ancak ince ayrıntı doğruluğunu '
                                                                                                                              'düşürebilir.',
 'Existing 8 ms / 2 px default settings are automatically migrated to the new 4 ms / 0 px high-fidelity defaults.': 'Mevcut 8 ms / 2 px varsayılan ayarlar, yeni yüksek doğruluklu '
                                                                                                                    '4 ms / 0 px varsayılanlarına otomatik olarak geçirilir.',
 'While-held macros use physical-only trigger tracking, so the macro can send its own trigger key and unrelated keys can be pressed without stopping playback.': 'Basılı tutma '
                                                                                                                                                                 'makroları '
                                                                                                                                                                 'yalnızca '
                                                                                                                                                                 'fiziksel '
                                                                                                                                                                 'tetikleyiciyi '
                                                                                                                                                                 'izler. Böylece '
                                                                                                                                                                 'makro kendi '
                                                                                                                                                                 'tetikleyici '
                                                                                                                                                                 'tuşunu '
                                                                                                                                                                 'gönderebilir ve '
                                                                                                                                                                 'ilgisiz tuşlara '
                                                                                                                                                                 'basılması '
                                                                                                                                                                 'oynatmayı '
                                                                                                                                                                 'durdurmaz.',
 'Use combinations such as Ctrl+Shift+F8 when a single-key global hotkey conflicts with another program.': 'Tek tuşlu genel kısayol başka bir programla çakıştığında Ctrl+Shift+F8 '
                                                                                                           'gibi birleşimler kullanın.',
 'If a key or mouse button remains held after a crash, use the emergency stop or physically press and release that input once.': 'Bir çökmeden sonra tuş veya fare düğmesi basılı '
                                                                                                                                 'kalırsa acil durdurmayı kullanın ya da ilgili '
                                                                                                                                 'girdiye fiziksel olarak bir kez basıp bırakın.',
 'Repeat count 0 and loop count 0 mean infinite. Always keep the emergency stop available.': 'Tekrar sayısının veya döngü sayısının 0 olması sonsuz anlamına gelir. Acil '
                                                                                             'durdurmayı her zaman kullanılabilir tutun.',
 'Close other audio tools that have taken exclusive control of the microphone or output device if device tests fail.': 'Aygıt testleri başarısız olursa mikrofonun veya çıkış '
                                                                                                                       'aygıtının özel denetimini ele geçirmiş diğer ses '
                                                                                                                       'araçlarını kapatın.',
 'The v4 low-latency engine prefers Windows WASAPI endpoints. If a saved DirectSound/MME device is replaced automatically, test the route before voice chat.': 'v4 düşük gecikme '
                                                                                                                                                               'motoru Windows '
                                                                                                                                                               'WASAPI uç '
                                                                                                                                                               'noktalarını tercih '
                                                                                                                                                               'eder. Kayıtlı bir '
                                                                                                                                                               'DirectSound/MME '
                                                                                                                                                               'aygıtı otomatik '
                                                                                                                                                               'olarak '
                                                                                                                                                               'değiştirilirse '
                                                                                                                                                               'sesli sohbetten '
                                                                                                                                                               'önce yönlendirmeyi '
                                                                                                                                                               'test edin.',
 'Enable Mix my microphone into Primary output, start microphone volume at 1.00x, then click Apply and test audio routing.': 'Mikrofonumu Birincil çıkışa karıştır seçeneğini '
                                                                                                                             'etkinleştirin, mikrofon ses düzeyini 1,00x ile '
                                                                                                                             'başlatın, ardından Ses yönlendirmesini uygula ve '
                                                                                                                             'test et düğmesine tıklayın.',
 'Voice works but clips do not: verify MrSoundboard Primary output is CABLE Input and the voice-chat input is CABLE Output.': 'Sesiniz çalışıyor ancak klipler çalışmıyorsa '
                                                                                                                              'MrSoundboard Birincil çıkışının CABLE Input, sesli '
                                                                                                                              'sohbet girişinin ise CABLE Output olduğunu '
                                                                                                                              'doğrulayın.',
 'Clips work but voice does not: verify the real microphone is selected, microphone mixing is enabled, and the Live microphone level moves while speaking.': 'Klipler çalışıyor '
                                                                                                                                                             'ancak sesiniz '
                                                                                                                                                             'çalışmıyorsa gerçek '
                                                                                                                                                             'mikrofonun seçili, '
                                                                                                                                                             'mikrofon '
                                                                                                                                                             'karıştırmanın etkin '
                                                                                                                                                             've konuşurken Canlı '
                                                                                                                                                             'mikrofon düzeyinin '
                                                                                                                                                             'hareket ediyor '
                                                                                                                                                             'olduğunu doğrulayın.',
 'After installing, removing, or renaming an audio device, run reset_audio_settings.bat if saved routing prevents startup.': 'Bir ses aygıtını yükledikten, kaldırdıktan veya '
                                                                                                                             'yeniden adlandırdıktan sonra kayıtlı yönlendirme '
                                                                                                                             'açılışı engelliyorsa reset_audio_settings.bat '
                                                                                                                             'dosyasını çalıştırın.',
 'The Windows X button is enabled in this build. With Keep running in the system tray enabled, X hides the window while hotkeys continue; use Quit from the tray menu to exit fully.': 'Bu '
                                                                                                                                                                                       'yapıda '
                                                                                                                                                                                       'Windows '
                                                                                                                                                                                       'X '
                                                                                                                                                                                       'düğmesi '
                                                                                                                                                                                       'etkindir. '
                                                                                                                                                                                       'Sistem '
                                                                                                                                                                                       'tepsisinde '
                                                                                                                                                                                       'çalışmaya '
                                                                                                                                                                                       'devam '
                                                                                                                                                                                       'et '
                                                                                                                                                                                       'seçeneği '
                                                                                                                                                                                       'etkinken '
                                                                                                                                                                                       'X '
                                                                                                                                                                                       'pencereyi '
                                                                                                                                                                                       'gizler '
                                                                                                                                                                                       've '
                                                                                                                                                                                       'kısayollar '
                                                                                                                                                                                       'çalışmayı '
                                                                                                                                                                                       'sürdürür; '
                                                                                                                                                                                       'tamamen '
                                                                                                                                                                                       'çıkmak '
                                                                                                                                                                                       'için '
                                                                                                                                                                                       'tepsi '
                                                                                                                                                                                       'menüsündeki '
                                                                                                                                                                                       'Çık '
                                                                                                                                                                                       'seçeneğini '
                                                                                                                                                                                       'kullanın.',
 'For the lowest microphone delay, prefer the WASAPI version of your physical microphone and cable devices when Windows lists several entries with similar names.': 'En düşük '
                                                                                                                                                                    'mikrofon '
                                                                                                                                                                    'gecikmesi '
                                                                                                                                                                    'için Windows '
                                                                                                                                                                    'benzer adlara '
                                                                                                                                                                    'sahip birden '
                                                                                                                                                                    'fazla giriş '
                                                                                                                                                                    'listelediğinde '
                                                                                                                                                                    'fiziksel '
                                                                                                                                                                    'mikrofonunuzun '
                                                                                                                                                                    've kablo '
                                                                                                                                                                    'aygıtlarının '
                                                                                                                                                                    'WASAPI '
                                                                                                                                                                    'sürümünü '
                                                                                                                                                                    'tercih edin.',
 'All visible product branding and source package names now use MrSoundboard; the low-latency v4 engine and close-button fix are retained.': 'Görünen tüm ürün markaları ve kaynak '
                                                                                                                                             'paket adları artık MrSoundboard '
                                                                                                                                             'kullanır; düşük gecikmeli v4 motoru '
                                                                                                                                             've kapatma düğmesi düzeltmesi '
                                                                                                                                             'korunmuştur.',
 'A virtual Windows audio driver used to route MrSoundboard and your real microphone into one voice-chat input.': 'MrSoundboard’u ve gerçek mikrofonunuzu tek bir sesli sohbet '
                                                                                                                  'girişine yönlendirmek için kullanılan sanal Windows ses '
                                                                                                                  'sürücüsü.',
 'MrInstaller downloads the driver ZIP from the official VB-Audio domain only after you approve it.': 'MrInstaller, sürücü ZIP’ini yalnızca onayınızdan sonra resmî VB-Audio alan '
                                                                                                      'adından indirir.',
 'It extracts the package and starts the matching Windows setup program with administrator permission.': 'Paketi çıkarır ve eşleşen Windows kurulum programını yönetici izniyle '
                                                                                                         'başlatır.',
 'Complete the driver setup, then restart the PC. The restart is required before reliable routing setup.': 'Sürücü kurulumunu tamamlayın, ardından bilgisayarı yeniden başlatın. '
                                                                                                           'Güvenilir yönlendirme kurulumu için yeniden başlatma gereklidir.',
 'After restarting, follow the Primary output, Monitor output, Microphone input, and voice-chat input steps shown above.': 'Yeniden başlattıktan sonra yukarıda gösterilen '
                                                                                                                           'Birincil çıkış, Dinleme çıkışı, Mikrofon girişi ve '
                                                                                                                           'sesli sohbet girişi adımlarını izleyin.',
 'Only download media you own, that is openly licensed or public-domain, or that you otherwise have permission to save. Follow the source site rules and local law.': 'Yalnızca '
                                                                                                                                                                      'size ait, '
                                                                                                                                                                      'açık '
                                                                                                                                                                      'lisanslı, '
                                                                                                                                                                      'kamu malı '
                                                                                                                                                                      'veya '
                                                                                                                                                                      'kaydetme '
                                                                                                                                                                      'izniniz '
                                                                                                                                                                      'bulunan '
                                                                                                                                                                      'medyaları '
                                                                                                                                                                      'indirin. '
                                                                                                                                                                      'Kaynak '
                                                                                                                                                                      'sitenin '
                                                                                                                                                                      'kurallarına '
                                                                                                                                                                      've yerel '
                                                                                                                                                                      'yasalara '
                                                                                                                                                                      'uyun.',
 'When a video requires login or age verification, choose a supported browser under Read cookies from browser. Close that browser first if Windows locks its cookie database.': 'Bir '
                                                                                                                                                                                'video '
                                                                                                                                                                                'giriş '
                                                                                                                                                                                'veya '
                                                                                                                                                                                'yaş '
                                                                                                                                                                                'doğrulaması '
                                                                                                                                                                                'gerektiriyorsa '
                                                                                                                                                                                'Tarayıcıdan '
                                                                                                                                                                                'çerezleri '
                                                                                                                                                                                'oku '
                                                                                                                                                                                'bölümünden '
                                                                                                                                                                                'desteklenen '
                                                                                                                                                                                'bir '
                                                                                                                                                                                'tarayıcı '
                                                                                                                                                                                'seçin. '
                                                                                                                                                                                'Windows '
                                                                                                                                                                                'çerez '
                                                                                                                                                                                'veritabanını '
                                                                                                                                                                                'kilitliyorsa '
                                                                                                                                                                                'önce '
                                                                                                                                                                                'o '
                                                                                                                                                                                'tarayıcıyı '
                                                                                                                                                                                'kapatın.',
 'The exact yt-dlp format selector accepts combinations such as 137+140 or bv*[height<=1080]+ba/b.': 'Tam yt-dlp biçim seçicisi 137+140 veya bv*[height<=1080]+ba/b gibi '
                                                                                                     'birleşimleri kabul eder.',
 'Queue concurrency and fragment concurrency are separate: simultaneous links downloads several URLs at once, while fragments per video accelerates segmented streams.': 'Kuyruk '
                                                                                                                                                                         'eşzamanlılığı '
                                                                                                                                                                         've parça '
                                                                                                                                                                         'eşzamanlılığı '
                                                                                                                                                                         'ayrıdır: '
                                                                                                                                                                         'Eşzamanlı '
                                                                                                                                                                         'bağlantılar '
                                                                                                                                                                         'birden '
                                                                                                                                                                         'fazla '
                                                                                                                                                                         'URL’yi '
                                                                                                                                                                         'aynı '
                                                                                                                                                                         'anda '
                                                                                                                                                                         'indirirken '
                                                                                                                                                                         'video '
                                                                                                                                                                         'başına '
                                                                                                                                                                         'parçalar '
                                                                                                                                                                         'bölümlü '
                                                                                                                                                                         'akışları '
                                                                                                                                                                         'hızlandırır.',
 'The duplicate-prevention archive skips media MrDownloader already completed, even when the output file was later moved.': 'Yinelenenleri önleme arşivi, çıktı dosyası sonradan '
                                                                                                                            'taşınmış olsa bile MrDownloader’ın daha önce '
                                                                                                                            'tamamladığı medyaları atlar.',
 'Browser cookies are read locally by yt-dlp and are not uploaded by MrDownloader. Do not share exported cookies.txt files.': 'Tarayıcı çerezleri yt-dlp tarafından yerel olarak '
                                                                                                                              'okunur ve MrDownloader tarafından yüklenmez. Dışa '
                                                                                                                              'aktarılmış cookies.txt dosyalarını paylaşmayın.',
 'SponsorBlock removal can take longer and may require FFmpeg to cut or re-encode parts of the file.': 'SponsorBlock kaldırma daha uzun sürebilir ve dosyanın bazı bölümlerini '
                                                                                                       'kesmek veya yeniden kodlamak için FFmpeg gerektirebilir.',
 'Approve the FFmpeg installation through Windows Package Manager.': 'FFmpeg yüklemesini Windows Paket Yöneticisi üzerinden onaylayın.',
 'If detection still shows FFmpeg missing, restart Windows so the updated PATH is visible to desktop apps.': 'Algılama hâlâ FFmpeg’in eksik olduğunu gösteriyorsa güncellenen '
                                                                                                             'PATH’in masaüstü uygulamalarına görünmesi için Windows’u yeniden '
                                                                                                             'başlatın.',
 'Approve the Deno installation through Windows Package Manager.': 'Deno yüklemesini Windows Paket Yöneticisi üzerinden onaylayın.',
 'MrDownloader can pass the detected Deno executable path directly to yt-dlp, including WinGet installations that are not yet visible in PATH.': 'MrDownloader, PATH’te henüz '
                                                                                                                                                 'görünmeyen WinGet kurulumları '
                                                                                                                                                 'dâhil algılanan Deno '
                                                                                                                                                 'çalıştırılabilir dosya yolunu '
                                                                                                                                                 'doğrudan yt-dlp’ye iletebilir.'})

# _FULL_TR_LAST_STATIC
_EXACT_TR.update({'Cancelling…': 'İptal ediliyor…',
 'Stopping…': 'Durduruluyor…',
 'Media streams are copied without re-encoding when possible. Images are safely re-saved without EXIF and ancillary metadata.': 'Mümkün olduğunda medya '
                                                                                                                                'akışları yeniden kodlanmadan '
                                                                                                                                'kopyalanır. Görseller EXIF ve '
                                                                                                                                'yardımcı meta veriler olmadan '
                                                                                                                                'güvenli biçimde yeniden '
                                                                                                                                'kaydedilir.'})

# _FULL_TR_FINAL_AUDIT
_EXACT_TR.update({'Total rate limit per job': 'İş başına toplam hız sınırı',
 'Detailed yt-dlp messages, warnings and post-processing steps appear here. Passwords and browser cookie contents are never printed by MrDownloader.': 'Ayrıntılı '
                                                                                                                                                       'yt-dlp '
                                                                                                                                                       'iletileri, '
                                                                                                                                                       'uyarılar '
                                                                                                                                                       've son '
                                                                                                                                                       'işleme '
                                                                                                                                                       'adımları '
                                                                                                                                                       'burada '
                                                                                                                                                       'görünür. '
                                                                                                                                                       'Parolalar '
                                                                                                                                                       've '
                                                                                                                                                       'tarayıcı '
                                                                                                                                                       'çerezlerinin '
                                                                                                                                                       'içeriği '
                                                                                                                                                       'MrDownloader '
                                                                                                                                                       'tarafından '
                                                                                                                                                       'asla '
                                                                                                                                                       'yazdırılmaz.',
 '  •  Use a format ID in Settings → Custom format selector when you need an exact stream.': '  •  Tam bir akış gerektiğinde Ayarlar → Özel biçim seçicisi '
                                                                                             'bölümünde bir biçim kimliği kullanın.',
 'Install FFmpeg through MrInstaller for merging and conversions.': 'Birleştirme ve dönüştürme işlemleri için FFmpeg’i MrInstaller üzerinden yükleyin.',
 'Install Deno through MrInstaller for full YouTube format support.': 'Tam YouTube biçim desteği için Deno’yu MrInstaller üzerinden yükleyin.',
 'Invalid quality or format selection': 'Geçersiz kalite veya biçim seçimi',
 'Python 3.11 or newer was not found. Install Python, enable Add Python to PATH, then restart MrInstaller.': 'Python 3.11 veya daha yeni bir sürüm bulunamadı. '
                                                                                                             'Python’u yükleyin, “Python’u PATH’e ekle” '
                                                                                                             'seçeneğini etkinleştirin ve MrInstaller’ı '
                                                                                                             'yeniden başlatın.',
 'No local requirements file is configured for this component.': 'Bu bileşen için yerel bir gereksinim dosyası yapılandırılmamış.',
 'The configured component requirements path is unsafe.': 'Yapılandırılmış bileşen gereksinimleri yolu güvenli değil.',
 'External downloads must use HTTPS.': 'Harici indirmelerde HTTPS kullanılması gerekir.',
 'No installer executable was found inside the downloaded ZIP.': 'İndirilen ZIP dosyasının içinde bir yükleyici çalıştırılabilir dosyası bulunamadı.',
 'Extracting external installer': 'Harici yükleyici çıkarılıyor',
 "Windows Package Manager (winget) was not found. Open the dependency's official website instead.": 'Windows Paket Yöneticisi (winget) bulunamadı. Bunun '
                                                                                                    'yerine bağımlılığın resmî web sitesini açın.',
 'The downloaded file failed SHA-256 verification and was deleted.': 'İndirilen dosya SHA-256 doğrulamasından geçemedi ve silindi.',
 'The setup process timed out.': 'Kurulum işlemi zaman aşımına uğradı.',
 'Connecting to GitHub': 'GitHub’a bağlanılıyor',
 'Verifying the GitHub file': 'GitHub dosyası doğrulanıyor',
 'The GitHub update download must use HTTPS.': 'GitHub güncelleme indirmesinde HTTPS kullanılması gerekir.',
 'GitHub returned an invalid update SHA.': 'GitHub geçersiz bir güncelleme SHA değeri döndürdü.',
 "The downloaded ZIP does not match GitHub's file SHA. It was deleted for safety.": 'İndirilen ZIP, GitHub dosyasının SHA değeriyle eşleşmiyor. Güvenlik için '
                                                                                    'silindi.',
 'The update ZIP is unexpectedly large.': 'Güncelleme ZIP’i beklenmedik derecede büyük.',
 'This software is not built into the hub. Continue only if you trust the publisher and source.': 'Bu yazılım merkeze gömülü değildir. Yalnızca yayıncıya ve '
                                                                                                  'kaynağa güveniyorsanız devam edin.',
 'MrInstaller can download this ZIP, safely replace its current program files, keep the existing private Python environment and settings, then restart itself. Installed Mr Apps are not removed; changed bundled apps will show Update buttons.': 'MrInstaller '
                                                                                                                                                                                                                                                   'bu '
                                                                                                                                                                                                                                                   'ZIP’i '
                                                                                                                                                                                                                                                   'indirebilir, '
                                                                                                                                                                                                                                                   'mevcut '
                                                                                                                                                                                                                                                   'program '
                                                                                                                                                                                                                                                   'dosyalarını '
                                                                                                                                                                                                                                                   'güvenli '
                                                                                                                                                                                                                                                   'biçimde '
                                                                                                                                                                                                                                                   'değiştirebilir, '
                                                                                                                                                                                                                                                   'özel '
                                                                                                                                                                                                                                                   'Python '
                                                                                                                                                                                                                                                   'ortamını '
                                                                                                                                                                                                                                                   've '
                                                                                                                                                                                                                                                   'ayarları '
                                                                                                                                                                                                                                                   'koruyabilir, '
                                                                                                                                                                                                                                                   'ardından '
                                                                                                                                                                                                                                                   'kendini '
                                                                                                                                                                                                                                                   'yeniden '
                                                                                                                                                                                                                                                   'başlatabilir. '
                                                                                                                                                                                                                                                   'Yüklü '
                                                                                                                                                                                                                                                   'Mr '
                                                                                                                                                                                                                                                   'uygulamaları '
                                                                                                                                                                                                                                                   'kaldırılmaz; '
                                                                                                                                                                                                                                                   'pakette '
                                                                                                                                                                                                                                                   'değişen '
                                                                                                                                                                                                                                                   'uygulamalarda '
                                                                                                                                                                                                                                                   'Güncelle '
                                                                                                                                                                                                                                                   'düğmesi '
                                                                                                                                                                                                                                                   'görünür.',
 'This legacy update channel provides a download link. GitHub-file updates can be applied in place automatically. The new bundle will show Update buttons for installed apps.': 'Bu '
                                                                                                                                                                                'eski '
                                                                                                                                                                                'güncelleme '
                                                                                                                                                                                'kanalı '
                                                                                                                                                                                'bir '
                                                                                                                                                                                'indirme '
                                                                                                                                                                                'bağlantısı '
                                                                                                                                                                                'sağlar. '
                                                                                                                                                                                'GitHub '
                                                                                                                                                                                'dosya '
                                                                                                                                                                                'güncellemeleri '
                                                                                                                                                                                'otomatik '
                                                                                                                                                                                'olarak '
                                                                                                                                                                                'yerinde '
                                                                                                                                                                                'uygulanabilir. '
                                                                                                                                                                                'Yeni '
                                                                                                                                                                                'pakette, '
                                                                                                                                                                                'yüklü '
                                                                                                                                                                                'uygulamalar '
                                                                                                                                                                                'için '
                                                                                                                                                                                'Güncelle '
                                                                                                                                                                                'düğmeleri '
                                                                                                                                                                                'görünür.',
 'This app may require administrator permission.': 'Bu uygulama yönetici izni gerektirebilir.',
 'A PC restart is required after installation.': 'Yüklemeden sonra bilgisayarın yeniden başlatılması gerekir.',
 'This app lists external required or recommended software. You can review each dependency from the Instructions page.': 'Bu uygulama gerekli veya önerilen '
                                                                                                                         'harici yazılımları listeler. Her '
                                                                                                                         'bağımlılığı Talimatlar sayfasından '
                                                                                                                         'inceleyebilirsiniz.',
 'Windows may show an administrator permission prompt.': 'Windows bir yönetici izni istemi gösterebilir.',
 'No fixed checksum is configured, so verify that the shown download address is the official publisher domain before continuing.': 'Sabit bir sağlama toplamı '
                                                                                                                                   'yapılandırılmamış. Devam '
                                                                                                                                   'etmeden önce gösterilen '
                                                                                                                                   'indirme adresinin resmî '
                                                                                                                                   'yayıncı alan adına ait '
                                                                                                                                   'olduğunu doğrulayın.',
 'You must restart the PC after installing it.': 'Yükledikten sonra bilgisayarı yeniden başlatmanız gerekir.',
 '\n\nThe selected Demucs model downloads automatically the first time it is used.': '\n\nSeçilen Demucs modeli ilk kullanımda otomatik olarak indirilir.',
 '\n\nThe selected background-removal model downloads automatically the first time it is used.': '\n'
                                                                                                 '\n'
                                                                                                 'Seçilen arka plan kaldırma modeli ilk kullanımda otomatik '
                                                                                                 'olarak indirilir.',
 "\n\nUse each app's Update button. Existing settings and app data are kept.": '\n'
                                                                               '\n'
                                                                               'Her uygulamanın Güncelle düğmesini kullanın. Mevcut ayarlar ve uygulama '
                                                                               'verileri korunur.',
 'Review & install': 'İncele ve yükle',
 'Place app ZIP files in the packages folder, then add their details to installer_manifest.json. The hub will generate install controls and instructions automatically.': 'Uygulama '
                                                                                                                                                                          'ZIP '
                                                                                                                                                                          'dosyalarını '
                                                                                                                                                                          'packages '
                                                                                                                                                                          'klasörüne '
                                                                                                                                                                          'yerleştirin, '
                                                                                                                                                                          'ardından '
                                                                                                                                                                          'ayrıntılarını '
                                                                                                                                                                          'installer_manifest.json '
                                                                                                                                                                          'dosyasına '
                                                                                                                                                                          'ekleyin. '
                                                                                                                                                                          'Merkez, '
                                                                                                                                                                          'yükleme '
                                                                                                                                                                          'denetimlerini '
                                                                                                                                                                          've '
                                                                                                                                                                          'talimatları '
                                                                                                                                                                          'otomatik '
                                                                                                                                                                          'olarak '
                                                                                                                                                                          'oluşturur.',
 'The server returned invalid update information.': 'Sunucu geçersiz güncelleme bilgisi döndürdü.',
 'Could not process online update information': 'Çevrimiçi güncelleme bilgisi işlenemedi',
 '\n\nOpen the official website?': '\n\nResmî web sitesi açılsın mı?',
 'This MrInstaller package contains updates for:\n\n': 'Bu MrInstaller paketi şu uygulamaların güncellemelerini içeriyor:\n\n',
 'New updates are available:\n\n• ': 'Yeni güncellemeler mevcut:\n\n• ',
 'Non-Windows test run: restart skipped.': 'Windows dışı test çalıştırması: yeniden başlatma atlandı.',
 '\n\nSee %APPDATA%\\MrInstaller\\update.log for details.': '\n\nAyrıntılar için %APPDATA%\\MrInstaller\\update.log dosyasına bakın.',
 'The GitHub repository URL must look like https://github.com/OWNER/REPOSITORY': 'GitHub depo adresi https://github.com/SAHİP/DEPO biçiminde olmalıdır.',
 'The configured GitHub update file must be a ZIP file.': 'Yapılandırılmış GitHub güncelleme dosyası bir ZIP dosyası olmalıdır.',
 'GitHub returned unexpectedly large metadata.': 'GitHub beklenmedik derecede büyük meta veri döndürdü.',
 'GitHub did not return update-file metadata.': 'GitHub güncelleme dosyasının meta verilerini döndürmedi.',
 'GitHub returned an invalid file SHA.': 'GitHub geçersiz bir dosya SHA değeri döndürdü.',
 'GitHub did not provide a secure ZIP download URL.': 'GitHub güvenli bir ZIP indirme adresi sağlamadı.',
 'No update-manifest URL is configured.': 'Güncelleme bildirimi adresi yapılandırılmamış.',
 'The update-manifest URL must use HTTPS.': 'Güncelleme bildirimi adresinde HTTPS kullanılması gerekir.',
 'The update manifest must contain a JSON object.': 'Güncelleme bildirimi bir JSON nesnesi içermelidir.',
 'This MrInstaller build does not support that update-manifest schema.': 'Bu MrInstaller yapısı söz konusu güncelleme bildirimi şemasını desteklemiyor.',
 'Could not reach GitHub. Check your internet connection, firewall, VPN, or DNS settings, then try again.': 'GitHub’a ulaşılamadı. İnternet bağlantınızı, '
                                                                                                            'güvenlik duvarınızı, VPN’inizi veya DNS '
                                                                                                            'ayarlarınızı denetleyip yeniden deneyin.',
 'The GitHub update check timed out. Try again.': 'GitHub güncelleme denetimi zaman aşımına uğradı. Yeniden deneyin.',
 'Could not reach the update server. Check your internet connection, firewall, VPN, or DNS settings, then try again.': 'Güncelleme sunucusuna ulaşılamadı. '
                                                                                                                       'İnternet bağlantınızı, güvenlik '
                                                                                                                       'duvarınızı, VPN’inizi veya DNS '
                                                                                                                       'ayarlarınızı denetleyip yeniden '
                                                                                                                       'deneyin.',
 'The update check timed out. Try again.': 'Güncelleme denetimi zaman aşımına uğradı. Yeniden deneyin.',
 'The update server returned unreadable JSON data.': 'Güncelleme sunucusu okunamayan JSON verisi döndürdü.',
 'GitHub refused the update check. Its temporary unauthenticated request limit may have been reached. Try again later.': 'GitHub güncelleme denetimini '
                                                                                                                         'reddetti. Geçici kimlik doğrulamasız '
                                                                                                                         'istek sınırına ulaşılmış olabilir. '
                                                                                                                         'Daha sonra yeniden deneyin.',
 'A secure connection to GitHub could not be established. Check your PC date/time, antivirus HTTPS scanning, VPN, or proxy settings.': 'GitHub ile güvenli '
                                                                                                                                       'bağlantı kurulamadı. '
                                                                                                                                       'Bilgisayarınızın '
                                                                                                                                       'tarih/saatini, '
                                                                                                                                       'antivirüs HTTPS '
                                                                                                                                       'taramasını, VPN veya '
                                                                                                                                       'vekil sunucu '
                                                                                                                                       'ayarlarını denetleyin.',
 'The update manifest is unexpectedly large.': 'Güncelleme bildirimi beklenmedik derecede büyük.',
 'Could not create shortcut': 'Kısayol oluşturulamadı',
 'Hotkey behavior': 'Kısayol davranışı',
 'Title contains': 'Başlık şunu içerir',
 'Macro validation': 'Makro doğrulaması',
 'Example: Smooth Click Sequence': 'Örnek: Akıcı Tıklama Dizisi',
 'Could not read the target window position.': 'Hedef pencerenin konumu okunamadı.',
 'No foreground window is available.': 'Kullanılabilir bir ön plan penceresi yok.',
 'Could not resolve the target window client area.': 'Hedef pencerenin istemci alanı belirlenemedi.',
 'Set a Target Window title in Macro Options first.': 'Önce Makro Seçenekleri bölümünde bir Hedef Pencere başlığı ayarlayın.',
 'Stop playback before starting a recording.': 'Kayıt başlatmadan önce oynatmayı durdurun.',
 'MrMacro found the following items:\n\n': 'MrMacro şu öğeleri buldu:\n\n',
 'The macro repeats infinitely and contains no delay or wait action; this can consume excessive CPU and input bandwidth.': 'Makro sonsuza kadar tekrarlanıyor '
                                                                                                                           've gecikme ya da bekleme eylemi '
                                                                                                                           'içermiyor; bu durum aşırı işlemci '
                                                                                                                           've girdi bant genişliği '
                                                                                                                           'kullanabilir.',
 'The selected microphone has no input channels.': 'Seçilen mikrofonun giriş kanalı yok.',
 'The selected device has no input channels.': 'Seçilen aygıtın giriş kanalı yok.',
 'Nothing is being recorded.': 'Şu anda kayıt yapılmıyor.',
 'The trim settings removed the entire sound.': 'Kırpma ayarları sesin tamamını kaldırdı.',
 'Press Apply and test, then speak into your microphone.': 'Uygula ve test et düğmesine basın, ardından mikrofonunuza konuşun.',
 'Apply and test audio routing': 'Ses yönlendirmesini uygula ve test et',
 'Test tone sent to Primary and Monitor outputs. Low-latency routing is active.': 'Test tonu Birincil ve Dinleme çıkışlarına gönderildi. Düşük gecikmeli '
                                                                                  'yönlendirme etkin.',
 ' Speak into your microphone and confirm that the live level meter moves.': ' Mikrofonunuza konuşun ve canlı seviye göstergesinin hareket ettiğini '
                                                                             'doğrulayın.',
 'No microphone samples are arriving. Press Apply and test, then verify Windows microphone privacy and the selected real microphone.': 'Mikrofondan örnek '
                                                                                                                                       'gelmiyor. Uygula ve '
                                                                                                                                       'test et düğmesine '
                                                                                                                                       'basın, ardından '
                                                                                                                                       'Windows mikrofon '
                                                                                                                                       'gizlilik ayarlarını ve '
                                                                                                                                       'seçilen gerçek '
                                                                                                                                       'mikrofonu doğrulayın.',
 'Background Remover is not installed. Run setup_background_remover.bat or setup_optional_ai.bat in the MrStudio folder.': 'Arka Plan Kaldırıcı yüklü değil. '
                                                                                                                           'MrStudio klasöründeki '
                                                                                                                           'setup_background_remover.bat veya '
                                                                                                                           'setup_optional_ai.bat dosyasını '
                                                                                                                           'çalıştırın.',
 'Vocal Remover is not installed. Run setup_vocal_remover.bat or setup_optional_ai.bat in the MrStudio folder.': 'Vokal Ayırıcı yüklü değil. MrStudio '
                                                                                                                 'klasöründeki setup_vocal_remover.bat veya '
                                                                                                                 'setup_optional_ai.bat dosyasını çalıştırın.',
 'The standalone build cannot load a newly installed Demucs module. Use the normal MrInstaller Python build for Vocal Remover.': 'Bağımsız yapı, yeni yüklenen '
                                                                                                                                 'Demucs modülünü yükleyemez. '
                                                                                                                                 'Vokal Ayırıcı için normal '
                                                                                                                                 'MrInstaller Python yapısını '
                                                                                                                                 'kullanın.',
 'AI background removal is optional. Run setup_background_remover.bat or setup_optional_ai.bat first.': 'Yapay zekâ ile arka plan kaldırma isteğe bağlıdır. '
                                                                                                        'Önce setup_background_remover.bat veya '
                                                                                                        'setup_optional_ai.bat dosyasını çalıştırın.',
 'Invalid timecode:': 'Geçersiz zaman kodu:',
 'ffprobe was not found. Select it in Settings or install FFmpeg.': 'ffprobe bulunamadı. Ayarlar bölümünden seçin veya FFmpeg’i yükleyin.',
 'FFmpeg was not found. Install it or choose ffmpeg.exe in Settings.': 'FFmpeg bulunamadı. Yükleyin veya Ayarlar bölümünden ffmpeg.exe dosyasını seçin.',
 'Add at least one audio track.': 'En az bir ses parçası ekleyin.',
 'ffprobe could not inspect this file.': 'ffprobe bu dosyayı inceleyemedi.',
 'LibreOffice was not found. Install it or choose soffice.exe in Settings for document conversion.': 'LibreOffice bulunamadı. Belge dönüştürme için yükleyin '
                                                                                                     'veya Ayarlar bölümünden soffice.exe dosyasını seçin.',
 'LibreOffice did not create an output file.': 'LibreOffice bir çıktı dosyası oluşturmadı.',
 'Transparent PNG background removal': 'Şeffaf PNG arka plan kaldırma',
 'Local vocal separation and image background removal. Files stay on your computer; models download only when their optional component is installed and first used.': 'Yerel '
                                                                                                                                                                      'vokal '
                                                                                                                                                                      'ayırma '
                                                                                                                                                                      've '
                                                                                                                                                                      'görsel '
                                                                                                                                                                      'arka '
                                                                                                                                                                      'plan '
                                                                                                                                                                      'kaldırma. '
                                                                                                                                                                      'Dosyalar '
                                                                                                                                                                      'bilgisayarınızda '
                                                                                                                                                                      'kalır; '
                                                                                                                                                                      'modeller '
                                                                                                                                                                      'yalnızca '
                                                                                                                                                                      'isteğe '
                                                                                                                                                                      'bağlı '
                                                                                                                                                                      'bileşenleri '
                                                                                                                                                                      'yüklendiğinde '
                                                                                                                                                                      've '
                                                                                                                                                                      'ilk '
                                                                                                                                                                      'kez '
                                                                                                                                                                      'kullanıldığında '
                                                                                                                                                                      'indirilir.',
 'Cancelable background jobs keep the interface responsive.': 'İptal edilebilir arka plan işleri arayüzün akıcı kalmasını sağlar.',
 'Separate vocals and instrumental tracks locally with configurable Demucs models and export quality.': 'Yapılandırılabilir Demucs modelleri ve dışa aktarma '
                                                                                                        'kalitesiyle vokalleri ve enstrümantal parçaları yerel '
                                                                                                        'olarak ayırın.',
 'Create transparent PNGs with general, portrait, detailed-object, and illustration models.': 'Genel, portre, ayrıntılı nesne ve illüstrasyon modelleriyle '
                                                                                              'şeffaf PNG’ler oluşturun.',
 'Inspect files, extract frames, and safely strip metadata.': 'Dosyaları inceleyin, kareleri çıkarın ve meta verileri güvenli biçimde temizleyin.',
 'Choose color to remove': 'Kaldırılacak rengi seç',
 'Loading background-removal model': 'Arka plan kaldırma modeli yükleniyor',
 'Saving transparent result': 'Şeffaf sonuç kaydediliyor',
 'Configure local processing tools and export behavior. No account, cloud upload, analytics, or online editor service is required.': 'Yerel işleme araçlarını '
                                                                                                                                     've dışa aktarma '
                                                                                                                                     'davranışını '
                                                                                                                                     'yapılandırın. Hesap, '
                                                                                                                                     'buluta yükleme, analiz '
                                                                                                                                     'veya çevrimiçi '
                                                                                                                                     'düzenleyici hizmeti '
                                                                                                                                     'gerekmez.',
 'Inspect streams and metadata, extract video frames, remove private metadata, and build multi-page PDFs from images.': 'Akışları ve meta verileri inceleyin, '
                                                                                                                        'video karelerini çıkarın, özel meta '
                                                                                                                        'verileri kaldırın ve görsellerden çok '
                                                                                                                        'sayfalı PDF’ler oluşturun.',
 'Load timeline project': 'Zaman çizelgesi projesini yükle',
 'Could not load project': 'Proje yüklenemedi'})

_EXACT_TR.update({'Restart your PC before using this app.': 'Bu uygulamayı kullanmadan önce bilgisayarınızı yeniden başlatın.',
 'Application Support': 'Uygulama Desteği',
 'Select vocals, instrumental, or both outputs.': 'Vokal, enstrümantal veya her iki çıktıyı seçin.',
 'End of file': 'Dosyanın sonu',
 'MrMacro currently targets Windows because it uses Win32 SendInput.': 'MrMacro, Win32 SendInput kullandığı için şu anda Windows’u hedefler.',
 'Physical key tracking is available only on Windows.': 'Fiziksel tuş izleme yalnızca Windows’ta kullanılabilir.',
 'GitHub returned unreadable update information.': 'GitHub okunamayan güncelleme bilgisi döndürdü.'})

_REGEX_TR[:0] = [
    (re.compile(r"^Downloading the MrInstaller update \((.+) / (.+)\)$"), lambda m: f"MrInstaller güncellemesi indiriliyor ({m.group(1)} / {m.group(2)})"),
    (re.compile(r"^Downloading the MrInstaller update \((.+)\)$"), lambda m: f"MrInstaller güncellemesi indiriliyor ({m.group(1)})"),
    (re.compile(r"^Playback stopped because of an error: (.+)$", re.S), lambda m: f"Bir hata nedeniyle oynatma durduruldu: {m.group(1)}"),
    (re.compile(r"^Added (\d+) link\(s\) to the queue\.$"), lambda m: f"Kuyruğa {m.group(1)} bağlantı eklendi."),
    (re.compile(r"^Preparing (.+)$"), lambda m: f"{m.group(1)} hazırlanıyor"),
    (re.compile(r"^Installing (.+) — this can take several minutes$"), lambda m: f"{m.group(1)} yükleniyor — bu işlem birkaç dakika sürebilir"),
    (re.compile(r"^Connecting to download (.+)$"), lambda m: f"{m.group(1)} indirmesine bağlanılıyor"),
    (re.compile(r"^Starting (.+) setup$"), lambda m: f"{m.group(1)} kurulumu başlatılıyor"),
    (re.compile(r"^Setup failed with exit code (.+?)\.\n\nRecent setup output:\n(.*?)\n\nFull log:\n(.+)$", re.S), lambda m: f"Kurulum {m.group(1)} çıkış koduyla başarısız oldu.\n\nSon kurulum çıktısı:\n{m.group(2)}\n\nTam günlük:\n{m.group(3)}"),
    (re.compile(r"^Requirements file not found:\n(.+)$", re.S), lambda m: f"Gereksinimler dosyası bulunamadı:\n{m.group(1)}"),
    (re.compile(r"^The private Python launcher was not created:\n(.+)$", re.S), lambda m: f"Özel Python başlatıcısı oluşturulamadı:\n{m.group(1)}"),
    (re.compile(r"^Package ZIP is missing:\n(.+)$", re.S), lambda m: f"Paket ZIP’i eksik:\n{m.group(1)}"),
    (re.compile(r"^Checking package \((.+) / (.+)\)$"), lambda m: f"Paket denetleniyor ({m.group(1)} / {m.group(2)})"),
    (re.compile(r"^Extracting (.+)$"), lambda m: f"{m.group(1)} çıkarılıyor"),
    (re.compile(r"^(.+) is not installed\.$"), lambda m: f"{m.group(1)} yüklü değil."),
    (re.compile(r"^Install (.+) before installing this component\.$"), lambda m: f"Bu bileşeni yüklemeden önce {m.group(1)} yükleyin."),
    (re.compile(r"^The installed (.+) folder could not be found:\n(.+)\n\nReinstall or update (.+), then try again\.$", re.S), lambda m: f"Yüklü {m.group(1)} klasörü bulunamadı:\n{m.group(2)}\n\n{m.group(3)} uygulamasını yeniden yükleyin veya güncelleyin, ardından yeniden deneyin."),
    (re.compile(r"^The component requirements file is missing:\n(.+)\n\nUpdate (.+) to the newest bundled version, then try again\.$", re.S), lambda m: f"Bileşen gereksinimleri dosyası eksik:\n{m.group(1)}\n\n{m.group(2)} uygulamasını paketteki en yeni sürüme güncelleyin, ardından yeniden deneyin."),
    (re.compile(r"^The private (.+) Python environment was not found:\n(.+)\n\nReinstall (.+), then try again\.$", re.S), lambda m: f"{m.group(1)} için özel Python ortamı bulunamadı:\n{m.group(2)}\n\n{m.group(3)} uygulamasını yeniden yükleyip tekrar deneyin."),
    (re.compile(r"^Verifying (.+) download$"), lambda m: f"{m.group(1)} indirmesi doğrulanıyor"),
    (re.compile(r"^Downloading (.+) \((.+) / (.+)\)$"), lambda m: f"{m.group(1)} indiriliyor ({m.group(2)} / {m.group(3)})"),
    (re.compile(r"^Downloading (.+) \((.+)\)$"), lambda m: f"{m.group(1)} indiriliyor ({m.group(2)})"),
    (re.compile(r"^Verifying (.+) \((.+)%\)$"), lambda m: f"{m.group(1)} doğrulanıyor (%{m.group(2)})"),
    (re.compile(r"^The update ZIP is corrupted near: (.+)$", re.S), lambda m: f"Güncelleme ZIP’i şu konumun yakınında bozuk: {m.group(1)}"),
    (re.compile(r"^The downloaded ZIP is not a complete MrInstaller update\. Missing: (.+)$", re.S), lambda m: f"İndirilen ZIP tam bir MrInstaller güncellemesi değil. Eksik: {m.group(1)}"),
    (re.compile(r"^Unsafe path found inside update ZIP: (.+)$", re.S), lambda m: f"Güncelleme ZIP’inin içinde güvenli olmayan yol bulundu: {m.group(1)}"),
    (re.compile(r"^Update helper not found: (.+)$", re.S), lambda m: f"Güncelleme yardımcısı bulunamadı: {m.group(1)}"),
    (re.compile(r"^(.+) was (installed|updated) successfully\.$"), lambda m: f"{m.group(1)} başarıyla {'yüklendi' if m.group(2) == 'installed' else 'güncellendi'}."),
    (re.compile(r"^(.+) was installed successfully\.\n\nRestart (.+) before using the tool\.$", re.S), lambda m: f"{m.group(1)} başarıyla yüklendi.\n\nAracı kullanmadan önce {m.group(2)} uygulamasını yeniden başlatın."),
    (re.compile(r"^Updating (.+)$"), lambda m: f"{m.group(1)} güncelleniyor"),
    (re.compile(r"^Installing (.+)$"), lambda m: f"{m.group(1)} yükleniyor"),
    (re.compile(r"^Before installing:\n• (.+)$", re.S), lambda m: f"Yüklemeden önce:\n• {m.group(1)}"),
    (re.compile(r"^(.+)\n\nContinue with the app (.+)\?$", re.S), lambda m: f"{m.group(1)}\n\n{m.group(2)} uygulamasıyla devam edilsin mi?"),
    (re.compile(r"^MrInstaller will use MrStudio's private Python environment and install the packages listed in (.+)\.$"), lambda m: f"MrInstaller, MrStudio’nun özel Python ortamını kullanacak ve {m.group(1)} dosyasında listelenen paketleri yükleyecek."),
    (re.compile(r"^(.+)\n\nContinue\? This may download large AI runtime files and can take several minutes\.$", re.S), lambda m: f"{m.group(1)}\n\nDevam edilsin mi? Büyük yapay zekâ çalışma zamanı dosyaları indirilebilir ve işlem birkaç dakika sürebilir."),
    (re.compile(r"^(.+)\n\nMrInstaller will ask Windows Package Manager to install package:\n(.+)\n\nContinue\?$", re.S), lambda m: f"{m.group(1)}\n\nMrInstaller, Windows Paket Yöneticisi’nden şu paketi yüklemesini isteyecek:\n{m.group(2)}\n\nDevam edilsin mi?"),
    (re.compile(r"^Downloading (.+)$"), lambda m: f"{m.group(1)} indiriliyor"),
    (re.compile(r"^Update payload is missing (.+)$", re.S), lambda m: f"Güncelleme verisinde şu öğe eksik: {m.group(1)}"),
    (re.compile(r"^Unsafe update path: (.+)$", re.S), lambda m: f"Güvenli olmayan güncelleme yolu: {m.group(1)}"),
    (re.compile(r"^MrInstaller could not apply the update:\n(.+)$", re.S), lambda m: f"MrInstaller güncellemeyi uygulayamadı:\n{m.group(1)}"),
    (re.compile(r"^The update server returned HTTP (.+)\.$"), lambda m: f"Güncelleme sunucusu HTTP {m.group(1)} döndürdü."),
    (re.compile(r"^(.+) was not found in (.+)/(.+) on branch (.+)\.$"), lambda m: f"{m.group(1)}, {m.group(2)}/{m.group(3)} deposunun {m.group(4)} dalında bulunamadı."),
    (re.compile(r"^Unsafe path inside ZIP archive: (.+)$", re.S), lambda m: f"ZIP arşivinin içinde güvenli olmayan yol: {m.group(1)}"),
    (re.compile(r"^Repeat block (.+) times$"), lambda m: f"Bloğu {m.group(1)} kez tekrarla"),
    (re.compile(r"^Recorded high-fidelity path: (.+) stored points, (.+) ms\.\nThe path geometry is kept as one compact action\. Delay, chance, enabled state, and note remain editable\.$", re.S), lambda m: f"Yüksek doğruluklu yol kaydedildi: {m.group(1)} nokta, {m.group(2)} ms.\nYol geometrisi tek bir kompakt eylem olarak korunur. Gecikme, olasılık, etkinlik durumu ve not düzenlenebilir."),
    (re.compile(r"^Hotkey conflict: '(.+)' is assigned to both (.+) and (.+)\. The later binding was not registered\.$", re.S), lambda m: f"Kısayol çakışması: ‘{m.group(1)}’ hem {m.group(2)} hem de {m.group(3)} için atanmış. Sonraki bağlantı kaydedilmedi."),
    (re.compile(r"^Unsupported action: (.+)$"), lambda m: f"Desteklenmeyen eylem: {m.group(1)}"),
    (re.compile(r"^(.+) \(Imported\)$"), lambda m: f"{m.group(1)} (İçe Aktarıldı)"),
    (re.compile(r"^Exported (.+)$"), lambda m: f"Dışa aktarıldı: {m.group(1)}"),
    (re.compile(r"^Action (.+): infinite loop block; it requires the emergency stop to exit\.$"), lambda m: f"Eylem {m.group(1)}: Sonsuz döngü bloğu; çıkmak için acil durdurma gerekir."),
    (re.compile(r"^Action (.+): Loop End has no matching Loop Start\.$"), lambda m: f"Eylem {m.group(1)}: Döngü Sonu için eşleşen bir Döngü Başlangıcı yok."),
    (re.compile(r"^Action (.+): keyboard action has no valid Windows virtual-key code\.$"), lambda m: f"Eylem {m.group(1)}: Klavye eyleminin geçerli bir Windows sanal tuş kodu yok."),
    (re.compile(r"^Action (.+): recorded mouse path contains no points\.$"), lambda m: f"Eylem {m.group(1)}: Kaydedilen fare yolu hiç nokta içermiyor."),
    (re.compile(r"^Action (.+): pixel color must use #RRGGBB format\.$"), lambda m: f"Eylem {m.group(1)}: Piksel rengi #RRGGBB biçiminde olmalıdır."),
    (re.compile(r"^Action (.+): image wait has no reference image\.$"), lambda m: f"Eylem {m.group(1)}: Görsel bekleme eyleminin referans görseli yok."),
    (re.compile(r"^Action (.+): reference image does not currently exist: (.+)$", re.S), lambda m: f"Eylem {m.group(1)}: Referans görsel şu anda mevcut değil: {m.group(2)}"),
    (re.compile(r"^Action (.+): Loop Start has no matching Loop End\.$"), lambda m: f"Eylem {m.group(1)}: Döngü Başlangıcı için eşleşen bir Döngü Sonu yok."),
    (re.compile(r"^Windows rejected every supported microphone format: (.+)$", re.S), lambda m: f"Windows desteklenen tüm mikrofon biçimlerini reddetti: {m.group(1)}"),
    (re.compile(r"^Audio file does not exist: (.+)$", re.S), lambda m: f"Ses dosyası mevcut değil: {m.group(1)}"),
    (re.compile(r"^Monitor device not found: (.+)$", re.S), lambda m: f"Dinleme aygıtı bulunamadı: {m.group(1)}"),
    (re.compile(r"^(.+)\nCategory: (.+)\nVolume: (.+)× \| Speed: (.+)×\nLeft click: play \| Right click: options$", re.S), lambda m: f"{m.group(1)}\nKategori: {m.group(2)}\nSes düzeyi: {m.group(3)}× | Hız: {m.group(4)}×\nSol tık: oynat | Sağ tık: seçenekler"),
    (re.compile(r"^Unsupported separation format: (.+)$"), lambda m: f"Desteklenmeyen ayırma biçimi: {m.group(1)}"),
    (re.compile(r"^Created: (.+)$"), lambda m: f"Oluşturuldu: {m.group(1)}"),
    (re.compile(r"^Demucs completed but did not create the expected track: (.+)$", re.S), lambda m: f"Demucs tamamlandı ancak beklenen parçayı oluşturmadı: {m.group(1)}"),
    (re.compile(r"^Invalid timecode: (.+)$"), lambda m: f"Geçersiz zaman kodu: {m.group(1)}"),
    (re.compile(r"^Unsupported conversion target: \.(.+)$"), lambda m: f"Desteklenmeyen dönüştürme hedefi: .{m.group(1)}"),
    (re.compile(r"^Track row (.+) has an invalid gain or delay\.$"), lambda m: f"{m.group(1)}. parça satırında geçersiz kazanç veya gecikme var."),
    (re.compile(r"^Strip metadata — (.+)$"), lambda m: f"Meta verileri temizle — {m.group(1)}"),
    (re.compile(r"^Timeline row (.+) contains a non-numeric setting\.$"), lambda m: f"Zaman çizelgesinin {m.group(1)}. satırı sayısal olmayan bir ayar içeriyor."),
]

# Longer phrases are replaced before individual words. This gives useful Turkish
# coverage to dynamic status text without altering file names, URLs, or code-like values.
_PHRASE_TR: list[tuple[str, str]] = [
    ("Choose an installation folder", "Bir yükleme klasörü seçin"),
    ("Check for updates", "Güncellemeleri denetle"),
    ("checking for updates", "güncellemeler denetleniyor"),
    ("update available", "güncelleme mevcut"),
    ("package changed", "paket değişti"),
    ("restart required", "yeniden başlatma gerekli"),
    ("open output folder", "çıktı klasörünü aç"),
    ("open export folder", "dışa aktarma klasörünü aç"),
    ("output folder", "çıktı klasörü"),
    ("input file", "girdi dosyası"),
    ("output file", "çıktı dosyası"),
    ("select files", "dosyaları seç"),
    ("select file", "dosya seç"),
    ("choose folder", "klasör seç"),
    ("download queue", "indirme kuyruğu"),
    ("export queue", "dışa aktarma kuyruğu"),
    ("processing log", "işlem günlüğü"),
    ("start download", "indirmeyi başlat"),
    ("cancel download", "indirmeyi iptal et"),
    ("download complete", "indirme tamamlandı"),
    ("download failed", "indirme başarısız"),
    ("installation complete", "yükleme tamamlandı"),
    ("installation failed", "yükleme başarısız"),
    ("creating shortcuts", "kısayollar oluşturuluyor"),
    ("preparing installation", "yükleme hazırlanıyor"),
    ("required components", "gerekli bileşenler"),
    ("optional component", "isteğe bağlı bileşen"),
    ("not installed", "yüklü değil"),
    ("not found", "bulunamadı"),
    ("no results", "sonuç yok"),
    ("no items", "öğe yok"),
    ("are you sure", "emin misiniz"),
    ("please select", "lütfen seçin"),
    ("please choose", "lütfen seçin"),
    ("could not", "başarısız oldu"),
    ("failed to", "başarısız:"),
    ("successfully", "başarıyla"),
    ("in progress", "devam ediyor"),
    ("drag and drop", "sürükleyip bırakın"),
    ("click to", "tıklayarak"),
    ("double-click", "çift tıklayın"),
    ("right-click", "sağ tıklayın"),
    ("keyboard shortcut", "klavye kısayolu"),
    ("global hotkey", "genel kısayol"),
    ("microphone input", "mikrofon girişi"),
    ("primary output", "birincil çıkış"),
    ("monitor output", "dinleme çıkışı"),
    ("audio device", "ses aygıtı"),
    ("background remover", "arka plan kaldırıcı"),
    ("vocal remover", "vokal ayırıcı"),
    ("audio only", "yalnızca ses"),
    ("video only", "yalnızca video"),
    ("best available", "mevcut en iyi"),
    ("frame rate", "kare hızı"),
    ("sample rate", "örnekleme hızı"),
    ("bit rate", "bit hızı"),
    ("file size", "dosya boyutu"),
]

_WORD_TR: dict[str, str] = {
    "all": "tümü", "apps": "uygulamalar", "app": "uygulama", "installed": "yüklü",
    "available": "mevcut", "install": "yükle", "uninstall": "kaldır", "update": "güncelle",
    "launch": "başlat", "instructions": "talimatlar", "settings": "ayarlar", "language": "dil",
    "save": "kaydet", "cancel": "iptal", "close": "kapat", "open": "aç", "browse": "gözat",
    "select": "seç", "choose": "seç", "add": "ekle", "remove": "kaldır", "delete": "sil",
    "edit": "düzenle", "start": "başlat", "stop": "durdur", "pause": "duraklat",
    "resume": "devam et", "reset": "sıfırla", "clear": "temizle", "search": "ara",
    "ready": "hazır", "running": "çalışıyor", "finished": "tamamlandı", "complete": "tamamlandı",
    "completed": "tamamlandı", "failed": "başarısız", "error": "hata", "warning": "uyarı",
    "required": "gerekli", "optional": "isteğe bağlı", "folder": "klasör", "file": "dosya",
    "files": "dosyalar", "output": "çıktı", "input": "girdi", "quality": "kalite",
    "format": "biçim", "formats": "biçimler", "video": "video", "audio": "ses", "image": "görsel",
    "images": "görseller", "download": "indir", "downloads": "indirmeler", "queue": "kuyruk",
    "progress": "ilerleme", "status": "durum", "name": "ad", "description": "açıklama",
    "category": "kategori", "version": "sürüm", "default": "varsayılan", "enabled": "etkin",
    "disabled": "devre dışı", "yes": "evet", "no": "hayır", "none": "yok", "home": "ana sayfa",
    "help": "yardım", "about": "hakkında", "view": "görünüm", "tools": "araçlar",
    "tool": "araç", "converter": "dönüştürücü", "advanced": "gelişmiş", "basic": "temel",
    "local": "yerel", "online": "çevrimiçi", "desktop": "masaüstü", "shortcut": "kısayol",
    "shortcuts": "kısayollar", "restart": "yeniden başlat", "apply": "uygula", "copy": "kopyala",
    "paste": "yapıştır", "import": "içe aktar", "export": "dışa aktar", "record": "kaydet",
    "recording": "kayıt", "play": "oynat", "playback": "oynatma", "microphone": "mikrofon",
    "device": "aygıt", "devices": "aygıtlar", "volume": "ses düzeyi", "speed": "hız",
    "duration": "süre", "delay": "gecikme", "loop": "döngü", "loops": "döngüler",
    "action": "eylem", "actions": "eylemler", "hotkey": "kısayol", "hotkeys": "kısayollar",
    "keyboard": "klavye", "mouse": "fare", "button": "düğme", "buttons": "düğmeler",
    "new": "yeni", "duplicate": "çoğalt", "title": "başlık", "path": "yol", "size": "boyut",
    "width": "genişlik", "height": "yükseklik", "color": "renk", "background": "arka plan",
    "metadata": "meta veri", "subtitles": "altyazılar", "playlist": "oynatma listesi",
    "automatic": "otomatik", "manual": "manuel", "refresh": "yenile", "test": "test et",
}

# _FULL_TR_WORDS: fallback vocabulary for dynamic text.
_WORD_TR.update({'the': '', 'a': 'bir', 'an': 'bir', 'and': 've', 'or': 'veya', 'is': '', 'are': '', 'was': '', 'were': '', 'be': 'ol', 'been': '', 'to': '', 'from': '-den', 'for': 'için', 'with': 'ile', 'without': 'olmadan', 'in': 'içinde', 'into': 'içine', 'on': 'üzerinde', 'of': '', 'this': 'bu', 'that': 'bu', 'these': 'bunlar', 'those': 'onlar', 'your': 'sizin', 'you': 'siz', 'its': 'onun', 'it': 'o', 'first': 'önce', 'before': 'önce', 'after': 'sonra', 'when': 'olduğunda', 'while': 'sırasında', 'then': 'ardından', 'again': 'yeniden', 'only': 'yalnızca', 'also': 'ayrıca', 'other': 'diğer', 'more': 'daha fazla', 'less': 'daha az', 'all': 'tümü', 'each': 'her', 'every': 'her', 'current': 'geçerli', 'selected': 'seçili', 'existing': 'mevcut', 'newer': 'daha yeni', 'older': 'daha eski', 'same': 'aynı', 'can': '-ebilir', 'could': '-ebilirdi', 'will': '-ecek', 'may': '-ebilir', 'must': 'gerekir', 'should': 'gerekir', 'not': 'değil', 'never': 'asla', 'already': 'zaten', 'now': 'şimdi', 'still': 'hâlâ', 'yet': 'henüz', 'open': 'aç', 'opened': 'açıldı', 'close': 'kapat', 'closed': 'kapalı', 'run': 'çalıştır', 'running': 'çalışıyor', 'start': 'başlat', 'started': 'başladı', 'finish': 'tamamla', 'finishes': 'biter', 'finished': 'tamamlandı', 'cancelled': 'iptal edildi', 'failed': 'başarısız', 'success': 'başarılı', 'downloaded': 'indirildi', 'upload': 'yükle', 'uploaded': 'yüklendi', 'replace': 'değiştir', 'replaces': 'değiştirir', 'changed': 'değişti', 'read': 'oku', 'write': 'yaz', 'show': 'göster', 'shown': 'gösterilen', 'hide': 'gizle', 'found': 'bulundu', 'missing': 'eksik', 'available': 'mevcut', 'unavailable': 'kullanılamıyor', 'configured': 'yapılandırıldı', 'connected': 'bağlandı', 'registered': 'kaydedildi', 'source': 'kaynak', 'destination': 'hedef', 'component': 'bileşen', 'components': 'bileşenler', 'task': 'görev', 'tasks': 'görevler', 'update': 'güncelleme', 'updates': 'güncellemeler', 'check': 'denetim', 'channel': 'kanal', 'build': 'yapı', 'repository': 'depo', 'manifest': 'bildirim', 'application': 'uygulama', 'program': 'program', 'software': 'yazılım', 'installer': 'yükleyici', 'environment': 'ortam', 'information': 'bilgi', 'permission': 'izin', 'confirmation': 'onay', 'notice': 'uyarı', 'timeout': 'zaman aşımı', 'seconds': 'saniye', 'second': 'saniye', 'example': 'örnek', 'custom': 'özel', 'selector': 'seçici', 'stream': 'akış', 'streams': 'akışlar', 'container': 'kapsayıcı', 'resolution': 'çözünürlük', 'playlist': 'oynatma listesi', 'playlists': 'oynatma listeleri', 'subtitle': 'altyazı', 'thumbnail': 'küçük resim', 'chapters': 'bölümler', 'browser': 'tarayıcı', 'cookies': 'çerezler', 'cookie': 'çerez', 'database': 'veritabanı', 'network': 'ağ', 'bandwidth': 'bant genişliği', 'memory': 'bellek', 'disk': 'disk', 'media': 'medya', 'site': 'site', 'sites': 'siteler', 'terms': 'koşullar', 'law': 'yasa', 'profile': 'profil', 'profiles': 'profiller', 'category': 'kategori', 'categories': 'kategoriler', 'sound': 'ses', 'sounds': 'sesler', 'signal': 'sinyal', 'voice': 'ses', 'headphones': 'kulaklık', 'speakers': 'hoparlörler', 'routing': 'yönlendirme', 'active': 'etkin', 'silent': 'sessiz', 'muted': 'susturulmuş', 'capture': 'yakalama', 'captured': 'yakalandı', 'detected': 'algılandı', 'samples': 'örnekler', 'privacy': 'gizlilik', 'window': 'pencere', 'foreground': 'ön plan', 'target': 'hedef', 'relative': 'göreli', 'cursor': 'imleç', 'pixel': 'piksel', 'screen': 'ekran', 'recorded': 'kaydedilmiş', 'stored': 'saklanan', 'points': 'noktalar', 'geometry': 'geometri', 'compact': 'kompakt', 'editable': 'düzenlenebilir', 'chance': 'olasılık', 'jitter': 'sapma', 'note': 'not', 'comments': 'yorumlar', 'comment': 'yorum', 'field': 'alan', 'nearest': 'en yakın', 'timeline': 'zaman çizelgesi', 'repeat': 'tekrar', 'count': 'sayısı', 'mode': 'mod', 'binding': 'bağlantı', 'released': 'bırakıldı', 'keyboard': 'klavye', 'keys': 'tuşlar', 'key': 'tuş', 'held': 'basılı', 'physically': 'fiziksel olarak', 'coordinates': 'koordinatlar', 'compatibility': 'uyumluluk', 'protected': 'korumalı', 'competitive': 'rekabetçi', 'games': 'oyunlar', 'rules': 'kurallar', 'workspace': 'çalışma alanı', 'professional': 'profesyonel', 'editing': 'düzenleme', 'conversion': 'dönüştürme', 'suite': 'paket', 'built': 'geliştirildi', 'account': 'hesap', 'website': 'web sitesi', 'licenses': 'lisanslar', 'model': 'model', 'models': 'modeller', 'quality': 'kalite', 'processing': 'işleme', 'time': 'süre', 'vocals': 'vokaller', 'instrumental': 'enstrümantal', 'stems': 'kanallar', 'removal': 'kaldırma', 'general': 'genel', 'purpose': 'amaçlı', 'detailed': 'ayrıntılı', 'objects': 'nesneler', 'portraits': 'portreler', 'hair': 'saç', 'edges': 'kenarlar', 'transparency': 'saydamlık', 'locally': 'yerel olarak', 'runtime': 'çalışma zamanı', 'cache': 'önbellek', 'levels': 'düzeyler', 'mastering': 'mastering', 'tone': 'ton', 'cleanup': 'temizleme', 'space': 'ortam', 'mixer': 'mikser', 'track': 'parça', 'tracks': 'parçalar', 'batch': 'toplu', 'batches': 'toplu işlemler', 'items': 'öğeler', 'individually': 'ayrı ayrı', 'rest': 'kalanı', 'lower': 'daha düşük', 'better': 'daha iyi', 'strong': 'güçlü', 'range': 'aralık', 'outputs': 'çıktılar', 'subfolders': 'alt klasörler', 'creating': 'oluşturma', 'focused': 'odaklanmış', 'computer': 'bilgisayar', 'begin': 'başla', 'fit': 'sığdır', 'crop': 'kırpma', 'selection': 'seçim', 'drag': 'sürükle', 'over': 'üzerinde', 'enabling': 'etkinleştirdikten', 'resize': 'yeniden boyutlandır', 'aspect': 'en-boy', 'ratio': 'oranı', 'rotate': 'döndür', 'flip': 'çevir', 'filters': 'filtreler', 'applied': 'uygulandı', 'undoable': 'geri alınabilir', 'edits': 'düzenlemeler', 'stylized': 'stilize', 'caption': 'açıklama', 'credit': 'kaynak', 'label': 'etiket', 'watermark': 'filigran', 'center': 'orta', 'chroma': 'renk', 'pick': 'seç', 'initialize': 'hazırla', 'zoom': 'yakınlaştırma', 'paths': 'yollar', 'blank': 'boş', 'locations': 'konumlar', 'overwrite': 'üzerine yaz', 'overwriting': 'üzerine yazma', 'interactive': 'etkileşimli', 'editors': 'düzenleyiciler', 'location': 'konum', 'saved': 'kaydedildi', 'codec': 'kodek', 'dimensions': 'boyutlar', 'appears': 'görünür', 'frame': 'kare', 'exports': 'dışa aktarımlar', 'thousands': 'binlerce', 'copied': 'kopyalandı', 'safely': 'güvenli biçimde', 'ancillary': 'yardımcı', 'extractor': 'çıkarıcı', 'cleaner': 'temizleyici', 'transform': 'dönüşüm', 'framing': 'kadraj', 'original': 'orijinal', 'horizontally': 'yatay', 'vertically': 'dikey', 'top': 'üst', 'bottom': 'alt', 'left': 'sol', 'right': 'sağ', 'clip': 'klip', 'fade': 'geçiş', 'opening': 'açılış', 'four': 'dört', 'editor': 'düzenleyici', 'incomplete': 'tamamlanmadı'})



# MrChat manifest translations
_EXACT_TR.update({'Communication': 'İletişim', 'A private Discord-like chat app for friends with servers, channels, direct messages, real-time presence, reactions, replies, and secure file sharing.': 'Sunucular, kanallar, direkt mesajlar, anlık çevrimiçi durumu, tepkiler, yanıtlar ve güvenli dosya paylaşımı içeren, arkadaşlara özel Discord benzeri sohbet uygulaması.', 'MrChat includes both a desktop client and a private self-hosted server. Messages cannot travel between friends unless one MrChat server is running and reachable.': 'MrChat hem masaüstü istemcisi hem de kendinizin barındırabileceği özel bir sunucu içerir. Çalışan ve erişilebilir bir MrChat sunucusu olmadan arkadaşlar arasında mesaj iletilemez.', 'For same-network use, the host starts the bundled server and friends connect to the host computer’s local IPv4 address on port 8765.': 'Aynı ağda kullanım için sunucu sahibi birlikte gelen sunucuyu başlatır; arkadaşlar sunucu bilgisayarının yerel IPv4 adresine 8765 portundan bağlanır.', 'For always-online internet use, deploy the bundled Python server to a hosting provider with persistent storage and HTTPS. A server running on your PC goes offline when your PC is turned off.': 'İnternet üzerinden sürekli çevrimiçi kullanım için birlikte gelen Python sunucusunu kalıcı depolama ve HTTPS sunan bir barındırma sağlayıcısına dağıtın. Bilgisayarınızda çalışan sunucu, bilgisayar kapatıldığında çevrimdışı olur.', 'The first installation needs internet access while MrInstaller creates a private Python environment and downloads the client and server components.': 'İlk kurulumda MrInstaller özel bir Python ortamı oluşturup istemci ve sunucu bileşenlerini indirirken internet bağlantısı gerekir.', 'Uploaded files are stored by the chosen server owner. Only use a server operated by someone you trust.': 'Yüklenen dosyalar seçilen sunucunun sahibi tarafından saklanır. Yalnızca güvendiğiniz birinin işlettiği sunucuyu kullanın.', 'Launch MrChat and choose Host on this PC to open the bundled server console, or enter the HTTPS address of an existing MrChat server.': 'MrChat’i açıp birlikte gelen sunucu konsolunu başlatmak için Bu Bilgisayarda Barındır seçeneğini kullanın veya mevcut bir MrChat sunucusunun HTTPS adresini girin.', 'The server console displays a private friend registration code. Share the server address and code only with trusted friends.': 'Sunucu konsolunda özel bir arkadaş kayıt kodu gösterilir. Sunucu adresini ve kodu yalnızca güvendiğiniz arkadaşlarla paylaşın.', 'Windows Firewall may ask for private-network access when hosting on a LAN. Allow private networks only; public-network access is not required for normal LAN use.': 'Yerel ağda sunucu barındırırken Windows Güvenlik Duvarı özel ağ erişimi isteyebilir. Yalnızca özel ağlara izin verin; normal yerel ağ kullanımı için genel ağ erişimi gerekmez.', 'Create an account, then create a private server or join one using its invite code. Double-click a member to open a direct message.': 'Bir hesap oluşturun; ardından özel bir sunucu oluşturun veya davet koduyla bir sunucuya katılın. Direkt mesaj açmak için bir üyeye çift tıklayın.', 'Keep the server console open while self-hosting. Closing it disconnects every client until the server is started again.': 'Sunucuyu kendiniz barındırırken sunucu konsolunu açık tutun. Konsolu kapatmak, sunucu yeniden başlatılana kadar tüm istemcilerin bağlantısını keser.', 'MrChat supports private servers, text channels, direct messages, online presence, typing indicators, replies, editing, deletion, emoji reactions, and file uploads/downloads.': 'MrChat özel sunucuları, metin kanallarını, direkt mesajları, çevrimiçi durumunu, yazma göstergelerini, yanıtları, düzenlemeyi, silmeyi, emoji tepkilerini ve dosya yükleme/indirmeyi destekler.', 'The default server upload limit is 50 MB. The server owner can change it in the MrChatServer server_config.json file.': 'Varsayılan sunucu yükleme sınırı 50 MB’tır. Sunucu sahibi bunu MrChatServer klasöründeki server_config.json dosyasından değiştirebilir.', 'Executable file types are blocked by default. ZIP archives, images, videos, audio, and documents remain supported.': 'Çalıştırılabilir dosya türleri varsayılan olarak engellenir. ZIP arşivleri, görseller, videolar, ses dosyaları ve belgeler desteklenmeye devam eder.', 'Server data is stored under %APPDATA%\\MrChatServer by default, including the SQLite database, configuration, and uploaded files. Back up this folder regularly.': 'Sunucu verileri varsayılan olarak SQLite veritabanı, yapılandırma ve yüklenen dosyalar dahil %APPDATA%\\MrChatServer altında saklanır. Bu klasörü düzenli olarak yedekleyin.', 'Use HTTPS for any server reachable over the internet. Do not expose the default unencrypted HTTP service directly to the public internet.': 'İnternet üzerinden erişilebilen tüm sunucularda HTTPS kullanın. Varsayılan şifrelenmemiş HTTP hizmetini doğrudan genel internete açmayın.', 'MrChat uses the English or Turkish language selected in MrInstaller Settings. Restart MrChat after changing the shared language.': 'MrChat, MrInstaller Ayarları’nda seçilen İngilizce veya Türkçe dili kullanır. Ortak dili değiştirdikten sonra MrChat’i yeniden başlatın.'})

_SKIP_RE = re.compile(r"^(?:https?://|[A-Za-z]:[\\/]|%\([^)]*\)|[\w.-]+\.(?:py|bat|exe|dll|json|txt|md|zip|png|jpg|jpeg|webp|wav|mp3|mp4|mkv|flac|opus|m4a|svg|ico)|[a-z0-9_.-]+(?:,[a-z0-9_.-]+)+$)", re.I)


def _preserve_case(source: str, replacement: str) -> str:
    if source.isupper():
        return replacement.upper()
    if source[:1].isupper():
        return replacement[:1].upper() + replacement[1:]
    return replacement


def translate_text(text: Any, language: str | None = None) -> str:
    value = str(text if text is not None else "")
    if normalize_language(language or load_language()) != TURKISH or not value:
        return value
    if value in _EXACT_TR:
        return _EXACT_TR[value]
    for pattern, replacement in _REGEX_TR:
        match = pattern.match(value)
        if match:
            return replacement(match) if callable(replacement) else pattern.sub(replacement, value)
    stripped = value.strip()
    if not stripped or _SKIP_RE.search(stripped):
        return value

    result = value
    for source, target in sorted(_PHRASE_TR, key=lambda item: len(item[0]), reverse=True):
        pattern = re.compile(re.escape(source), re.I)
        result = pattern.sub(lambda m, t=target: _preserve_case(m.group(0), t), result)

    def replace_word(match: re.Match[str]) -> str:
        source = match.group(0)
        target = _WORD_TR.get(source.casefold())
        return _preserve_case(source, target) if target else source

    result = re.sub(r"(?<![\w])(?:[A-Za-z]+)(?![\w])", replace_word, result)
    return result


class LanguageManager(QObject):
    def __init__(self, app: QApplication, language: str | None = None) -> None:
        # Do not parent this Python QObject or its timers to QApplication.
        # Some Windows/PySide6 combinations can return a NULL Qt timer when a
        # Python QObject subclass is supplied as QTimer's parent, which used to
        # abort MrInstaller and every bundled app during startup.
        super().__init__()
        self.app = app
        self.language = normalize_language(language or load_language())
        self._refreshing = False
        self._refresh_pending = False
        self.defer_timer: QTimer | None = None
        self.timer: QTimer | None = None
        app.installEventFilter(self)
        self._install_timers()

    @staticmethod
    def _new_timer() -> QTimer | None:
        try:
            # Keep the Python reference instead of assigning a QObject parent.
            return QTimer()
        except (RuntimeError, SystemError, TypeError):
            # Localization must remain optional; a broken Qt timer must never
            # prevent the actual application from opening.
            return None

    def _install_timers(self) -> None:
        deferred = self._new_timer()
        if deferred is not None:
            try:
                deferred.setSingleShot(True)
                deferred.timeout.connect(self._run_deferred_refresh)
                self.defer_timer = deferred
            except (RuntimeError, SystemError, TypeError):
                self.defer_timer = None

        periodic = self._new_timer()
        if periodic is not None:
            try:
                periodic.setInterval(1800)
                periodic.timeout.connect(self.refresh)
                periodic.start()
                self.timer = periodic
            except (RuntimeError, SystemError, TypeError):
                self.timer = None

    def _run_deferred_refresh(self) -> None:
        self._refresh_pending = False
        self.refresh()

    def _request_refresh(self) -> None:
        if self._refresh_pending or self._refreshing:
            return
        self._refresh_pending = True
        if self.defer_timer is not None:
            try:
                self.defer_timer.start(0)
                return
            except (RuntimeError, SystemError, TypeError):
                self.defer_timer = None
        try:
            QTimer.singleShot(0, self._run_deferred_refresh)
        except (RuntimeError, SystemError, TypeError):
            # Last-resort synchronous pass. The re-entrancy guard in refresh()
            # prevents translation-triggered UI events from recursing forever.
            self._run_deferred_refresh()

    def set_language(self, language: str) -> None:
        self.language = normalize_language(language)
        self.refresh(force=True)

    def tr(self, text: Any) -> str:
        return translate_text(text, self.language)

    def eventFilter(self, watched: QObject, event: QEvent) -> bool:
        if self.language == ENGLISH:
            return False
        if event.type() in {
            QEvent.Type.Show,
            QEvent.Type.Polish,
            QEvent.Type.ChildAdded,
            QEvent.Type.WindowActivate,
        }:
            self._request_refresh()
        return False

    def refresh(self, force: bool = False) -> None:
        if self._refreshing or (self.language == ENGLISH and not force):
            return
        self._refreshing = True
        try:
            for window in self.app.topLevelWidgets():
                if force or window.isVisible():
                    self.translate_object(window, force=force)
        finally:
            self._refreshing = False

    def _translated_field(self, obj: QObject, key: str, current: str, force: bool = False) -> str:
        prop = f"_mr_i18n_{key}"
        original = obj.property(prop)
        if original is None or force:
            if original is None:
                original = current
                obj.setProperty(prop, original)
        expected = self.tr(original)
        if not force and current not in {str(original), expected}:
            original = current
            obj.setProperty(prop, original)
            expected = self.tr(original)
        return expected

    def translate_object(self, obj: QObject | None, force: bool = False) -> None:
        if obj is None:
            return
        try:
            if isinstance(obj, QWidget):
                title = obj.windowTitle()
                if title:
                    translated = self._translated_field(obj, "window_title", title, force)
                    if title != translated:
                        obj.setWindowTitle(translated)
                tooltip = obj.toolTip()
                if tooltip:
                    translated = self._translated_field(obj, "tooltip", tooltip, force)
                    if tooltip != translated:
                        obj.setToolTip(translated)
                status_tip = obj.statusTip()
                if status_tip:
                    translated = self._translated_field(obj, "status_tip", status_tip, force)
                    if status_tip != translated:
                        obj.setStatusTip(translated)
                whats_this = obj.whatsThis()
                if whats_this:
                    translated = self._translated_field(obj, "whats_this", whats_this, force)
                    if whats_this != translated:
                        obj.setWhatsThis(translated)

            if isinstance(obj, (QLabel, QAbstractButton)):
                text = obj.text()
                if text:
                    translated = self._translated_field(obj, "text", text, force)
                    if text != translated:
                        obj.setText(translated)

            if isinstance(obj, QGroupBox):
                title = obj.title()
                if title:
                    translated = self._translated_field(obj, "group_title", title, force)
                    if title != translated:
                        obj.setTitle(translated)

            if isinstance(obj, (QLineEdit, QPlainTextEdit, QTextEdit)):
                placeholder = obj.placeholderText()
                if placeholder:
                    translated = self._translated_field(obj, "placeholder", placeholder, force)
                    if placeholder != translated:
                        obj.setPlaceholderText(translated)

            if isinstance(obj, QDockWidget):
                title = obj.windowTitle()
                if title:
                    translated = self._translated_field(obj, "dock_title", title, force)
                    if title != translated:
                        obj.setWindowTitle(translated)

            if isinstance(obj, QComboBox):
                source = getattr(obj, "_mr_i18n_combo_source", None)
                current = [obj.itemText(i) for i in range(obj.count())]
                if source is None or len(source) != obj.count():
                    source = list(current)
                    setattr(obj, "_mr_i18n_combo_source", source)
                for i, original in enumerate(source):
                    current_item = obj.itemText(i)
                    expected = self.tr(original)
                    if not force and current_item not in {original, expected}:
                        original = current_item
                        source[i] = original
                    desired = self.tr(original)
                    if obj.itemText(i) != desired:
                        obj.setItemText(i, desired)

            if isinstance(obj, QTabWidget):
                source = getattr(obj, "_mr_i18n_tab_source", None)
                current = [obj.tabText(i) for i in range(obj.count())]
                if source is None or len(source) != obj.count():
                    source = list(current)
                    setattr(obj, "_mr_i18n_tab_source", source)
                for i, original in enumerate(source):
                    current_tab = obj.tabText(i)
                    expected = self.tr(original)
                    if not force and current_tab not in {original, expected}:
                        original = current_tab
                        source[i] = original
                    desired = self.tr(original)
                    if obj.tabText(i) != desired:
                        obj.setTabText(i, desired)

            if isinstance(obj, QTableWidget):
                for row in range(obj.rowCount()):
                    for column in range(obj.columnCount()):
                        item = obj.item(row, column)
                        if item is None:
                            continue
                        current = item.text()
                        key = f"_mr_i18n_table_cell_{row}_{column}"
                        original = obj.property(key)
                        if original is None or (current not in {str(original), self.tr(original)}):
                            original = current
                            obj.setProperty(key, original)
                        desired = self.tr(original)
                        if current != desired:
                            item.setText(desired)

            if isinstance(obj, QListWidget):
                source = getattr(obj, "_mr_i18n_list_source", None)
                current = [obj.item(i).text() for i in range(obj.count())]
                if source is None or len(source) != obj.count():
                    source = list(current)
                    setattr(obj, "_mr_i18n_list_source", source)
                for i, original in enumerate(source):
                    item = obj.item(i)
                    now = item.text()
                    expected = self.tr(original)
                    if not force and now not in {original, expected}:
                        original = now
                        source[i] = original
                    desired = self.tr(original)
                    if now != desired:
                        item.setText(desired)

            if isinstance(obj, QTreeWidget):
                def translate_tree_item(item):
                    for column in range(obj.columnCount()):
                        now = item.text(column)
                        if now:
                            role = 0x0100 + 313
                            original = item.data(column, role)
                            if original is None or (not force and now not in {str(original), self.tr(original)}):
                                original = now
                                item.setData(column, role, original)
                            desired = self.tr(original)
                            if now != desired:
                                item.setText(column, desired)
                    for child_index in range(item.childCount()):
                        translate_tree_item(item.child(child_index))
                for top_index in range(obj.topLevelItemCount()):
                    translate_tree_item(obj.topLevelItem(top_index))

            if isinstance(obj, (QSpinBox, QDoubleSpinBox)):
                for field, getter, setter in (
                    ("spin_prefix", obj.prefix, obj.setPrefix),
                    ("spin_suffix", obj.suffix, obj.setSuffix),
                    ("spin_special", obj.specialValueText, obj.setSpecialValueText),
                ):
                    current = getter()
                    if current:
                        translated = self._translated_field(obj, field, current, force)
                        if current != translated:
                            setter(translated)

            if isinstance(obj, QProgressBar):
                current = obj.format()
                if current:
                    translated = self._translated_field(obj, "progress_format", current, force)
                    if current != translated:
                        obj.setFormat(translated)

            if isinstance(obj, QToolBox):
                source = getattr(obj, "_mr_i18n_toolbox_source", None)
                current = [obj.itemText(i) for i in range(obj.count())]
                if source is None or len(source) != obj.count():
                    source = list(current)
                    setattr(obj, "_mr_i18n_toolbox_source", source)
                for i, original in enumerate(source):
                    desired = self.tr(original)
                    if obj.itemText(i) != desired:
                        obj.setItemText(i, desired)

            if isinstance(obj, QTableWidget):
                for axis, count, getter in (
                    ("h", obj.columnCount(), obj.horizontalHeaderItem),
                    ("v", obj.rowCount(), obj.verticalHeaderItem),
                ):
                    for index in range(count):
                        item = getter(index)
                        if item is None:
                            continue
                        current = item.text()
                        key = f"_mr_i18n_{axis}_{index}"
                        original = obj.property(key)
                        if original is None:
                            original = current
                            obj.setProperty(key, original)
                        desired = self.tr(original)
                        if current != desired:
                            item.setText(desired)

            if isinstance(obj, QAction):
                text = obj.text()
                if text:
                    translated = self._translated_field(obj, "action_text", text, force)
                    if text != translated:
                        obj.setText(translated)
                tooltip = obj.toolTip()
                if tooltip:
                    translated = self._translated_field(obj, "action_tooltip", tooltip, force)
                    if tooltip != translated:
                        obj.setToolTip(translated)
                status_tip = obj.statusTip()
                if status_tip:
                    translated = self._translated_field(obj, "action_status", status_tip, force)
                    if status_tip != translated:
                        obj.setStatusTip(translated)

            if isinstance(obj, QSystemTrayIcon):
                tooltip = obj.toolTip()
                if tooltip:
                    translated = self._translated_field(obj, "tray_tooltip", tooltip, force)
                    if tooltip != translated:
                        obj.setToolTip(translated)

            if isinstance(obj, QMenu):
                for action in obj.actions():
                    self.translate_object(action, force=force)

            for child in obj.children():
                self.translate_object(child, force=force)
        except RuntimeError:
            # A Qt object may be deleted while a deferred translation pass is running.
            return


def install_i18n(app: QApplication, language: str | None = None) -> LanguageManager:
    existing = getattr(app, "_mr_language_manager", None)
    if isinstance(existing, LanguageManager):
        if language is not None:
            existing.set_language(language)
        return existing
    manager = LanguageManager(app, language)
    setattr(app, "_mr_language_manager", manager)
    return manager


def get_i18n(app: QApplication | None = None) -> LanguageManager | None:
    application = app or QApplication.instance()
    return getattr(application, "_mr_language_manager", None) if application else None



def combo_value(combo: QComboBox) -> str:
    """Return the original semantic value even when the displayed item is translated."""
    source = getattr(combo, "_mr_i18n_combo_source", None)
    index = combo.currentIndex()
    if isinstance(source, list) and 0 <= index < len(source):
        return str(source[index])
    return combo.currentText()


def set_app_language(language: str, app: QApplication | None = None) -> None:
    application = app or QApplication.instance()
    if application is None:
        return
    install_i18n(application, language)


def tr(text: Any, language: str | None = None) -> str:
    manager = get_i18n()
    if manager is not None and language is None:
        return manager.tr(text)
    return translate_text(text, language)
