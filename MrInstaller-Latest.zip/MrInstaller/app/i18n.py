from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any

from PySide6.QtCore import QEvent, QObject, QTimer
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QAbstractButton,
    QApplication,
    QComboBox,
    QDockWidget,
    QGroupBox,
    QLabel,
    QLineEdit,
    QMenu,
    QPlainTextEdit,
    QSystemTrayIcon,
    QTabWidget,
    QTableWidget,
    QTextEdit,
    QWidget,
)

ENGLISH = "en"
TURKISH = "tr"
SUPPORTED_LANGUAGES = (ENGLISH, TURKISH)


def _state_path() -> Path:
    if os.name == "nt":
        base = Path(os.getenv("APPDATA", Path.home() / "AppData" / "Roaming"))
    else:
        base = Path(os.getenv("XDG_CONFIG_HOME", Path.home() / ".config"))
    return base / "MrInstaller" / "state.json"


def normalize_language(value: Any) -> str:
    text = str(value or "").strip().lower().replace("_", "-")
    if text in {"tr", "tr-tr", "turkish", "türkçe", "turkce"}:
        return TURKISH
    return ENGLISH


def load_language() -> str:
    path = _state_path()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return normalize_language(data.get("settings", {}).get("language", ENGLISH))
    except Exception:
        return ENGLISH


def language_name(code: str) -> str:
    return "Türkçe" if normalize_language(code) == TURKISH else "English"


# Exact translations for common interface text and the most visible app-specific text.
_EXACT_TR: dict[str, str] = {
    # Shared
    "English": "İngilizce",
    "Turkish": "Türkçe",
    "Language": "Dil",
    "Settings": "Ayarlar",
    "Save": "Kaydet",
    "Cancel": "İptal",
    "Close": "Kapat",
    "Exit": "Çıkış",
    "Quit": "Çık",
    "Apply": "Uygula",
    "OK": "Tamam",
    "Yes": "Evet",
    "No": "Hayır",
    "Browse": "Gözat",
    "Open": "Aç",
    "Add": "Ekle",
    "Remove": "Kaldır",
    "Delete": "Sil",
    "Edit": "Düzenle",
    "Start": "Başlat",
    "Stop": "Durdur",
    "Pause": "Duraklat",
    "Resume": "Devam Et",
    "Refresh": "Yenile",
    "Retry": "Yeniden Dene",
    "Search": "Ara",
    "Name": "Ad",
    "Type": "Tür",
    "Status": "Durum",
    "Progress": "İlerleme",
    "Ready": "Hazır",
    "Running": "Çalışıyor",
    "Finished": "Tamamlandı",
    "Completed": "Tamamlandı",
    "Failed": "Başarısız",
    "Error": "Hata",
    "Warning": "Uyarı",
    "Information": "Bilgi",
    "None": "Yok",
    "Default": "Varsayılan",
    "Enabled": "Etkin",
    "Disabled": "Devre Dışı",
    "Required": "Gerekli",
    "Optional": "İsteğe Bağlı",
    "Installed": "Yüklü",
    "Available": "Mevcut",
    "Update": "Güncelle",
    "Install": "Yükle",
    "Uninstall": "Kaldır",
    "Launch": "Başlat",
    "Instructions": "Talimatlar",
    "Tips": "İpuçları",
    "Before installation": "Yüklemeden önce",
    "After installation": "Yüklemeden sonra",
    "Dependencies": "Gerekli bileşenler",
    "Description": "Açıklama",
    "Category": "Kategori",
    "Version": "Sürüm",
    "File": "Dosya",
    "View": "Görünüm",
    "Help": "Yardım",
    "About": "Hakkında",
    "Home": "Ana Sayfa",
    "Audio": "Ses",
    "Video": "Video",
    "Image": "Görsel",
    "Utilities": "Araçlar",
    "Converter": "Dönüştürücü",
    "Output": "Çıktı",
    "Input": "Girdi",
    "Quality": "Kalite",
    "Format": "Biçim",
    "Folder": "Klasör",
    "Select file": "Dosya seç",
    "Select files": "Dosyaları seç",
    "Choose folder": "Klasör seç",
    "Open output folder": "Çıktı klasörünü aç",
    "Open export folder": "Dışa aktarma klasörünü aç",
    "Open project folder": "Proje klasörünü aç",
    "Processing Log": "İşlem Günlüğü",
    "Export Queue": "Dışa Aktarma Kuyruğu",
    "AI Tools": "Yapay Zekâ Araçları",
    "Video Studio": "Video Stüdyosu",
    "Audio Studio": "Ses Stüdyosu",
    "Image Studio": "Görsel Stüdyosu",
    "Utility Lab": "Araç Laboratuvarı",
    "Change settings": "Ayarları değiştir",
    "No description added yet.": "Henüz açıklama eklenmedi.",
    "No files selected.": "Dosya seçilmedi.",
    "No file selected": "Dosya seçilmedi",
    "Select an item first.": "Önce bir öğe seçin.",
    "Are you sure?": "Emin misiniz?",
    # MrInstaller
    "Installer Settings": "Yükleyici Ayarları",
    "Installer settings": "Yükleyici ayarları",
    "Interface language": "Arayüz dili",
    "English is used by default. This language is shared by MrInstaller and every Mr app.": "Varsayılan dil İngilizcedir. Bu dil MrInstaller ve tüm Mr uygulamaları tarafından ortak kullanılır.",
    "These settings control where apps are installed and which shortcuts are selected by default.": "Bu ayarlar uygulamaların nereye yükleneceğini ve varsayılan olarak hangi kısayolların seçileceğini belirler.",
    "Default installation folder": "Varsayılan yükleme klasörü",
    "Create desktop shortcuts by default": "Varsayılan olarak masaüstü kısayolları oluştur",
    "Create Start Menu shortcuts by default": "Varsayılan olarak Başlat Menüsü kısayolları oluştur",
    "Check online for updates when MrInstaller starts": "MrInstaller açıldığında çevrimiçi güncellemeleri denetle",
    "Choose installation folder": "Yükleme klasörünü seç",
    "Invalid folder": "Geçersiz klasör",
    "Choose an install folder.": "Bir yükleme klasörü seçin.",
    "All apps": "Tüm uygulamalar",
    "Check for updates": "Güncellemeleri denetle",
    "Checking for updates…": "Güncellemeler denetleniyor…",
    "Mr Apps": "Mr Uygulamaları",
    "Install your personal tools, required components, setup instructions, and fixes in one place.": "Kişisel araçlarınızı, gerekli bileşenleri, kurulum talimatlarını ve düzeltmeleri tek yerden yükleyin.",
    "Search apps…": "Uygulamalarda ara…",
    "Each app can include setup instructions, fixes, dependency installers, and restart warnings.": "Her uygulama kurulum talimatları, düzeltmeler, bileşen yükleyicileri ve yeniden başlatma uyarıları içerebilir.",
    "External software is never installed silently. MrInstaller shows the source, warnings, and asks first.": "Harici yazılımlar asla sessizce yüklenmez. MrInstaller kaynağı ve uyarıları gösterir, ardından onay ister.",
    "No apps added yet": "Henüz uygulama eklenmedi",
    "No apps match this view": "Bu görünüme uyan uygulama yok",
    "Try another search or category.": "Başka bir arama veya kategori deneyin.",
    "Update available": "Güncelleme mevcut",
    "Package changed": "Paket değişti",
    "Restart required": "Yeniden başlatma gerekli",
    "Install component": "Bileşeni yükle",
    "Open official website": "Resmî web sitesini aç",
    "Download and install": "İndir ve yükle",
    "Installation cancelled": "Yükleme iptal edildi",
    "Preparing installation": "Yükleme hazırlanıyor",
    "Creating shortcuts": "Kısayollar oluşturuluyor",
    "Removing files": "Dosyalar kaldırılıyor",
    "Updating installer state": "Yükleyici durumu güncelleniyor",
    "Creating a private app environment": "Özel uygulama ortamı oluşturuluyor",
    "Installing required app components": "Gerekli uygulama bileşenleri yükleniyor",
    "Connecting to download": "İndirmeye bağlanılıyor",
    "Download ready": "İndirme hazır",
    "Cancelling safely…": "Güvenli şekilde iptal ediliyor…",
    # MrDownloader
    "Available formats": "Mevcut biçimler",
    "yt-dlp, without the command line": "Komut satırı olmadan yt-dlp",
    "Checking FFmpeg…": "FFmpeg denetleniyor…",
    "Checking Deno…": "Deno denetleniyor…",
    "Downloads stay on this PC\nNo account • No cloud queue": "İndirmeler bu bilgisayarda kalır\nHesap yok • Bulut kuyruğu yok",
    "Download queue": "İndirme kuyruğu",
    "Paste one link per line, or paste an entire block of text. MrDownloader extracts every supported URL and can process several links at once.": "Her satıra bir bağlantı yapıştırın veya tüm metin bloğunu ekleyin. MrDownloader desteklenen URL'leri çıkarır ve birden fazla bağlantıyı aynı anda işleyebilir.",
    "Add links": "Bağlantı ekle",
    "Paste YouTube video, playlist, Shorts, music, or other yt-dlp-supported links here…": "YouTube videosu, oynatma listesi, Shorts, müzik veya yt-dlp destekli diğer bağlantıları buraya yapıştırın…",
    "Paste clipboard": "Panodan yapıştır",
    "Import .txt": ".txt içe aktar",
    "Inspect first link": "İlk bağlantıyı incele",
    "Add to queue": "Kuyruğa ekle",
    "Start queue": "Kuyruğu başlat",
    "Cancel selected": "Seçileni iptal et",
    "Clear finished": "Tamamlananları temizle",
    "These settings are copied into each new queue item. Existing active downloads keep the settings they started with.": "Bu ayarlar her yeni kuyruk öğesine kopyalanır. Etkin indirmeler başladıkları ayarları kullanmaya devam eder.",
    "Video + audio": "Video + ses",
    "Audio only": "Yalnızca ses",
    "Video only": "Yalnızca video",
    "Best available": "Mevcut en iyi",
    "Only the linked video": "Yalnızca bağlantıdaki video",
    "Playlist range": "Oynatma listesi aralığı",
    "Playlist folders": "Oynatma listesi klasörleri",
    "Download failed": "İndirme başarısız",
    "Cancelled by user": "Kullanıcı tarafından iptal edildi",
    "MrDownloader currently supports Windows 10 and Windows 11.": "MrDownloader şu anda Windows 10 ve Windows 11'i destekler.",
    # MrMacro
    "MrMacro currently supports Windows 10/11 only.": "MrMacro şu anda yalnızca Windows 10/11'i destekler.",
    "New Macro": "Yeni Makro",
    "Record": "Kaydet",
    "Play": "Oynat",
    "Emergency Stop": "Acil Durdurma",
    "Keyboard: Press Key": "Klavye: Tuşa Bas",
    "Keyboard: Key Down": "Klavye: Tuşu Basılı Tut",
    "Keyboard: Key Up": "Klavye: Tuşu Bırak",
    "Keyboard: Type Text": "Klavye: Metin Yaz",
    "Mouse: Move Absolute": "Fare: Mutlak Konuma Taşı",
    "Mouse: Recorded Path": "Fare: Kaydedilmiş Yol",
    "Mouse: Move Relative": "Fare: Göreli Taşı",
    "Mouse: Click": "Fare: Tıkla",
    "Mouse: Button Down": "Fare: Düğmeyi Basılı Tut",
    "Mouse: Button Up": "Fare: Düğmeyi Bırak",
    "Mouse: Scroll": "Fare: Kaydır",
    "Timing: Delay": "Zamanlama: Gecikme",
    "Condition: Wait for Pixel": "Koşul: Pikseli Bekle",
    "Condition: Wait for Image": "Koşul: Görseli Bekle",
    "Control: Loop Start": "Denetim: Döngü Başlangıcı",
    "Control: Loop End": "Denetim: Döngü Sonu",
    "Control: Comment": "Denetim: Yorum",
    "No input is sent": "Girdi gönderilmez",
    "Repeat block": "Bloğu tekrarla",
    "Return to nearest Loop Start": "En yakın Döngü Başlangıcına dön",
    "MrMacro crashed": "MrMacro çöktü",
    "An unexpected error occurred.": "Beklenmeyen bir hata oluştu.",
    # MrSoundboard
    "Audio routing needs attention": "Ses yönlendirmesi kontrol edilmeli",
    "Primary output": "Birincil çıkış",
    "Monitor output": "Dinleme çıkışı",
    "Microphone input": "Mikrofon girişi",
    "Soundboard": "Ses Paneli",
    "Add sound": "Ses ekle",
    "Live microphone": "Canlı mikrofon",
    "Mix my microphone into Primary output": "Mikrofonumu Birincil çıkışa karıştır",
    "Keep running in the system tray": "Sistem tepsisinde çalışmaya devam et",
    "Test audio routing": "Ses yönlendirmesini test et",
    "MrSoundboard failed to start": "MrSoundboard başlatılamadı",
    "MrSoundboard could not start.": "MrSoundboard başlatılamadı.",
    "No microphone inputs were found.": "Mikrofon girişi bulunamadı.",
    "Diagnostic failed:": "Tanılama başarısız:",
    "Saved recording:": "Kayıt kaydedildi:",
    "Press Enter to close...": "Kapatmak için Enter'a basın...",
    # MrStudio
    "LOCAL CREATIVE SUITE": "YEREL YARATICI PAKET",
    "Account-free": "Hesapsız",
    "Local": "Yerel",
    "Ready — processing stays local on this computer": "Hazır — işlemler bu bilgisayarda yerel olarak kalır",
    "Settings updated": "Ayarlar güncellendi",
    "About MrStudio": "MrStudio Hakkında",
    "MrStudio failed to start": "MrStudio başlatılamadı",
    "Opening image": "Görsel açılıyor",
    "Loading segmentation model": "Bölütleme modeli yükleniyor",
    "Saving transparent PNG": "Şeffaf PNG kaydediliyor",
    "Background removed": "Arka plan kaldırıldı",
    "Preparing vocal separation": "Vokal ayırma hazırlanıyor",
    "Vocal separation complete": "Vokal ayırma tamamlandı",
    "Loading separation model": "Ayırma modeli yükleniyor",
    "Collecting separated tracks": "Ayrılmış parçalar toplanıyor",
    "Separating vocals and music": "Vokal ve müzik ayrılıyor",
    "Vocal Remover": "Vokal Ayırıcı",
    "Background Remover": "Arka Plan Kaldırıcı",
    "Transparent PNG": "Şeffaf PNG",
    "Auto contrast": "Otomatik kontrast",
    "Top left": "Sol üst",
    "Top right": "Sağ üst",
    "Bottom left": "Sol alt",
    "Bottom right": "Sağ alt",
    "Open an image first.": "Önce bir görsel açın.",
    "No source image is loaded.": "Kaynak görsel yüklenmedi.",
    "File size:": "Dosya boyutu:",
    "Image info:": "Görsel bilgisi:",
    "EXIF fields:": "EXIF alanları:",
    # Additional MrDownloader interface text
    "No link": "Bağlantı yok",
    "Save to": "Kaydetme yeri",
    "Copy all": "Tümünü kopyala",
    "End item": "Öğeyi bitir",
    "No limit": "Sınır yok",
    "Clear log": "Günlüğü temizle",
    "Deno ready": "Deno hazır",
    "Start item": "Öğeyi başlat",
    "Audio codec": "Ses kodeği",
    "Video codec": "Video kodeği",
    "Speed / ETA": "Hız / Tahmini süre",
    "Title / URL": "Başlık / URL",
    "Activity log": "Etkinlik günlüğü",
    "Audio format": "Ses biçimi",
    "FFmpeg ready": "FFmpeg hazır",
    "Output files": "Çıktı dosyaları",
    "Download type": "İndirme türü",
    "Naming layout": "Adlandırma düzeni",
    "Save settings": "Ayarları kaydet",
    "Bitrate / note": "Bit hızı / not",
    "Embed chapters": "Bölümleri göm",
    "FFmpeg missing": "FFmpeg eksik",
    "Invalid format": "Geçersiz biçim",
    "No links found": "Bağlantı bulunamadı",
    "Queue is empty": "Kuyruk boş",
    "Settings saved": "Ayarlar kaydedildi",
    "What it can do": "Neler yapabilir",
    "Import URL list": "URL listesini içe aktar",
    "Use responsibly": "Sorumlu kullanın",
    "Video container": "Video kapsayıcısı",
    "Deno recommended": "Deno önerilir",
    "Invalid template": "Geçersiz şablon",
    "Unknown uploader": "Bilinmeyen yükleyici",
    "About MrDownloader": "MrDownloader Hakkında",
    "Choose cookies.txt": "cookies.txt dosyasını seç",
    "Format and quality": "Biçim ve kalite",
    "Or use cookies.txt": "Veya cookies.txt kullan",
    "Simultaneous links": "Eşzamanlı bağlantılar",
    "Fragments per video": "Video başına parçalar",
    "Required components": "Gerekli bileşenler",
    "Maximum video quality": "Maksimum video kalitesi",
    "Custom output template": "Özel çıktı şablonu",
    "Download full playlist": "Tüm oynatma listesini indir",
    "Finished successfully.": "Başarıyla tamamlandı.",
    "Audio bitrate / quality": "Ses bit hızı / kalitesi",
    "SponsorBlock categories": "SponsorBlock kategorileri",
    "Overwrite existing files": "Mevcut dosyaların üzerine yaz",
    "Read cookies from browser": "Tarayıcı çerezlerini oku",
    "Authentication and network": "Kimlik doğrulama ve ağ",
    "Performance and reliability": "Performans ve güvenilirlik",
    "Queue activity will appear here…": "Kuyruk etkinliği burada görünecek…",
    "New queue items will use these settings.": "Yeni kuyruk öğeleri bu ayarları kullanacak.",
    "Resume partial downloads when possible": "Mümkün olduğunda yarım indirmelere devam et",
    "Skip items already downloaded by MrDownloader": "MrDownloader tarafından daha önce indirilen öğeleri atla",
    "Use restricted ASCII-only filenames": "Yalnızca sınırlı ASCII dosya adları kullan",
    # Additional MrMacro interface text
    "New Macro": "Yeni Makro",
    "No hotkey": "Kısayol yok",
    "Play once": "Bir kez oynat",
    "Add Action": "Eylem Ekle",
    "Macro name": "Makro adı",
    "On timeout": "Zaman aşımında",
    "Button hold": "Düğme basılı tutma",
    "Click count": "Tıklama sayısı",
    "Ease in/out": "Yumuşak giriş/çıkış",
    "Mouse wheel": "Fare tekerleği",
    "App Settings": "Uygulama Ayarları",
    "Delete macro": "Makroyu sil",
    "Export macro": "Makroyu dışa aktar",
    "Motion curve": "Hareket eğrisi",
    "Mouse button": "Fare düğmesi",
    "Playing loop": "Döngü oynatılıyor",
    "Repeat count": "Tekrar sayısı",
    "Save Project": "Projeyi Kaydet",
    "Target color": "Hedef renk",
    "About MrMacro": "MrMacro Hakkında",
    "Global hotkey": "Genel kısayol",
    "Hold duration": "Basılı tutma süresi",
    "Import Macro…": "Makro İçe Aktar…",
    "Macro Options": "Makro Seçenekleri",
    "Mouse buttons": "Fare düğmeleri",
    "Play Selected": "Seçileni Oynat",
    "Record Toggle": "Kayıt Aç/Kapat",
    "Search region": "Arama bölgesi",
    "Behavior notes": "Davranış notları",
    "Emergency Stop": "Acil Durdurma",
    "Global hotkeys": "Genel kısayollar",
    "Mouse movement": "Fare hareketi",
    "Playing macro…": "Makro oynatılıyor…",
    "Press one key…": "Bir tuşa basın…",
    "Search macros…": "Makrolarda ara…",
    "Untitled Macro": "Adsız Makro",
    "Playback timing": "Oynatma zamanlaması",
    "Reference image": "Referans görsel",
    "Timeline Editor": "Zaman Çizelgesi Düzenleyicisi",
    "Add Macro Action": "Makro Eylemi Ekle",
    "Autosave failed:": "Otomatik kaydetme başarısız:",
    "Coordinate space": "Koordinat alanı",
    "Execution chance": "Çalıştırma olasılığı",
    "Macro validation": "Makro doğrulaması",
    "Open Data Folder": "Veri Klasörünü Aç",
    "Polish Recording": "Kaydı İyileştir",
    "Recording input…": "Girdi kaydediliyor…",
    "Speed multiplier": "Hız çarpanı",
    "Action is enabled": "Eylem etkin",
    "Edit Macro Action": "Makro Eylemini Düzenle",
    "Movement duration": "Hareket süresi",
    "Recovered Project": "Kurtarılan Proje",
    "Start Recording": "Kaydı Başlat",
    "Character interval": "Karakter aralığı",
    "Minimum confidence": "Minimum güven",
    "Recording controls": "Kayıt denetimleri",
    "Delay before action": "Eylem öncesi gecikme",
    "Play Selected Macro": "Seçili Makroyu Oynat",
    "Edit Selected Action": "Seçili Eylemi Düzenle",
    "Image wait timed out": "Görsel bekleme zaman aşımına uğradı",
    "Pixel wait timed out": "Piksel bekleme zaman aşımına uğradı",
    "Playback and binding": "Oynatma ve atama",
    "Toggle infinite loop": "Sonsuz döngüyü aç/kapat",
    "Delay before playback": "Oynatma öncesi gecikme",
    "Choose reference image": "Referans görsel seç",
    "Entire virtual desktop": "Tüm sanal masaüstü",
    "Start / stop recording": "Kaydı başlat / durdur",
    "The timeline is empty.": "Zaman çizelgesi boş.",
    "Additional delay jitter": "Ek gecikme sapması",
    "Mouse movement filtering": "Fare hareketi filtreleme",
    "Noise filtering distance": "Gürültü filtreleme mesafesi",
    "Target window (optional)": "Hedef pencere (isteğe bağlı)",
    "Loop count (0 = infinite)": "Döngü sayısı (0 = sonsuz)",
    "This macro has no actions.": "Bu makroda eylem yok.",
    "Repeat while hotkey is held": "Kısayol basılıyken tekrarla",
    "Use current cursor position": "Geçerli imleç konumunu kullan",
    "Stop recording before playback.": "Oynatmadan önce kaydı durdurun.",
    "Global safety and control hotkeys": "Genel güvenlik ve denetim kısayolları",
    "No timeline problems were detected.": "Zaman çizelgesinde sorun bulunmadı.",
    # Additional MrSoundboard interface text
    "Fade in": "Yavaşça aç",
    "Fade out": "Yavaşça kapat",
    "No data": "Veri yok",
    "New Sound": "Yeni Ses",
    "Add Sounds": "Sesler Ekle",
    "All Sounds": "Tüm Sesler",
    "Audio file": "Ses dosyası",
    "New profile": "Yeni profil",
    "New Profile": "Yeni Profil",
    "Add sounds": "Sesler ekle",
    "Audio output": "Ses çıkışı",
    "Button color": "Düğme rengi",
    "Choose Audio": "Ses Seç",
    "Delete sound": "Sesi sil",
    "Grid columns": "Izgara sütunları",
    "Input device": "Giriş aygıtı",
    "Missing file": "Dosya eksik",
    "Missing name": "Ad eksik",
    "Audio devices": "Ses aygıtları",
    "Button height": "Düğme yüksekliği",
    "Global hotkey": "Genel kısayol",
    "Profile name:": "Profil adı:",
    "Speed / pitch": "Hız / perde",
    "Stop and save": "Durdur ve kaydet",
    "Trim from end": "Sondan kırp",
    "Capture Hotkey": "Kısayolu Yakala",
    "Delete current": "Geçerliyi sil",
    "Delete profile": "Profili sil",
    "Export Profile": "Profili Dışa Aktar",
    "Import profile": "Profili içe aktar",
    "Import Profile": "Profili İçe Aktar",
    "Profile exists": "Profil mevcut",
    "Record a Sound": "Bir Ses Kaydet",
    "Rename current": "Geçerliyi yeniden adlandır",
    "Rename Profile": "Profili Yeniden Adlandır",
    "Reorder Sounds": "Sesleri Yeniden Sırala",
    "Search sounds…": "Seslerde ara…",
    "Sound Settings": "Ses Ayarları",
    "System default": "Sistem varsayılanı",
    "Play in reverse": "Tersten oynat",
    "Show audio file": "Ses dosyasını göster",
    "Start minimized": "Küçültülmüş başlat",
    "Start recording": "Kaydı başlat",
    "Stop all sounds": "Tüm sesleri durdur",
    "Stop this sound": "Bu sesi durdur",
    "Stop-all hotkey": "Tümünü durdurma kısayolu",
    "Trim from start": "Baştan kırp",
    "Microphone volume": "Mikrofon ses düzeyi",
    "Show MrSoundboard": "MrSoundboard'u Göster",
    "Soundboard volume": "Ses paneli ses düzeyi",
    "Loop until stopped": "Durdurulana kadar döngü",
    "Normalize peak volume": "Tepe ses düzeyini normalleştir",
    "Export portable bundle": "Taşınabilir paketi dışa aktar",
    "Give the sound a name.": "Sese bir ad verin.",
    "No audio was captured.": "Ses kaydedilmedi.",
    "Live microphone level": "Canlı mikrofon düzeyi",
    "Could not apply settings": "Ayarlar uygulanamadı",
    "Apply and test audio routing": "Ses yönlendirmesini uygula ve test et",
    "Keep window always on top": "Pencereyi her zaman üstte tut",
    "Confirm before deleting sounds": "Sesleri silmeden önce onay iste",
    "Profile exported successfully.": "Profil başarıyla dışa aktarıldı.",
    "Stop every playing sound first": "Önce çalan tüm sesleri durdurun",
    "Allow repeated triggers to overlap": "Tekrarlanan tetiklemelerin çakışmasına izin ver",
    "Drag rows to change the pad order.": "Ped sırasını değiştirmek için satırları sürükleyin.",
    "Enable soft limiter to prevent clipping": "Bozulmayı önlemek için yumuşak sınırlayıcıyı etkinleştir",
    "Drop audio files here or click “Add sounds”.": "Ses dosyalarını buraya bırakın veya “Sesler ekle”ye tıklayın.",
    "Changes speed and pitch together. 1.0 is original.": "Hız ve perdeyi birlikte değiştirir. 1.0 özgün değerdir.",
    "Speak into your microphone and confirm that the live level meter moves.": "Mikrofona konuşun ve canlı düzey göstergesinin hareket ettiğini doğrulayın.",
    # Additional MrStudio interface text
    "Save as": "Farklı kaydet",
    "Add text": "Metin ekle",
    "No files": "Dosya yok",
    "No image": "Görsel yok",
    "Add clips": "Klip ekle",
    "Add files": "Dosya ekle",
    "Font size": "Yazı tipi boyutu",
    "Gain (dB)": "Kazanç (dB)",
    "Max width": "Maksimum genişlik",
    "Move down": "Aşağı taşı",
    "Move up": "Yukarı taşı",
    "Not found": "Bulunamadı",
    "Safe copy": "Güvenli kopya",
    "Track row": "Parça satırı",
    "Video CRF": "Video CRF",
    "Add images": "Görsel ekle",
    "Add tracks": "Parça ekle",
    "Create PDF": "PDF Oluştur",
    "Frame rate": "Kare hızı",
    "Open image": "Görsel aç",
    "MP3 bitrate": "MP3 bit hızı",
    "Noise floor": "Gürültü tabanı",
    "PDF created": "PDF oluşturuldu",
    "Room reverb": "Oda yankısı",
    "Rotate 180°": "180° döndür",
    "Rotate left": "Sola döndür",
    "Rotate right": "Sağa döndür",
    "Sample rate": "Örnekleme hızı",
    "Audio edit": "Ses düzenleme",
    "Audio edit —": "Ses düzenleme —",
    "Image editor": "Görsel düzenleyici",
    "Image format": "Görsel biçimi",
    "Inspect file": "Dosyayı incele",
    "Load project": "Projeyi yükle",
    "Music volume": "Müzik ses düzeyi",
    "Peak limiter": "Tepe sınırlayıcı",
    "Quick editor": "Hızlı düzenleyici",
    "Remove audio": "Sesi kaldır",
    "Resize image": "Görseli yeniden boyutlandır",
    "Save project": "Projeyi kaydet",
    "Stroke width": "Çizgi kalınlığı",
    "Timeline row": "Zaman çizelgesi satırı",
    "Video edit": "Video düzenleme",
    "Video edit —": "Video düzenleme —",
    "Audio bitrate": "Ses bit hızı",
    "Choose output": "Çıktı seç",
    "Edge softness": "Kenar yumuşaklığı",
    "Export folder": "Dışa aktarma klasörü",
    "Flip vertical": "Dikey çevir",
    "Flip horizontal": "Yatay çevir",
    "Image batch": "Toplu görsel işlemi",
    "Image batch —": "Toplu görsel işlemi —",
    "Image quality": "Görsel kalitesi",
    "Images to PDF": "Görsellerden PDF",
    "Invalid color": "Geçersiz renk",
    "Output format": "Çıktı biçimi",
    "Parallel jobs": "Eşzamanlı işler",
    "Quality / CRF": "Kalite / CRF",
    "Reverb amount": "Yankı miktarı",
    "Reverse audio": "Sesi ters çevir",
    "Text position": "Metin konumu",
    "Burn subtitles": "Altyazıları videoya göm",
    "Clear finished": "Tamamlananları temizle",
    "Encoder preset": "Kodlayıcı ön ayarı",
    "External tools": "Harici araçlar",
    "Extract frames": "Kareleri çıkar",
    "File inspector": "Dosya inceleyici",
    "Final export": "Son dışa aktarma",
    "Final export —": "Son dışa aktarma —",
    "Missing output": "Çıktı eksik",
    "Missing source": "Kaynak eksik",
    "Quality shifts": "Kalite değişimleri",
    "Rendering clip": "Klip işleniyor",
    "Reset controls": "Denetimleri sıfırla",
    "Strip metadata": "Meta veriyi kaldır",
    "Add video clips": "Video klipleri ekle",
    "Apply watermark": "Filigran uygula",
    "Batch processor": "Toplu işlemci",
    "Detected FFmpeg": "FFmpeg algılandı",
    "Drop files here": "Dosyaları buraya bırakın",
    "Export behavior": "Dışa aktarma davranışı",
    "Export settings": "Dışa aktarma ayarları",
    "Frame extractor": "Kare çıkarıcı",
    "Image converted": "Görsel dönüştürüldü",
    "Image watermark": "Görsel filigranı",
    "No image loaded": "Görsel yüklenmedi",
    "One frame every": "Her şu aralıkta bir kare",
    "Remove selected": "Seçileni kaldır",
    "Render timeline": "Zaman çizelgesini işle",
    "Trim and timing": "Kırpma ve zamanlama",
    "Add audio tracks": "Ses parçaları ekle",
    "Background music": "Arka plan müziği",
    "Export audio mix": "Ses miksini dışa aktar",
    "Interactive crop": "Etkileşimli kırpma",
    "Invalid timeline": "Geçersiz zaman çizelgesi",
    "Metadata cleaner": "Meta veri temizleyici",
    "Metadata removed": "Meta veri kaldırıldı",
    "Multi-track mixer": "Çok parçalı mikser",
    "Refresh detection": "Algılamayı yenile",
    "Save edited image": "Düzenlenen görseli kaydet",
    "Source and output": "Kaynak ve çıktı",
    "Timing and motion": "Zamanlama ve hareket",
    "Watermark opacity": "Filigran saydamlığı",
    "Windows installer": "Windows yükleyicisi",
    "Apply adjustments": "Ayarlamaları uygula",
    "Applying overlays": "Katmanlar uygulanıyor",
    "Dynamic compressor": "Dinamik kompresör",
    "No output selected": "Çıktı seçilmedi",
    "Source and preview": "Kaynak ve önizleme",
    "Subtitle converted": "Altyazı dönüştürüldü",
    "Watermark position": "Filigran konumu",
    "Apply selected crop": "Seçili kırpmayı uygula",
    "Effects & mastering": "Efektler ve mastering",
    "Export edited video": "Düzenlenen videoyu dışa aktar",
    "FFT noise reduction": "FFT gürültü azaltma",
    "Installer not found": "Yükleyici bulunamadı",
    "Normalize final mix": "Son miksi normalleştir",
}

# Longer phrases are replaced before individual words. This gives useful Turkish
# coverage to dynamic status text without altering file names, URLs, or code-like values.
_PHRASE_TR: list[tuple[str, str]] = [
    ("Choose an installation folder", "Bir yükleme klasörü seçin"),
    ("Check for updates", "Güncellemeleri denetle"),
    ("checking for updates", "güncellemeler denetleniyor"),
    ("update available", "güncelleme mevcut"),
    ("package changed", "paket değişti"),
    ("restart required", "yeniden başlatma gerekli"),
    ("open output folder", "çıktı klasörünü aç"),
    ("open export folder", "dışa aktarma klasörünü aç"),
    ("output folder", "çıktı klasörü"),
    ("input file", "girdi dosyası"),
    ("output file", "çıktı dosyası"),
    ("select files", "dosyaları seç"),
    ("select file", "dosya seç"),
    ("choose folder", "klasör seç"),
    ("download queue", "indirme kuyruğu"),
    ("export queue", "dışa aktarma kuyruğu"),
    ("processing log", "işlem günlüğü"),
    ("start download", "indirmeyi başlat"),
    ("cancel download", "indirmeyi iptal et"),
    ("download complete", "indirme tamamlandı"),
    ("download failed", "indirme başarısız"),
    ("installation complete", "yükleme tamamlandı"),
    ("installation failed", "yükleme başarısız"),
    ("creating shortcuts", "kısayollar oluşturuluyor"),
    ("preparing installation", "yükleme hazırlanıyor"),
    ("required components", "gerekli bileşenler"),
    ("optional component", "isteğe bağlı bileşen"),
    ("not installed", "yüklü değil"),
    ("not found", "bulunamadı"),
    ("no results", "sonuç yok"),
    ("no items", "öğe yok"),
    ("are you sure", "emin misiniz"),
    ("please select", "lütfen seçin"),
    ("please choose", "lütfen seçin"),
    ("could not", "başarısız oldu"),
    ("failed to", "başarısız:"),
    ("successfully", "başarıyla"),
    ("in progress", "devam ediyor"),
    ("drag and drop", "sürükleyip bırakın"),
    ("click to", "tıklayarak"),
    ("double-click", "çift tıklayın"),
    ("right-click", "sağ tıklayın"),
    ("keyboard shortcut", "klavye kısayolu"),
    ("global hotkey", "genel kısayol"),
    ("microphone input", "mikrofon girişi"),
    ("primary output", "birincil çıkış"),
    ("monitor output", "dinleme çıkışı"),
    ("audio device", "ses aygıtı"),
    ("background remover", "arka plan kaldırıcı"),
    ("vocal remover", "vokal ayırıcı"),
    ("audio only", "yalnızca ses"),
    ("video only", "yalnızca video"),
    ("best available", "mevcut en iyi"),
    ("frame rate", "kare hızı"),
    ("sample rate", "örnekleme hızı"),
    ("bit rate", "bit hızı"),
    ("file size", "dosya boyutu"),
]

_WORD_TR: dict[str, str] = {
    "all": "tümü", "apps": "uygulamalar", "app": "uygulama", "installed": "yüklü",
    "available": "mevcut", "install": "yükle", "uninstall": "kaldır", "update": "güncelle",
    "launch": "başlat", "instructions": "talimatlar", "settings": "ayarlar", "language": "dil",
    "save": "kaydet", "cancel": "iptal", "close": "kapat", "open": "aç", "browse": "gözat",
    "select": "seç", "choose": "seç", "add": "ekle", "remove": "kaldır", "delete": "sil",
    "edit": "düzenle", "start": "başlat", "stop": "durdur", "pause": "duraklat",
    "resume": "devam et", "reset": "sıfırla", "clear": "temizle", "search": "ara",
    "ready": "hazır", "running": "çalışıyor", "finished": "tamamlandı", "complete": "tamamlandı",
    "completed": "tamamlandı", "failed": "başarısız", "error": "hata", "warning": "uyarı",
    "required": "gerekli", "optional": "isteğe bağlı", "folder": "klasör", "file": "dosya",
    "files": "dosyalar", "output": "çıktı", "input": "girdi", "quality": "kalite",
    "format": "biçim", "formats": "biçimler", "video": "video", "audio": "ses", "image": "görsel",
    "images": "görseller", "download": "indir", "downloads": "indirmeler", "queue": "kuyruk",
    "progress": "ilerleme", "status": "durum", "name": "ad", "description": "açıklama",
    "category": "kategori", "version": "sürüm", "default": "varsayılan", "enabled": "etkin",
    "disabled": "devre dışı", "yes": "evet", "no": "hayır", "none": "yok", "home": "ana sayfa",
    "help": "yardım", "about": "hakkında", "view": "görünüm", "tools": "araçlar",
    "tool": "araç", "converter": "dönüştürücü", "advanced": "gelişmiş", "basic": "temel",
    "local": "yerel", "online": "çevrimiçi", "desktop": "masaüstü", "shortcut": "kısayol",
    "shortcuts": "kısayollar", "restart": "yeniden başlat", "apply": "uygula", "copy": "kopyala",
    "paste": "yapıştır", "import": "içe aktar", "export": "dışa aktar", "record": "kaydet",
    "recording": "kayıt", "play": "oynat", "playback": "oynatma", "microphone": "mikrofon",
    "device": "aygıt", "devices": "aygıtlar", "volume": "ses düzeyi", "speed": "hız",
    "duration": "süre", "delay": "gecikme", "loop": "döngü", "loops": "döngüler",
    "action": "eylem", "actions": "eylemler", "hotkey": "kısayol", "hotkeys": "kısayollar",
    "keyboard": "klavye", "mouse": "fare", "button": "düğme", "buttons": "düğmeler",
    "new": "yeni", "duplicate": "çoğalt", "title": "başlık", "path": "yol", "size": "boyut",
    "width": "genişlik", "height": "yükseklik", "color": "renk", "background": "arka plan",
    "metadata": "meta veri", "subtitles": "altyazılar", "playlist": "oynatma listesi",
    "automatic": "otomatik", "manual": "manuel", "refresh": "yenile", "test": "test et",
}

_SKIP_RE = re.compile(r"^(?:https?://|[A-Za-z]:[\\/]|%\([^)]*\)|[\w.-]+\.(?:py|bat|exe|dll|json|txt|md|zip|png|jpg|jpeg|webp|wav|mp3|mp4|mkv|flac|opus|m4a|svg|ico))", re.I)


def _preserve_case(source: str, replacement: str) -> str:
    if source.isupper():
        return replacement.upper()
    if source[:1].isupper():
        return replacement[:1].upper() + replacement[1:]
    return replacement


def translate_text(text: Any, language: str | None = None) -> str:
    value = str(text if text is not None else "")
    if normalize_language(language or load_language()) != TURKISH or not value:
        return value
    if value in _EXACT_TR:
        return _EXACT_TR[value]
    stripped = value.strip()
    if not stripped or _SKIP_RE.search(stripped):
        return value

    result = value
    for source, target in sorted(_PHRASE_TR, key=lambda item: len(item[0]), reverse=True):
        pattern = re.compile(re.escape(source), re.I)
        result = pattern.sub(lambda m, t=target: _preserve_case(m.group(0), t), result)

    def replace_word(match: re.Match[str]) -> str:
        source = match.group(0)
        target = _WORD_TR.get(source.casefold())
        return _preserve_case(source, target) if target else source

    result = re.sub(r"(?<![\w])(?:[A-Za-z]+)(?![\w])", replace_word, result)
    return result


class LanguageManager(QObject):
    def __init__(self, app: QApplication, language: str | None = None) -> None:
        super().__init__(app)
        self.app = app
        self.language = normalize_language(language or load_language())
        app.installEventFilter(self)
        self.defer_timer = QTimer(self)
        self.defer_timer.setSingleShot(True)
        self.defer_timer.timeout.connect(self.refresh)
        self.timer = QTimer(self)
        self.timer.setInterval(1800)
        self.timer.timeout.connect(self.refresh)
        self.timer.start()

    def set_language(self, language: str) -> None:
        self.language = normalize_language(language)
        self.refresh(force=True)

    def tr(self, text: Any) -> str:
        return translate_text(text, self.language)

    def eventFilter(self, watched: QObject, event: QEvent) -> bool:
        if self.language == ENGLISH:
            return False
        if event.type() in {
            QEvent.Type.Show,
            QEvent.Type.Polish,
            QEvent.Type.ChildAdded,
            QEvent.Type.WindowActivate,
        } and not self.defer_timer.isActive():
            self.defer_timer.start(0)
        return False

    def refresh(self, force: bool = False) -> None:
        if self.language == ENGLISH and not force:
            return
        for window in self.app.topLevelWidgets():
            if force or window.isVisible():
                self.translate_object(window, force=force)

    def _translated_field(self, obj: QObject, key: str, current: str, force: bool = False) -> str:
        prop = f"_mr_i18n_{key}"
        original = obj.property(prop)
        if original is None or force:
            if original is None:
                original = current
                obj.setProperty(prop, original)
        expected = self.tr(original)
        if not force and current not in {str(original), expected}:
            original = current
            obj.setProperty(prop, original)
            expected = self.tr(original)
        return expected

    def translate_object(self, obj: QObject | None, force: bool = False) -> None:
        if obj is None:
            return
        try:
            if isinstance(obj, QWidget):
                title = obj.windowTitle()
                if title:
                    translated = self._translated_field(obj, "window_title", title, force)
                    if title != translated:
                        obj.setWindowTitle(translated)
                tooltip = obj.toolTip()
                if tooltip:
                    translated = self._translated_field(obj, "tooltip", tooltip, force)
                    if tooltip != translated:
                        obj.setToolTip(translated)
                status_tip = obj.statusTip()
                if status_tip:
                    translated = self._translated_field(obj, "status_tip", status_tip, force)
                    if status_tip != translated:
                        obj.setStatusTip(translated)
                whats_this = obj.whatsThis()
                if whats_this:
                    translated = self._translated_field(obj, "whats_this", whats_this, force)
                    if whats_this != translated:
                        obj.setWhatsThis(translated)

            if isinstance(obj, (QLabel, QAbstractButton)):
                text = obj.text()
                if text:
                    translated = self._translated_field(obj, "text", text, force)
                    if text != translated:
                        obj.setText(translated)

            if isinstance(obj, QGroupBox):
                title = obj.title()
                if title:
                    translated = self._translated_field(obj, "group_title", title, force)
                    if title != translated:
                        obj.setTitle(translated)

            if isinstance(obj, (QLineEdit, QPlainTextEdit, QTextEdit)):
                placeholder = obj.placeholderText()
                if placeholder:
                    translated = self._translated_field(obj, "placeholder", placeholder, force)
                    if placeholder != translated:
                        obj.setPlaceholderText(translated)

            if isinstance(obj, QDockWidget):
                title = obj.windowTitle()
                if title:
                    translated = self._translated_field(obj, "dock_title", title, force)
                    if title != translated:
                        obj.setWindowTitle(translated)

            if isinstance(obj, QComboBox):
                source = getattr(obj, "_mr_i18n_combo_source", None)
                current = [obj.itemText(i) for i in range(obj.count())]
                if source is None or len(source) != obj.count():
                    source = list(current)
                    setattr(obj, "_mr_i18n_combo_source", source)
                for i, original in enumerate(source):
                    current_item = obj.itemText(i)
                    expected = self.tr(original)
                    if not force and current_item not in {original, expected}:
                        original = current_item
                        source[i] = original
                    desired = self.tr(original)
                    if obj.itemText(i) != desired:
                        obj.setItemText(i, desired)

            if isinstance(obj, QTabWidget):
                source = getattr(obj, "_mr_i18n_tab_source", None)
                current = [obj.tabText(i) for i in range(obj.count())]
                if source is None or len(source) != obj.count():
                    source = list(current)
                    setattr(obj, "_mr_i18n_tab_source", source)
                for i, original in enumerate(source):
                    current_tab = obj.tabText(i)
                    expected = self.tr(original)
                    if not force and current_tab not in {original, expected}:
                        original = current_tab
                        source[i] = original
                    desired = self.tr(original)
                    if obj.tabText(i) != desired:
                        obj.setTabText(i, desired)

            if isinstance(obj, QTableWidget):
                for axis, count, getter in (
                    ("h", obj.columnCount(), obj.horizontalHeaderItem),
                    ("v", obj.rowCount(), obj.verticalHeaderItem),
                ):
                    for index in range(count):
                        item = getter(index)
                        if item is None:
                            continue
                        current = item.text()
                        key = f"_mr_i18n_{axis}_{index}"
                        original = obj.property(key)
                        if original is None:
                            original = current
                            obj.setProperty(key, original)
                        desired = self.tr(original)
                        if current != desired:
                            item.setText(desired)

            if isinstance(obj, QAction):
                text = obj.text()
                if text:
                    translated = self._translated_field(obj, "action_text", text, force)
                    if text != translated:
                        obj.setText(translated)
                tooltip = obj.toolTip()
                if tooltip:
                    translated = self._translated_field(obj, "action_tooltip", tooltip, force)
                    if tooltip != translated:
                        obj.setToolTip(translated)
                status_tip = obj.statusTip()
                if status_tip:
                    translated = self._translated_field(obj, "action_status", status_tip, force)
                    if status_tip != translated:
                        obj.setStatusTip(translated)

            if isinstance(obj, QSystemTrayIcon):
                tooltip = obj.toolTip()
                if tooltip:
                    translated = self._translated_field(obj, "tray_tooltip", tooltip, force)
                    if tooltip != translated:
                        obj.setToolTip(translated)

            if isinstance(obj, QMenu):
                for action in obj.actions():
                    self.translate_object(action, force=force)

            for child in obj.children():
                self.translate_object(child, force=force)
        except RuntimeError:
            # A Qt object may be deleted while a deferred translation pass is running.
            return


def install_i18n(app: QApplication, language: str | None = None) -> LanguageManager:
    existing = getattr(app, "_mr_language_manager", None)
    if isinstance(existing, LanguageManager):
        if language is not None:
            existing.set_language(language)
        return existing
    manager = LanguageManager(app, language)
    setattr(app, "_mr_language_manager", manager)
    return manager


def get_i18n(app: QApplication | None = None) -> LanguageManager | None:
    application = app or QApplication.instance()
    return getattr(application, "_mr_language_manager", None) if application else None


def set_app_language(language: str, app: QApplication | None = None) -> None:
    application = app or QApplication.instance()
    if application is None:
        return
    install_i18n(application, language)


def tr(text: Any, language: str | None = None) -> str:
    manager = get_i18n()
    if manager is not None and language is None:
        return manager.tr(text)
    return translate_text(text, language)
