from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any


class StateStore:
    def __init__(self) -> None:
        base = Path.home() / "AppData" / "Roaming"
        self.path = base / "MrInstaller" / "state.json"
        old = base / "PersonalAppsHub" / "state.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists() and old.exists():
            try:
                shutil.copy2(old, self.path)
            except OSError:
                pass
        self._data: dict[str, Any] = self._load()

    def _load(self) -> dict[str, Any]:
        if not self.path.exists():
            return {"settings": {}, "installed": {}}
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise ValueError("State root must be an object")
            data.setdefault("settings", {})
            data.setdefault("installed", {})
            return data
        except Exception:
            backup = self.path.with_suffix(".broken.json")
            try:
                self.path.replace(backup)
            except OSError:
                pass
            return {"settings": {}, "installed": {}}

    def save(self) -> None:
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps(self._data, indent=2, ensure_ascii=False), encoding="utf-8")
        temp.replace(self.path)

    def get_setting(self, key: str, default: Any = None) -> Any:
        return self._data["settings"].get(key, default)

    def set_setting(self, key: str, value: Any) -> None:
        self._data["settings"][key] = value
        self.save()

    def installed_info(self, app_id: str) -> dict[str, Any] | None:
        value = self._data["installed"].get(app_id)
        return value if isinstance(value, dict) else None

    def mark_installed(self, app_id: str, info: dict[str, Any]) -> None:
        self._data["installed"][app_id] = info
        self.save()

    def mark_uninstalled(self, app_id: str) -> None:
        self._data["installed"].pop(app_id, None)
        self.save()
