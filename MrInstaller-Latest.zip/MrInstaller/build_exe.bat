@echo off
setlocal
cd /d "%~dp0"
title Build MrInstaller

if not exist ".venv\Scripts\python.exe" (
    echo Run run.bat once before building.
    pause
    exit /b 1
)

".venv\Scripts\python.exe" -m pip install pyinstaller
if errorlevel 1 goto :error

".venv\Scripts\python.exe" -m PyInstaller ^
  --noconfirm ^
  --clean ^
  --windowed ^
  --name "MrInstaller" ^
  --icon "assets\mrinstaller.ico" ^
  main.py
if errorlevel 1 goto :error

copy /Y "installer_manifest.json" "dist\MrInstaller\installer_manifest.json" >nul
if not exist "dist\MrInstaller\packages" mkdir "dist\MrInstaller\packages"
xcopy /E /I /Y "packages" "dist\MrInstaller\packages" >nul
if not exist "dist\MrInstaller\assets" mkdir "dist\MrInstaller\assets"
xcopy /E /I /Y "assets" "dist\MrInstaller\assets" >nul
copy /Y "README.md" "dist\MrInstaller\README.md" >nul
copy /Y "PUBLISHING_UPDATES.md" "dist\MrInstaller\PUBLISHING_UPDATES.md" >nul
copy /Y "GITHUB_UPDATE_SETUP.md" "dist\MrInstaller\GITHUB_UPDATE_SETUP.md" >nul
copy /Y "UPDATE_NOTES.txt" "dist\MrInstaller\UPDATE_NOTES.txt" >nul
copy /Y "make_update_zip.py" "dist\MrInstaller\make_update_zip.py" >nul
copy /Y "make_update_zip.bat" "dist\MrInstaller\make_update_zip.bat" >nul

echo.
echo Build complete:
echo dist\MrInstaller\MrInstaller.exe
pause
exit /b 0

:error
echo.
echo Build failed.
pause
exit /b 1
