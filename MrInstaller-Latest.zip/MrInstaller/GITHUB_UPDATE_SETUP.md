# MrInstaller fixed-ZIP updates

The update channel is already configured for:

- Repository: `https://github.com/MrKayra/MrInstaller-Updates`
- Branch: `main`
- File: `MrInstaller-Latest.zip`

## Initial publication

1. Upload `MrInstaller-Latest.zip` to the root of the repository.
2. Keep the exact filename and keep it on the `main` branch.
3. Give the same ZIP to friends after uploading it.
4. Their first launch stores the current GitHub file SHA as the baseline.

## Every future update

1. Replace whichever package or MrInstaller source files changed.
2. Optionally update visible versions and `UPDATE_NOTES.txt`.
3. Double-click `make_update_zip.bat`.
4. It creates a fresh `MrInstaller-Latest.zip` beside the MrInstaller folder and gives the bundle a new build ID.
5. Replace the existing repository ZIP and commit/push the change.
6. Friends receive an update popup the next time MrInstaller starts.

Do not create a second filename such as `MrInstaller-Latest (1).zip`. Replace the existing file.

## How changed apps are identified

Each installed app stores the SHA-256 of the package from which it was installed. A newer MrInstaller bundle calculates the SHA-256 of its bundled packages. If a package differs, that app receives an Update button even when its displayed version was not increased.

Visible versions should still be increased for clarity, but they are no longer required for detecting package changes.

## User experience in 1.4+

Friends no longer need to extract a second copy. When the GitHub file SHA changes, they choose **Update now**. MrInstaller verifies the ZIP, updates its current folder in place, preserves `.venv` and AppData settings, and restarts.


## GitHub metadata behavior

GitHub may include a Base64 copy of repository files smaller than roughly 1 MB in the Contents API JSON response. MrInstaller 1.8.1 and newer allow enough guarded metadata space for this valid response while still rejecting unexpectedly large responses.
