@echo off
setlocal
cd /d "%~dp0"
title Build MrInstaller GitHub Update ZIP

where py >nul 2>nul
if %errorlevel%==0 (
    py -3 make_update_zip.py
) else (
    python make_update_zip.py
)
if errorlevel 1 goto :error

echo.
echo Upload the newly created MrInstaller-Latest.zip to:
echo https://github.com/MrKayra/MrInstaller-Updates
echo.
pause
exit /b 0

:error
echo.
echo The update ZIP could not be created.
pause
exit /b 1
