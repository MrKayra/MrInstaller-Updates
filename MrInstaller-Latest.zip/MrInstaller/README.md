# MrInstaller 1.6.4

MrInstaller is the Windows installer, launcher, and update hub for **MrStudio**, **MrMacro**, **MrSoundboard**, and **MrDownloader**.

## Included apps

- **MrStudio 1.2.1** — local video, audio, image, conversion, metadata, subtitle, and utility tools. The old OmniEdit source branding has been removed.
- **MrMacro 1.1.0** — macro recording, global hotkeys, timeline editing, playback, and visual wait conditions. The old MacroForge source branding has been removed. Dropdowns and dialogs now use a forced dark theme on every Windows theme.
- **MrSoundboard 4.1.0** — low-latency sound clips, hotkeys, microphone mixing, monitoring, recording, and virtual-cable routing. The old OpenSoundboard source branding has been removed, and the usable X-button fix is retained.
- **MrDownloader 1.0.0** — configurable yt-dlp media downloader with multi-link queues, quality presets, playlists, subtitles, metadata, cookies, and format inspection.

## Running MrInstaller

1. Install 64-bit Python 3.11 or newer and enable **Add Python to PATH**.
2. Extract the complete MrInstaller ZIP.
3. Double-click `run.bat`.

On the first run, `run.bat` creates a private environment. It then starts MrInstaller with `pythonw` and exits, so closing the command window does not close the app. Installed Mr Apps are launched the same detached way.

## Installing and updating an included app

Press **Install** for a new app. MrInstaller safely extracts the app, creates a private environment, installs its required Python components, creates shortcuts, and stores it under `%LOCALAPPDATA%\MrApps` by default.

When the bundled version is newer than the installed version, MrInstaller shows a launch popup and changes that app's button to **Update**. Updates use a temporary backup and roll back automatically if setup fails. Personal app data stored under `%APPDATA%` is not removed.

The first installation or update of each source app needs internet access for Python packages. Later launches are local.

## Online update popups

This build is already connected to `https://github.com/MrKayra/MrInstaller-Updates`. It watches `MrInstaller-Latest.zip` on the `main` branch.

When that GitHub file is replaced, MrInstaller detects its changed GitHub SHA and shows an update popup on launch. A newer downloaded bundle compares SHA-256 package hashes and gives Update buttons only to changed apps.

Run `make_update_zip.bat` before every upload so the bundle receives a unique build ID. See `GITHUB_UPDATE_SETUP.md` and `PUBLISHING_UPDATES.md`.

## External apps

External software is never installed silently. MrInstaller shows what it is, why it is needed, the source, administrator/restart warnings, and asks for permission.

- MrStudio can install FFmpeg and LibreOffice through Windows Package Manager.
- MrSoundboard can download the official VB-CABLE driver package, extract it, and start its administrator setup after approval.
- VB-CABLE requires a Windows restart after installation.

## Troubleshooting

- Use `run_console.bat` when MrInstaller itself will not start.
- Each installed app contains its own diagnostic launcher or setup log.
- MrInstaller setup logs are stored inside the installed app folder as `mrinstaller_setup.log`.
- External installer logs are stored under `%USERPROFILE%\Downloads\MrInstaller\ExternalInstallers`.
- App state and MrInstaller logs are stored under `%APPDATA%\MrInstaller`.

## Building a standalone MrInstaller EXE

Run `run.bat` once, close MrInstaller, then run `build_exe.bat`.

The output appears at `dist\MrInstaller\MrInstaller.exe`. Copy the entire `dist\MrInstaller` folder when sharing it, because the manifest, app ZIPs, icons, and GitHub update guides are stored beside the EXE.

The included apps are Python source packages. Even when MrInstaller itself is built as an EXE, installing the included apps still requires a normal Python 3.11+ installation unless the source ZIPs are later replaced with prebuilt Windows app folders.

## In-place GitHub updates

When the fixed GitHub ZIP changes, MrInstaller can download it, verify GitHub's blob SHA and ZIP structure, close itself, replace the current program files, preserve `.venv` and AppData settings, then restart automatically. A temporary backup is restored if replacement fails. Installed apps remain installed; changed bundled app packages receive Update buttons after restart.

## Language

Open **Settings** in MrInstaller to choose **English** or **Türkçe**. English is the default. The selection is stored in MrInstaller's shared state and is used by MrStudio, MrMacro, MrSoundboard, and MrDownloader the next time each app opens.
