@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title MrInstaller Launcher

set "PYTHON="
for %%V in (3.14 3.13 3.12 3.11 3.10) do (
    if not defined PYTHON (
        py -%%V -c "import sys" >nul 2>nul
        if not errorlevel 1 set "PYTHON=py -%%V"
    )
)

if not defined PYTHON (
    where python >nul 2>nul
    if not errorlevel 1 (
        python -c "import sys; raise SystemExit(0 if (3, 10) ^<= sys.version_info[:2] ^< (3, 15) else 1)" >nul 2>nul
        if not errorlevel 1 set "PYTHON=python"
    )
)

if not defined PYTHON (
    echo.
    echo Python 3.10 through 3.14 was not found.
    echo Install Python from https://www.python.org/downloads/windows/
    echo Enable "Add python.exe to PATH" during installation.
    echo.
    pause
    exit /b 1
)

if not exist ".venv\Scripts\pythonw.exe" (
    echo Creating the private MrInstaller environment...
    %PYTHON% -m venv .venv
    if errorlevel 1 goto :error
)

if not exist ".venv\.mrinstaller_ready_6_11_1" (
    echo Installing MrInstaller components...
    ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check --upgrade -r requirements.txt
    if errorlevel 1 goto :error
    del /q ".venv\.mrinstaller_ready" >nul 2>nul
    > ".venv\.mrinstaller_ready_6_11_1" echo ready
)

echo Checking MrInstaller startup files...
".venv\Scripts\python.exe" -c "from app.ui import MainWindow; from app.utils import format_bytes, sha256_file"
if errorlevel 1 goto :error

rem pythonw runs independently, so this command window can close safely.
start "MrInstaller" /D "%~dp0" ".venv\Scripts\pythonw.exe" "%~dp0main.py"
if errorlevel 1 goto :error
exit /b 0

:error
echo.
echo MrInstaller could not start. The error is shown above.
echo You can also run run_console.bat for a complete diagnostic log.
echo.
pause
exit /b 1
