@echo off
setlocal
cd /d "%~dp0"
title MrInstaller Launcher

where py >nul 2>nul
if %errorlevel%==0 (
    set "PYTHON=py -3"
) else (
    where python >nul 2>nul
    if errorlevel 1 (
        echo.
        echo Python 3.11 or newer was not found.
        echo Install Python and enable Add Python to PATH.
        echo.
        pause
        exit /b 1
    )
    set "PYTHON=python"
)

if not exist ".venv\Scripts\pythonw.exe" (
    echo Creating MrInstaller environment...
    %PYTHON% -m venv .venv
    if errorlevel 1 goto :error
)

if not exist ".venv\.mrinstaller_ready" (
    ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
    if errorlevel 1 goto :error
    > ".venv\.mrinstaller_ready" echo ready
)

rem pythonw is detached from this command window. Closing CMD will not close MrInstaller.
start "" ".venv\Scripts\pythonw.exe" "%~dp0main.py"
exit /b 0

:error
echo.
echo MrInstaller could not start. Read the error above.
pause
exit /b 1
