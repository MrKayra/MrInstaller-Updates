from __future__ import annotations

import datetime as dt
import json
import uuid
import zipfile
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
OUTPUT = PROJECT_ROOT.parent / "MrInstaller-Latest.zip"
MANIFEST = PROJECT_ROOT / "installer_manifest.json"
EXCLUDED_DIRS = {".venv", "__pycache__", ".ruff_cache", "build", "dist", ".git", ".idea", ".vscode"}
EXCLUDED_FILES = {"MrInstaller-Latest.zip"}


def main() -> int:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    settings = manifest.setdefault("settings", {})
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    settings["hub_build_id"] = f"{stamp}-{uuid.uuid4().hex[:10]}"
    MANIFEST.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    temp = OUTPUT.with_suffix(".zip.tmp")
    temp.unlink(missing_ok=True)
    OUTPUT.unlink(missing_ok=True)
    with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(PROJECT_ROOT.rglob("*")):
            relative = path.relative_to(PROJECT_ROOT)
            if any(part in EXCLUDED_DIRS for part in relative.parts):
                continue
            if path.name in EXCLUDED_FILES or not path.is_file():
                continue
            archive.write(path, Path("MrInstaller") / relative)

    temp.replace(OUTPUT)
    print(f"Created: {OUTPUT}")
    print(f"Build ID: {settings['hub_build_id']}")
    print(f"Size: {OUTPUT.stat().st_size:,} bytes")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
