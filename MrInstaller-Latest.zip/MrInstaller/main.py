from __future__ import annotations

import logging
import sys
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication, QMessageBox

from app.config import AppConfig
from app.ui import MainWindow


def configure_logging() -> Path:
    log_dir = Path.home() / "AppData" / "Roaming" / "MrInstaller" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "hub.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        handlers=[logging.FileHandler(log_file, encoding="utf-8")] + ([logging.StreamHandler(sys.stdout)] if sys.stdout else []),
    )
    return log_file


def main() -> int:
    log_file = configure_logging()
    app = QApplication(sys.argv)
    app.setApplicationName("MrInstaller")
    app.setOrganizationName("Kayra.exe Studios")
    app.setStyle("Fusion")
    app.setAttribute(Qt.ApplicationAttribute.AA_DontUseNativeMenuBar, False)

    project_root = (
        Path(sys.executable).resolve().parent
        if getattr(sys, "frozen", False)
        else Path(__file__).resolve().parent
    )
    try:
        config = AppConfig.load(project_root / "installer_manifest.json")
        app.setApplicationVersion(config.settings.hub_version)
        window = MainWindow(config=config, project_root=project_root)
        window.show()
        return app.exec()
    except Exception as exc:
        logging.exception("Fatal startup error")
        QMessageBox.critical(
            None,
            "MrInstaller could not start",
            f"{exc}\n\nA log was saved to:\n{log_file}",
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
