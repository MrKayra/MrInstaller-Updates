from __future__ import annotations

import ctypes
import logging
import sys
import traceback
from pathlib import Path


def configure_logging() -> Path:
    log_dir = Path.home() / "AppData" / "Roaming" / "MrInstaller" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "hub.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        handlers=[logging.FileHandler(log_file, encoding="utf-8")]
        + ([logging.StreamHandler(sys.stdout)] if sys.stdout else []),
    )
    return log_file


def show_fatal_error(message: str, log_file: Path) -> None:
    full_message = f"{message}\n\nA log was saved to:\n{log_file}"
    try:
        from PySide6.QtWidgets import QApplication, QMessageBox

        app = QApplication.instance() or QApplication(sys.argv)
        QMessageBox.critical(None, "MrInstaller could not start", full_message)
        return
    except Exception:
        pass

    try:
        ctypes.windll.user32.MessageBoxW(
            0,
            full_message,
            "MrInstaller could not start",
            0x10,
        )
    except Exception:
        # Last-resort fallback for console/debug launches.
        print(full_message, file=sys.stderr)


def configure_windows_identity() -> None:
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("KayraExe.MrInstaller.1")
    except Exception:
        pass


def main() -> int:
    configure_windows_identity()
    log_file = configure_logging()
    try:
        from PySide6.QtCore import Qt
        from PySide6.QtGui import QIcon
        from PySide6.QtWidgets import QApplication

        from app.config import AppConfig
        from app.i18n import install_i18n
        from app.ui import MainWindow

        app = QApplication(sys.argv)
        app.setApplicationName("MrInstaller")
        app.setOrganizationName("Kayra.exe Studios")
        app.setApplicationDisplayName("MrInstaller")
        app.setStyle("Fusion")
        app.setAttribute(Qt.ApplicationAttribute.AA_DontUseNativeMenuBar, False)
        install_i18n(app)

        project_root = (
            Path(sys.executable).resolve().parent
            if getattr(sys, "frozen", False)
            else Path(__file__).resolve().parent
        )
        icon_path = project_root / "assets" / "mrinstaller.ico"
        if icon_path.exists():
            app.setWindowIcon(QIcon(str(icon_path)))
        config = AppConfig.load(project_root / "installer_manifest.json")
        app.setApplicationVersion(config.settings.hub_version)
        window = MainWindow(config=config, project_root=project_root)
        window.show()
        return app.exec()
    except Exception as exc:
        logging.exception("Fatal startup error")
        show_fatal_error(f"{type(exc).__name__}: {exc}", log_file)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
