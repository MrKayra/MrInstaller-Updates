@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" call run.bat
".venv\Scripts\python.exe" main.py
echo.
echo MrInstaller closed with exit code %errorlevel%.
pause
