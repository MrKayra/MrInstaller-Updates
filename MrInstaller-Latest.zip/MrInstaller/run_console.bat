@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title MrInstaller Diagnostic Launcher

set "PYTHON="
for %%V in (3.14 3.13 3.12 3.11 3.10) do (
    if not defined PYTHON (
        py -%%V -c "import sys" >nul 2>nul
        if not errorlevel 1 set "PYTHON=py -%%V"
    )
)
if not defined PYTHON (
    where python >nul 2>nul
    if not errorlevel 1 (
        python -c "import sys; raise SystemExit(0 if (3, 10) ^<= sys.version_info[:2] ^< (3, 15) else 1)" >nul 2>nul
        if not errorlevel 1 set "PYTHON=python"
    )
)
if not defined PYTHON (
    echo Python 3.10 through 3.14 was not found.
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo Creating the private MrInstaller environment...
    %PYTHON% -m venv .venv
    if errorlevel 1 goto :error
)
if not exist ".venv\.mrinstaller_ready_6_11_1" (
    echo Installing MrInstaller components...
    ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check --upgrade -r requirements.txt
    if errorlevel 1 goto :error
    del /q ".venv\.mrinstaller_ready" >nul 2>nul
    > ".venv\.mrinstaller_ready_6_11_1" echo ready
)

".venv\Scripts\python.exe" main.py
set "RESULT=%errorlevel%"
echo.
echo MrInstaller closed with exit code %RESULT%.
pause
exit /b %RESULT%

:error
echo.
echo MrInstaller setup failed.
pause
exit /b 1
